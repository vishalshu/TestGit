package com.lexisnexis.es.dms.audit;

import com.lexisnexis.es.dms.core.service.BasicDmsService;
import com.lexisnexis.es.dms.core.service.DmsServiceResult;
import com.lexisnexis.es.dms.core.service.ServiceResult;
import com.lexisnexis.es.dms.core.transaction.RequestContext;

/**
 * Implementation of the service interface for auditing <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public class AuditService extends BasicDmsService
{

    /*
     * (non-Javadoc)
     * @see com.lexisnexis.es.dms.service.DmsService#process(com.lexisnexis.es.dms.transaction.RequestContext)
     */
    @Override
    public DmsServiceResult process(final RequestContext currentContext)
    {
        if (currentContext != null)
        {
            // TODO actually check something!
            return new ServiceResult(true, null);
        }
        else
        {
            throw new IllegalArgumentException();
        }
    }

}
