/**
 * 
 */
package com.lexisnexis.es.dms.audit;

import org.junit.Test;

/**
 * <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */

public class AuditServiceTest
{
    /**
     * Tests when the context is null - should throw exception
     */
    @Test(expected = IllegalArgumentException.class)
    public void testNullContext()
    {
        AuditService auditService = new AuditService();
        auditService.process(null);
    }

}
