/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.adapter.cmis;

import java.io.InputStream;

import org.apache.chemistry.opencmis.client.api.Document;

import com.lexisnexis.es.dms.core.service.RepositoryObjectLocationImpl;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectLocation;
import com.lexisnexis.es.dms.core.transaction.DocumentRepositoryObject;

/**
 * An implementation of the DocumentInfo interface based on an OpenCMIS Document. <br/>
 * <br/>
 * <hr/>
 * @author OMahonyJ
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class CMISDocumentInfo implements DocumentRepositoryObject
{

    /** the cmis document */
    private final Document cmisDocument;

    /**
     * @param cmisDocument
     */
    public CMISDocumentInfo(final Document cmisDocument)
    {
        super();
        this.cmisDocument = cmisDocument;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RepositoryObjectLocation getLocation()
    {
        // TODO what do multiple paths mean? - something to do with multifiling?
        RepositoryObjectLocation docLoc = new RepositoryObjectLocationImpl(cmisDocument.getPaths().get(0));
        return docLoc;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getDocumentFileName()
    {
        return cmisDocument.getContentStreamFileName();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getMimeType()
    {
        return cmisDocument.getContentStreamMimeType();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isVersioned()
    {
        // TODO Auto-generated method stub
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isMajorVersion()
    {
        return cmisDocument.isMajorVersion();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public InputStream getContent()
    {
        return cmisDocument.getContentStream().getStream();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getId()
    {
        return cmisDocument.getId();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName()
    {
        return cmisDocument.getName();
    }
}
