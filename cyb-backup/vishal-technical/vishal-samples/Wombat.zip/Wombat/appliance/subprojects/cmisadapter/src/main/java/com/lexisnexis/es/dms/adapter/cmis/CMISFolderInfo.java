/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.adapter.cmis;

import org.apache.chemistry.opencmis.client.api.Folder;

import com.lexisnexis.es.dms.core.service.RepositoryObjectLocationImpl;
import com.lexisnexis.es.dms.core.transaction.FolderRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectLocation;

/**
 * Implementation of the FolderIfo interface based on cmis Folder object <br/>
 * <br/>
 * <hr/>
 * @author OMahonyJ
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class CMISFolderInfo implements FolderRepositoryObject
{

    /**  */
    Folder cmisFolder;

    /**
     * Construct using a cmis Folder.
     * @param cmisFolder
     */
    public CMISFolderInfo(final Folder cmisFolder)
    {
        super();
        this.cmisFolder = cmisFolder;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isRootFolder()
    {
        return cmisFolder.isRootFolder();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RepositoryObjectLocation getLocation()
    {
        RepositoryObjectLocation location = new RepositoryObjectLocationImpl(cmisFolder.getPath());
        return location;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getId()
    {
        return cmisFolder.getId();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName()
    {
        return cmisFolder.getName();
    }

}
