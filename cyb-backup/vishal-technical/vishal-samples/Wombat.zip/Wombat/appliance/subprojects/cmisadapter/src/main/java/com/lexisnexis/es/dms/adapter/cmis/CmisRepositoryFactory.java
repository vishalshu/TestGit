/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.adapter.cmis;

import java.util.List;
import java.util.Map;

import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.SessionFactory;
import org.apache.chemistry.opencmis.client.runtime.SessionFactoryImpl;
import org.springframework.beans.factory.InitializingBean;

import com.lexisnexis.es.dms.repository.RepositoryException;

/**
 * Implementation of {@link CmisRepositoryFactory}.<br/>
 * NOTE: Instance of this class must be created through Spring only, as it is using spring callback method. <br/>
 * <hr/>
 * @author shuklav
 */

public class CmisRepositoryFactory implements InitializingBean
{

    /** session parameters used to connect to underlying repository */
    private final Map<String, String> sessionParameters;

    /** fetched repositories list */
    protected List<Repository> repositories;

    /**
     * @param sessionParameters session parameters used to connect to underlying repository
     */
    public CmisRepositoryFactory(final Map<String, String> sessionParameters)
    {
        this.sessionParameters = sessionParameters;
    }

    /**
     * Fetches {@link Repository} instance which can be used to interact with underlying repository.
     * @return the repository instance
     * @throws RepositoryException
     */

    public Repository getRepository() throws RepositoryException
    {

        if (repositories == null || repositories.size() == 0)
        {
            throw new RepositoryException("Could not fetch the valid repository instance");
        }
        return repositories.get(0);
    }

    /**
     * Initializes repositories
     */
    private void initRepositories()
    {
        SessionFactory factory = SessionFactoryImpl.newInstance();
        repositories = factory.getRepositories(sessionParameters);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void afterPropertiesSet() throws Exception
    {
        initRepositories();

    }

}
