/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.adapter.cmis.actions;

import java.util.StringTokenizer;

import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.ItemIterable;
import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.commons.enums.BaseTypeId;
import org.apache.chemistry.opencmis.commons.enums.VersioningState;

import com.lexisnexis.es.dms.core.transaction.DocumentInfo;
import com.lexisnexis.es.dms.repository.actions.RepositoryAction;

/**
 * Abstract class for all the CMIS repository actions. Provides utility methods useful for cmis repository
 * action classes.<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 */

public abstract class AbstractCmisRepositoryAction implements RepositoryAction
{
    /** the repository instance interacting with underlying document repository */
    protected final Repository repository;

    /** The path of the initial folder for this repository, e.g. the root dms folder for this application */
    private String startPath;

    /**
     * @param repository the repository instance which can interact with documents repository
     */
    public AbstractCmisRepositoryAction(final Repository repository)
    {
        super();
        this.repository = repository;
    }

    /**
     * Scans the repository for a child folder with the specified path.
     * @param session the cmis session
     * @param folderPath the path to the required folder
     * @return the specified child folder, or the last valid folder found on the path
     */
    public Folder getChildFolderByPath(final Session session, final String folderPath)
    {
        return getChildFolderByPath(getStartFolder(session), folderPath);
    }

    /**
     * Scans the specified folder for a child folder with the specified path.
     * @param startFolder the starting point for the search
     * @param folderPath the path to the required folder
     * @return the specified child folder, or the last valid folder found on the path
     */
    public Folder getChildFolderByPath(final Folder startFolder, final String folderPath)
    {
        Folder childFolder = startFolder;
        StringTokenizer st = new StringTokenizer(folderPath, "\\/");
        while (st.hasMoreTokens() && childFolder != null)
        {
            childFolder = getChildFolderByName(childFolder, st.nextToken());
        }
        return childFolder;
    }

    /**
     * tests whether the supplied CmisObject is a folder
     * @param o the object to test
     * @return true if it is a Folder
     */
    protected boolean isFolder(final CmisObject o)
    {
        if (o.getBaseTypeId().equals(BaseTypeId.CMIS_FOLDER))
        {
            return true;
        }
        return false;
    }

    /**
     * Scans the supplied folder for a child folder with the specified name
     * @param parentFolder the folder to search
     * @param folderName the name of the child folder
     * @return the specified child folder
     */
    protected Folder getChildFolderByName(final Folder parentFolder, final String folderName)
    {
        Folder childObject = null;
        ItemIterable<CmisObject> children = parentFolder.getChildren();
        if (children != null)
        {
            for (CmisObject o : children)
            {
                if (isFolder(o) && folderName.equals(o.getName()))
                {
                    childObject = (Folder)o;
                    break;
                }
            }
        }
        else
        {
            // TODO LOGGING
            System.out.println("getChildFolderByName(): parent folder has no children.");
        }
        if (childObject == null)
        {
            // TODO LOGGING
            System.out.println("getChildFolderByName(): child not found.");
        }
        return childObject;
    }

    /**
     * Scans the supplied folder for a document with the specified name
     * @param parentFolder the folder to search
     * @param documentName the name of the document in the folder
     * @return the specified document
     */
    protected Document getChildDocumentByName(final Folder parentFolder, final String documentName)
    {
        Document childObject = null;
        for (CmisObject o : parentFolder.getChildren())
        {
            if (isDocument(o) && documentName.equals(o.getName()))
            {
                childObject = (Document)o;
                break;
            }
        }
        return childObject;
    }

    /**
     * tests whether the supplied CmisObject is a document
     * @param o the object to test
     * @return true if it is a Document
     */
    protected boolean isDocument(final CmisObject o)
    {
        if (o.getBaseTypeId().equals(BaseTypeId.CMIS_DOCUMENT))
        {
            return true;
        }
        return false;
    }

    /**
     * examines the DovumentInfo and determines the VersioningState
     * @param info the info for the document
     * @return the appropriate VersioningState
     */
    public VersioningState getVersioningState(final DocumentInfo info)
    {
        VersioningState versionState = VersioningState.NONE;
        if (info.isVersioned())
        {
            if (info.isMajorVersion())
            {
                versionState = VersioningState.MAJOR;
            }
            else
            {
                versionState = VersioningState.MINOR;
            }
        }
        return versionState;
    }

    /**
     * Gets the starting point for placing documents in the repository, a combination of the repository root,
     * plus any application startPath that has been specified in configuration files.
     * @param session the current CMIS session
     * @return the starting folder for document storage
     */
    protected Folder getStartFolder(final Session session)
    {
        Folder rootFolder = session.getRootFolder();
        return getChildFolderByPath(rootFolder, startPath);
    }

    /**
     * @return the startPath
     */
    public String getStartPath()
    {
        return startPath;
    }

    /**
     * @param startPath the startPath to set
     */
    public void setStartPath(final String startPath)
    {
        this.startPath = startPath;
    }

}
