/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.adapter.cmis.actions;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.Session;

import com.lexisnexis.es.dms.adapter.cmis.CMISDocumentInfo;
import com.lexisnexis.es.dms.core.transaction.BulkDocumentsInfo;
import com.lexisnexis.es.dms.core.transaction.DocumentInfo;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectLocation;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestResult;
import com.lexisnexis.es.dms.core.transaction.RequestResultImpl;
import com.lexisnexis.es.dms.repository.actions.CreateBulkDocumentsAction;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class CmisCreateBulkDocumentAction extends CmisCreateDocumentAction implements
                        CreateBulkDocumentsAction
{

    /**
     * @param repository
     */
    public CmisCreateBulkDocumentAction(final Repository repository)
    {
        super(repository);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestResult execute(final RequestContext requestContext)
    {

        Document doc = null;
        final RequestResultImpl requestResult = new RequestResultImpl();
        requestContext.addEventItem("starting bulk document creation");
        final Session session = repository.createSession();
        requestContext.addEventItem("session created");
        BulkDocumentsInfo info = null;
        if (requestContext.getRepositoryObjectInfo() instanceof BulkDocumentsInfo)
        {
            info = (BulkDocumentsInfo)requestContext.getRepositoryObjectInfo();
        }
        if (info != null)
        {
            final RepositoryObjectLocation location = info.getLocation();
            final String folderPath = location != null ? location.getLogicalPath() : defaultPath;
            for (DocumentInfo docInfo : info.getDocuments())
            {
                doc = createDocument(requestContext, session, docInfo, folderPath);
                requestResult.addResult(new CMISDocumentInfo(doc));
            }
        }
        requestContext.addEventItem("bulk upload completed");
        return requestResult;
    }

}
