/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.adapter.cmis.actions;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.enums.VersioningState;
import org.apache.chemistry.opencmis.commons.impl.dataobjects.ContentStreamImpl;

import com.lexisnexis.es.dms.adapter.cmis.CMISDocumentInfo;
import com.lexisnexis.es.dms.core.service.BasicRequestContextEventItem;
import com.lexisnexis.es.dms.core.transaction.DocumentInfo;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectLocation;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestContextEventItem;
import com.lexisnexis.es.dms.core.transaction.RequestResult;
import com.lexisnexis.es.dms.core.transaction.RequestResultImpl;
import com.lexisnexis.es.dms.repository.actions.CreateDocumentAction;

/**
 * cmis implementation for Create new document action <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 */

public class CmisCreateDocumentAction extends AbstractCmisRepositoryAction
                        implements CreateDocumentAction
{
    /**
     * Default path to be used for document creation if logical path is not passed in the reequest context.
     */
    protected final String defaultPath = "lndms";

    /**
     * @param repository the repository instance which can interact with documents repository
     */
    public CmisCreateDocumentAction(final Repository repository)
    {
        super(repository);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestResult execute(final RequestContext requestContext)
    {
        Document doc = null;
        requestContext.addEventItem("creating document");
        final Session session = repository.createSession();
        requestContext.addEventItem("session created");
        DocumentInfo info = null;
        if (requestContext.getRepositoryObjectInfo() instanceof DocumentInfo)
        {
            info = (DocumentInfo)requestContext.getRepositoryObjectInfo();
        }
        if (info != null)
        {
            final RepositoryObjectLocation location = info.getLocation();
            final String folderPath = location != null ? location.getLogicalPath() : defaultPath;
            doc = createDocument(requestContext, session, info, folderPath);
        }

        final RequestResultImpl requestResult = new RequestResultImpl();
        requestResult.addResult(new CMISDocumentInfo(doc));
        return requestResult;

    }

    /**
     * @param requestContext
     * @param session
     * @param docInfo
     * @param folderPath
     * @return newly created instance of document
     */
    protected Document createDocument(final RequestContext requestContext,
                                      final Session session,
                                      final DocumentInfo docInfo,
                                      final String folderPath)
    {
        Document doc = null;
        final Folder folder = getChildFolderByPath(session, folderPath);
        if (folder != null)
        {
            requestContext.addEventItem("folder located");
            String name = docInfo.getDocumentFileName();
            String mimeType = docInfo.getMimeType();
            doc = createDocument(requestContext,
                                          session,
                                          folder,
                                          name,
                                          docInfo.getContent(),
                                          mimeType,
                                          getVersioningState(docInfo));
            requestContext.addEventItem("doc created:" + doc.getId());
        }
        else
        {
            requestContext.addEventItem("folder not found:" + folderPath);
            // TODO throw an exception?
        }

        requestContext.addEventItem("document creation finished");
        return doc;
    }

    /**
     * Creates a doc with the specified name in the specified folder with the given contents (unless the
     * document already exists).
     * @param requestContext the current context
     * @param session the current session
     * @param newDocsFolder the folder where the document should be created
     * @param name the name to give the new document
     * @param content the content of the file
     * @param mimeType the mime type of the file (e.g "text/plain")
     * @param versionState the versioning state (e.g. MAJOR, MINOR or NONE)
     * @return the new document, or the existing document if a doc of that name already exists
     */
    private Document createDocument(final RequestContext requestContext,
                                    final Session session,
                                    final Folder newDocsFolder,
                                    final String name,
                                    final InputStream content,
                                    final String mimeType,
                                    final VersioningState versionState)
    {
        if (session == null)
        {
            throw new IllegalArgumentException("CMISAdapter - session is null");
        }
        if (newDocsFolder == null)
        {
            throw new IllegalArgumentException("CMISAdapter - newDocsFolder is null");
        }
        if (name == null)
        {
            throw new IllegalArgumentException("CMISAdapter - name is null");
        }
        if (content == null)
        {
            throw new IllegalArgumentException("CMISAdapter - content is null");
        }
        if (mimeType == null)
        {
            throw new IllegalArgumentException("CMISAdapter - mimeType is null");
        }
        if (versionState == null)
        {
            throw new IllegalArgumentException("CMISAdapter - versionState is null");
        }
        Document newDoc = getChildDocumentByName(newDocsFolder, name);
        if (newDoc == null)
        {
            // properties
            // (minimal set: name and object type id)
            Map<String, Object> properties = new HashMap<String, Object>();
            properties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:document");
            properties.put(PropertyIds.NAME, name);

            // content

            ContentStream contentStream;
            try
            {
                contentStream = new ContentStreamImpl(name,
                                                                    BigInteger.valueOf(content.available()),
                                                                    mimeType,
                                                                    content);
            }
            catch (IOException e)
            {
                throw new IllegalArgumentException("CMISAdapter - content is corrupted");
            }

            // create a new version
            try
            {
                newDoc = newDocsFolder.createDocument(properties, contentStream, versionState);
            }
            catch (Throwable t)
            {
                t.printStackTrace();
            }
        }
        else
        {
            RequestContextEventItem item = new BasicRequestContextEventItem("Document already exists:" + name);
            item.setReturnCode(RequestContextEventItem.DOCUMENT_ALREADY_EXISTS);
            requestContext.addEventItem(item);
        }
        return newDoc;
    }

}
