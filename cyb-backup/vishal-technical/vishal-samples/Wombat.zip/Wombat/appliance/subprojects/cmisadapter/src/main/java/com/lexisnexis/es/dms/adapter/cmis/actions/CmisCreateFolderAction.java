/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.adapter.cmis.actions;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.commons.PropertyIds;

import com.lexisnexis.es.dms.adapter.cmis.CMISFolderInfo;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectInfo;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestResult;
import com.lexisnexis.es.dms.core.transaction.RequestResultImpl;
import com.lexisnexis.es.dms.repository.actions.CreateFolderAction;

/**
 * cmis implementation for Create new folder action <br/>
 * <br/>
 * Creates a new folder (or chain of folders) under the root folder with the specified name(s), provided it
 * does not already exist. If the Folder already exists, the existing folder is returned. The folder to create
 * is taken from the document location in the context. All necessary folders on the path will be created, the
 * final 'leaf' will be returned <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class CmisCreateFolderAction extends AbstractCmisRepositoryAction
                        implements CreateFolderAction
{

    /**
     * @param repository the repository instance which can interact with documents repository
     */
    public CmisCreateFolderAction(final Repository repository)
    {
        super(repository);

    }

    /**
     * {@inheritDoc}
     * @return the last folder in the location
     */
    @Override
    public RequestResult execute(final RequestContext requestContext)
    {
        String folderPath = null;
        CMISFolderInfo returnFolder = null;
        Folder childFolder = null;

        requestContext.addEventItem("creating Folder");
        Session session = repository.createSession();
        requestContext.addEventItem("session created");

        // Need to change this logic to use folderInfo for all the create folder requests
        final RepositoryObjectInfo info = requestContext.getRepositoryObjectInfo();

        if (info != null)
        {
            folderPath = info.getLocation().getLogicalPath();
        }

        if (folderPath != null && folderPath.trim().length() > 0)
        {
            childFolder = getStartFolder(session);
            final StringTokenizer st = new StringTokenizer(folderPath, "\\/");
            while (st.hasMoreTokens() && childFolder != null)
            {
                childFolder = createFolder(requestContext, session, childFolder, st.nextToken());
            }
            returnFolder = new CMISFolderInfo(childFolder);
        }
        final RequestResultImpl requestResult = new RequestResultImpl();
        requestResult.addResult(returnFolder);
        return requestResult;
    }

    /**
     * Creates a new folder under the specified folder with the specified name, provided it does not already
     * exist. If the Folder already exists, the existing folder is returned
     * @param requestContext the current context
     * @param session the current session
     * @param currentFolder the parent folder
     * @param newFolderName the name for the new child folder
     * @return the newly created folder, or the existing folder of that name
     */
    Folder createFolder(final RequestContext requestContext,
                        final Session session,
                        final Folder currentFolder,
                        final String newFolderName)
    {
        Folder returnFolder = getChildFolderByName(currentFolder, newFolderName);
        if (returnFolder == null)
        {
            requestContext.addEventItem("creating new Folder" + newFolderName);
            // properties
            // (minimal set: name and object type id)
            Map<String, Object> properties = new HashMap<String, Object>();
            properties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:folder");
            properties.put(PropertyIds.NAME, newFolderName);

            // create the folder
            returnFolder = currentFolder.createFolder(properties);
        }
        else
        {
            requestContext.addEventItem("folder already exists:" + newFolderName);
        }
        return returnFolder;
    }

}
