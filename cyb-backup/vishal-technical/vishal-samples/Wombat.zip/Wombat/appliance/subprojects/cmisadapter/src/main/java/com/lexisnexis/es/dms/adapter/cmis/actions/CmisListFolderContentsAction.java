/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.adapter.cmis.actions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.ItemIterable;
import org.apache.chemistry.opencmis.client.api.OperationContext;
import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.Session;

import com.lexisnexis.es.dms.adapter.cmis.CMISDocumentInfo;
import com.lexisnexis.es.dms.adapter.cmis.CMISFolderInfo;
import com.lexisnexis.es.dms.core.service.BasicRequestContextEventItem;
import com.lexisnexis.es.dms.core.transaction.RepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectInfo;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestContextEventItem;
import com.lexisnexis.es.dms.core.transaction.RequestResult;
import com.lexisnexis.es.dms.core.transaction.RequestResultImpl;
import com.lexisnexis.es.dms.repository.actions.ListFolderContentsAction;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class CmisListFolderContentsAction extends AbstractCmisRepositoryAction implements
                        ListFolderContentsAction
{

    /**
     * @param repository
     */
    public CmisListFolderContentsAction(final Repository repository)
    {
        super(repository);
        // TODO Auto-generated constructor stub
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestResult execute(final RequestContext requestContext)
    {
        requestContext.addEventItem("listing Folder");
        Session session = repository.createSession();
        requestContext.addEventItem("session created");
        RepositoryObjectInfo info = requestContext.getRepositoryObjectInfo();
        String folderPath = info.getLocation().getLogicalPath();
        RequestResult requestResult = null;
        if (folderPath != null && folderPath.trim().length() > 0)
        {
            requestResult = listFolder(requestContext, session, folderPath);
        }
        else
        {
            throw new IllegalArgumentException("Folder path can not be null");
        }
        return requestResult;
    }

    /**
     * Get the contents of the specified folder, 1 page at a time.
     * @param requestContext the current context
     * @param session the cmis session
     * @param folderPath the path of the folder
     * @return a list of repository objects
     */
    private RequestResult listFolder(final RequestContext requestContext,
                                     final Session session,
                                     final String folderPath)
    {
        List<RepositoryObject> results = new ArrayList<RepositoryObject>();
        // TODO - where do we get paging numbers from?
        int maxItemsPerPage = 10;
        int skipCount = 0;
        final RequestResultImpl requestResult = new RequestResultImpl();

        Folder folder = getChildFolderByPath(session, folderPath);
        if (folder != null)
        {
            OperationContext operationContext = session.createOperationContext();

            ItemIterable<CmisObject> children = folder.getChildren(operationContext);
            long totalSize = children.getTotalNumItems();

            Iterator<CmisObject> childItems = null;
            if (maxItemsPerPage > 0)
            {
                // just one page of results
                requestContext.addEventItem("getting up to " + maxItemsPerPage
                                            + " items starting at index "
                                            + skipCount);
                operationContext.setMaxItemsPerPage(maxItemsPerPage);
                ItemIterable<CmisObject> page = children.skipTo(skipCount).getPage();
                childItems = page.iterator();
            }
            else
            {
                // all the results
                requestContext.addEventItem("getting all children ");
                childItems = children.iterator();
            }
            while (childItems.hasNext())
            {
                CmisObject item = childItems.next();
                if (isFolder(item))
                {
                    results.add(new CMISFolderInfo((Folder)item));
                }
                else if (isDocument(item))
                {
                    results.add(new CMISDocumentInfo((Document)item));
                }
            }
            requestResult.setStartIndex(skipCount);
            requestResult.setTotalResultSize(totalSize);
            requestResult.setResults(results);
        }
        else
        {
            RequestContextEventItem item = new BasicRequestContextEventItem("Folder not found:" + folderPath);
            item.setReturnCode(RequestContextEventItem.FOLDER_NOT_FOUND);
            requestContext.addEventItem(item);
        }
        return requestResult;
    }
}
