/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.adapter.cmis.actions;

import java.util.ArrayList;
import java.util.List;

import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.commons.exceptions.CmisConstraintException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisObjectNotFoundException;

import com.lexisnexis.es.dms.adapter.cmis.CMISDocumentInfo;
import com.lexisnexis.es.dms.core.service.BasicRequestContextEventItem;
import com.lexisnexis.es.dms.core.service.DMSQueryAttributes;
import com.lexisnexis.es.dms.core.service.DMSRetrievalResult;
import com.lexisnexis.es.dms.core.transaction.DocumentRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestContextEventItem;
import com.lexisnexis.es.dms.core.transaction.RequestResult;
import com.lexisnexis.es.dms.core.transaction.RequestResultImpl;
import com.lexisnexis.es.dms.repository.actions.RetrieveDocumentsAction;

/**
 * cmis implementation to retrieve documents by id.<br/>
 * Fetch a set of documents based on the ids supplied in the context. <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class CmisRetrieveDocumentsByIdAction extends AbstractCmisRepositoryAction
                        implements RetrieveDocumentsAction
{

    /**
     * @param repository the repository instance which can interact with documents repository
     */
    public CmisRetrieveDocumentsByIdAction(final Repository repository)
    {
        super(repository);

    }

    /**
     * Fetch a set of documents based on the ids supplied in the context.
     * @param requestContext the current context
     * @return a list of retrieval results (never null)
     */
    @Override
    public RequestResult execute(final RequestContext requestContext)
    {
        List<RepositoryObject> results = new ArrayList<RepositoryObject>();
        Session session = repository.createSession();
        DMSQueryAttributes dmsqa = requestContext.getQueryAttributes();
        if (dmsqa != null)
        {
            List<String> docIds = dmsqa.getAttributes(DMSQueryAttributes.Type.DOCUMENT_ID);
            if (docIds.size() > 0)
            {
                for (String docId : docIds)
                {
                    if (docId != null)
                    {
                        DocumentRepositoryObject docInfo = retrieveDocumentById(requestContext,
                                                                                session,
                                                                                docId.trim());
                        results.add(new DMSRetrievalResult(docId, docInfo));
                    }
                }
            }
        }
        else
        {
            RequestContextEventItem item = new BasicRequestContextEventItem("ERROR: no attributes for document retrieval.");
            item.setReturnCode(RequestContextEventItem.MISSING_VALUE);
            requestContext.addEventItem(item);
        }
        RequestResultImpl result = new RequestResultImpl();
        result.setResults(results);
        return result;
    }

    /**
     * Fetch a document based on unique identifier
     * @param requestContext the current context
     * @param session the cmis session
     * @param docId the id of the required document
     * @return the requested document
     */
    public DocumentRepositoryObject retrieveDocumentById(final RequestContext requestContext,
                                                         final Session session,
                                                         final String docId)
    {
        CMISDocumentInfo returnVal = null;
        if (requestContext != null && session != null && docId != null)
        {
            CmisObject object = null;
            try
            {
                object = session.getObject(docId);
            }
            catch (CmisObjectNotFoundException confe)
            {
                requestContext.addEventItem("retrieveDocument(), object not found exception:" + docId);
            }
            catch (CmisConstraintException cce)
            {
                requestContext.addEventItem("retrieveDocument(), constraint exception:" + docId);
            }
            if (object != null)
            {
                if (isDocument(object))
                {
                    returnVal = new CMISDocumentInfo((Document)object);
                    requestContext.addEventItem("retrieveDocument(), document found:" + docId);
                }
                else
                {
                    requestContext.addEventItem("retrieveDocument(), object found but not a document:" + docId);
                }
            }
            else
            {
                RequestContextEventItem item = new BasicRequestContextEventItem("retrieveDocument(), doc not found:" + docId);
                item.setReturnCode(RequestContextEventItem.MISSING_VALUE);
                requestContext.addEventItem(item);
            }
        }
        else
        {
            // TODO an exception?
            requestContext.addEventItem("retrieveDocument(), invalid parameters.");
        }
        return returnVal;
    }
}
