package com.lexisnexis.es.dms.core.addressing;

import java.util.List;

/**
 * Encapsulates a path to a document or folder including repository identifier and location within the
 * repository. <br/>
 * <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author connorb
 * @version $Revision$
 * @since 1.4
 * 
 *        <pre>
 * $Id$
 * </pre>
 */
public interface DocumentPath
{

    /**
     * Return the document domain, eg "client", "finance".
     * @return The domain section, with no delimiters.
     */
    public String getDomain();

    /**
     * Gets the parts of the path that are used to look up information significant for routing.
     * @return Routing classifier path components. <code>null</code> if there are no classifiers defined for
     *         this domain.
     */
    public List<String> getRoutingClassifiers();

}