/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */
package com.lexisnexis.es.dms.core.security;

/**
 * First cut of credentials class - will need expansion! <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public interface Credentials
{

    /**
     * Gets the user id as a string
     * @return the user id as a string
     */
    public String getUserId();
}
