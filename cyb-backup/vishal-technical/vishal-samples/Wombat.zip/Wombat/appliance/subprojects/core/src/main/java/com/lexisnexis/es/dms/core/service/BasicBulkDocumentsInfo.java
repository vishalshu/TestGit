/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.service;

import java.util.ArrayList;
import java.util.List;

import com.lexisnexis.es.dms.core.transaction.BulkDocumentsInfo;
import com.lexisnexis.es.dms.core.transaction.DocumentInfo;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectLocation;

/**
 * Basic implementation of BulkDocumentInfo. <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class BasicBulkDocumentsInfo implements BulkDocumentsInfo
{

    /**
     * @see BasicBulkDocumentsInfo#getLocation()
     */
    private RepositoryObjectLocation location;

    /**
     * @see BasicBulkDocumentsInfo#getDocuments()
     */
    private List<DocumentInfo> documents;

    /**
     * the repository location where all the documents are created. <br>
     * NOTE: This method serves just as default location for all the documents inside. <i>getLocation()</i>
     * for each {@link DocumentInfo} object can be overridden.
     */
    @Override
    public RepositoryObjectLocation getLocation()
    {
        return location;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<DocumentInfo> getDocuments()
    {
        return documents;
    }

    /**
     * @see BasicBulkDocumentsInfo#getLocation()
     * @param location the location to set
     */
    public void setLocation(final RepositoryObjectLocation location)
    {
        this.location = location;
    }

    /**
     * @see BasicBulkDocumentsInfo#getDocuments()
     * @param documents the documents to set
     */
    public void setDocuments(final List<DocumentInfo> documents)
    {
        this.documents = documents;
    }

    /**
     * Add new document for bulk creation
     * @param document the document to be added
     */
    public void addDocument(final DocumentInfo document)
    {
        if (documents == null)
        {
            documents = new ArrayList<DocumentInfo>();
        }

        documents.add(document);
    }

}
