package com.lexisnexis.es.dms.core.service;

import java.lang.annotation.Inherited;

import com.lexisnexis.es.dms.core.transaction.RequestContext;

/**
 * An abstract implementation of the DmsService interface. <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public abstract class BasicDmsService implements DmsService
{

    /**
     * Whether this service instance is mandatory or not
     */
    private boolean mandatory;

    @Override
    public abstract DmsServiceResult process(RequestContext currentContext);

    /**
     * {@link Inherited}
     */
    @Override
    public boolean getMandatory()
    {
        return mandatory;
    }

    /**
     * {@link Inherited}
     */
    @Override
    public void setMandatory(final boolean mandatory)
    {
        this.mandatory = mandatory;
    }

}