/**
 * 
 */
package com.lexisnexis.es.dms.core.service;

import java.io.InputStream;

import com.lexisnexis.es.dms.core.transaction.DocumentDTO;
import com.lexisnexis.es.dms.core.transaction.DocumentRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectLocation;

/**
 * Simple implementation of @{link DocumentRepositoryObject} interface <br/>
 * <br/>
 * @see DocumentRepositoryObject <hr/>
 *      Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 *      <hr/>
 * @author omahonyj
 */

public class BasicDocumentRepositoryObject implements DocumentRepositoryObject, DocumentDTO
{

    /**
     * A unique identifier for this object within its repository
     */
    private String id;

    /**
     * the name of document instance of underlying repository
     */
    private String name;

    /**
     * the document location
     */
    private RepositoryObjectLocation location = null;

    /**
     * the name of the doc file
     */
    private String fileName = null;

    /**
     * the mime type
     */
    private String mimeType = null;

    /**
     * is the document versioned?
     */
    private boolean isVersioned = true;

    /**
     * is this a major version?
     */
    private boolean isMajorVersion = true;

    /**
     * the actual document contents
     */
    private InputStream contents = null;

    /**
     * the department for the document
     */
    private String department;

    /**
     * @see BasicDocumentRepositoryObject#id
     * @return the id
     */
    @Override
    public String getId()
    {
        return id;
    }

    /**
     * @see BasicDocumentRepositoryObject#id
     * @param id the id to set
     */
    public void setId(final String id)
    {
        this.id = id;
    }

    /**
     * @see BasicDocumentRepositoryObject#name
     * @return the name
     */
    @Override
    public String getName()
    {
        return name;
    }

    /**
     * @see BasicDocumentRepositoryObject#name
     * @param name the name to set
     */
    public void setName(final String name)
    {
        this.name = name;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RepositoryObjectLocation getLocation()
    {
        return location;
    }

    /**
     * @param location
     * @see BasicDocumentRepositoryObject#getLocation()
     */
    @Override
    public void setLocation(final RepositoryObjectLocation location)
    {
        this.location = location;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getDocumentFileName()
    {
        return fileName;
    }

    /**
     * @param name the name to set
     * @see BasicDocumentRepositoryObject#getDocumentFileName()
     */
    @Override
    public void setDocumentFileName(final String name)
    {
        this.fileName = name;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getMimeType()
    {
        return mimeType;
    }

    /**
     * @param mimeType the mimeType to set
     * @see BasicDocumentRepositoryObject#getMimeType()
     */
    @Override
    public void setMimeType(final String mimeType)
    {
        this.mimeType = mimeType;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isVersioned()
    {
        return isVersioned;
    }

    /**
     * @param isVersioned the isVersioned to set
     * @see BasicDocumentRepositoryObject#isVersioned()
     */
    @Override
    public void setVersioned(final boolean isVersioned)
    {
        this.isVersioned = isVersioned;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isMajorVersion()
    {
        return isMajorVersion;
    }

    /**
     * @param isMajorVersion the isMajorVersion to set
     * @see BasicDocumentRepositoryObject#isMajorVersion()
     */
    @Override
    public void setMajorVersion(final boolean isMajorVersion)
    {
        this.isMajorVersion = isMajorVersion;

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public InputStream getContent()
    {
        return contents;
    }

    /**
     * @param contents the contents to set
     * @see BasicDocumentRepositoryObject#getContent()
     */
    @Override
    public void setContent(final InputStream contents)
    {
        this.contents = contents;

    }

    /**
     * @param department the department to set
     */
    public void setDepartment(final String department)
    {
        this.department = department;
    }

    /**
     * @return the department
     */
    public String getDepartment()
    {
        return department;
    }

}
