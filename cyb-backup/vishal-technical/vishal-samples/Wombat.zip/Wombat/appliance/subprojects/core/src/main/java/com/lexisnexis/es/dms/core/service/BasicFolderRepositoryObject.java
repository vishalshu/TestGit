/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.service;

import com.lexisnexis.es.dms.core.transaction.FolderRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectLocation;

/**
 * Simple implementation of @{link FolderRepositoryObject} interface <br/>
 * <br/>
 * @see FolderRepositoryObject <br/>
 *      <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class BasicFolderRepositoryObject implements FolderRepositoryObject
{

    /** @see BasicFolderRepositoryObject#getId() */
    private String id;

    /** @see BasicFolderRepositoryObject#name */
    private String name;

    /** @see BasicFolderRepositoryObject#isRootFolder() */
    private boolean isRootFolder = false;

    /** @see BasicFolderRepositoryObject#getLocation() */
    private RepositoryObjectLocation location;

    /**
     * @param isRootFolder the isRootFolder to set
     */
    public void setRootFolder(final boolean isRootFolder)
    {
        this.isRootFolder = isRootFolder;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getId()
    {
        return id;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName()
    {

        return name;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isRootFolder()
    {
        return isRootFolder;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RepositoryObjectLocation getLocation()
    {
        return location;
    }

    /**
     * @param location the location to set
     */
    public void setLocation(final RepositoryObjectLocation location)
    {
        this.location = location;
    }

    /**
     * @param id the id to set
     */
    public void setId(final String id)
    {
        this.id = id;
    }

    /**
     * @param name the name to set
     */
    public void setName(final String name)
    {
        this.name = name;
    }

}
