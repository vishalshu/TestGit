package com.lexisnexis.es.dms.core.service;

import java.util.ArrayList;
import java.util.List;

import com.lexisnexis.es.dms.core.security.Credentials;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectInfo;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestContextEvent;
import com.lexisnexis.es.dms.core.transaction.RequestContextEventItem;
import com.lexisnexis.es.dms.core.transaction.RequestResult;

/**
 * An abstract superclass which handles the common bits of the RequestContext interface <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public abstract class BasicRequestContext implements RequestContext
{

    /**
     * a collection of events associated with this request
     */
    private List<RequestContextEvent> events;

    /**
     * the object containing info about the document
     */
    private RepositoryObjectInfo repoObjectInfo;

    /**
     * the object representing the dms action the user is trying to perform
     */
    private RequestType requestType;

    /**
     * the credentials of the user
     */
    private Credentials userCredentials;

    /**
     * the objecting holding attributes that represent a request from the user
     */
    private DMSQueryAttributes queryAttributes;

    /**
     * Object holding the reults of the user request
     */
    private RequestResult requestResult;

    /**
     * {@inheritDoc}
     */
    @Override
    public List<RequestContextEvent> getEvents()
    {
        return events;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addEvent(final RequestContextEvent event)
    {
        if (events == null)
        {
            events = new ArrayList<RequestContextEvent>();
        }
        events.add(event);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addEventItem(final String eventIdentifier, final RequestContextEventItem eventItem)
    {
        if (eventItem != null && eventIdentifier != null)
        {
            RequestContextEvent theEvent = getEvent(eventIdentifier);
            if (theEvent == null)
            {

                theEvent = new BasicRequestContextEvent(eventIdentifier);
                addEvent(theEvent);
            }
            theEvent.addEventItem(eventItem);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addEventItem(final String eventIdentifier, final String eventDescription)
    {
        if (eventDescription != null)
        {
            RequestContextEventItem eventItem = new BasicRequestContextEventItem(eventDescription);
            addEventItem(eventIdentifier, eventItem);
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addEventItem(final RequestContextEventItem eventItem)
    {
        RequestContextEvent currentEvent = getCurrentEvent();
        if (currentEvent != null && eventItem != null)
        {
            addEventItem(currentEvent.getIdentifier(), eventItem);
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestContextEvent getEvent(final String id)
    {
        if (id != null && events != null)
        {
            for (RequestContextEvent event : events)
            {
                if (id.equals(event.getIdentifier()))
                {
                    return event;
                }
            }
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestContextEvent getCurrentEvent()
    {
        if (events != null && events.size() > 0)
        {
            return events.get(events.size() - 1);
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addEventItem(final String eventDescription)
    {
        RequestContextEvent currentEvent = getCurrentEvent();
        if (eventDescription != null && currentEvent != null)
        {
            addEventItem(currentEvent.getIdentifier(), eventDescription);
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RepositoryObjectInfo getRepositoryObjectInfo()
    {
        return repoObjectInfo;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setRepositoryObjectInfo(final RepositoryObjectInfo info)
    {
        repoObjectInfo = info;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestType getRequestType()
    {
        return requestType;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setRequestType(final RequestType type)
    {
        requestType = type;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Credentials getUserCredentials()
    {
        // TODO Auto-generated method stub
        return userCredentials;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setUserCredentials(final Credentials credentials)
    {
        userCredentials = credentials;

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public DMSQueryAttributes getQueryAttributes()
    {
        return queryAttributes;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setQueryAttributes(final DMSQueryAttributes queryAttributes)
    {
        this.queryAttributes = queryAttributes;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestResult getRequestResult()
    {
        return requestResult;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setRequestResult(final RequestResult result)
    {
        requestResult = result;

    }

}