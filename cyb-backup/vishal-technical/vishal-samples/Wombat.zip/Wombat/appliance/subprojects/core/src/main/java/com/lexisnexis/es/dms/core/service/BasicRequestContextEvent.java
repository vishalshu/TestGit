/**
 * 
 */
package com.lexisnexis.es.dms.core.service;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.lexisnexis.es.dms.core.transaction.RequestContextEvent;
import com.lexisnexis.es.dms.core.transaction.RequestContextEventItem;

/**
 * A basic implementation of the requestContextEvent interface. Used for recording events during service
 * invocation. It is intended that there be one event object per service invocation. Each recordable item is
 * reguistered as a RequestContextEventItem on the event. <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */

public class BasicRequestContextEvent implements RequestContextEvent
{

    /**
     * an identifier for this event
     */
    private final String id;

    /**
     * a description of the event
     */
    private final String description;

    /**
     * start timestamp
     */
    private final Date startTime;

    /**
     * end timestamp
     */
    private Date endTime;

    /**
     * list of items recorded against this event
     */
    private List<RequestContextEventItem> eventItems;

    /**
     * Constructor for this event, takes a String (the identifier of a service). This object will then be used
     * to record significant occurrences in the life-span of the service.
     * @param serviceIdentifier the identifier of the service this event is being created for
     */
    public BasicRequestContextEvent(final String serviceIdentifier)
    {
        startTime = new Date();
        id = serviceIdentifier;
        description = serviceIdentifier + " event";
        addEventItem(new BasicRequestContextEventItem(getDescription() + " initiated"));
    }

    /**
     * Constructor for this event, takes a DmsService. This object will then be used to record significant
     * occurences in the lifespan of the service
     * @param service the service this event is being created for
     */
    public BasicRequestContextEvent(final DmsService service)
    {
        startTime = new Date();
        id = service.getClass().getName();
        description = service.getClass().getName() + " event";
        addEventItem(new BasicRequestContextEventItem(getDescription() + " initiated"));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getIdentifier()
    {
        return id;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getDescription()
    {
        return description;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Date getStartTime()
    {
        return startTime;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Date getEndTime()
    {
        return endTime;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long getDuration()
    {
        if (endTime != null)
        {
            return endTime.getTime() - startTime.getTime();
        }
        return new Date().getTime() - startTime.getTime();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<RequestContextEventItem> getEventItems()
    {
        return eventItems;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stop()
    {
        endTime = new Date();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addEventItem(final RequestContextEventItem item)
    {
        if (item != null)
        {
            if (eventItems == null)
            {
                eventItems = new ArrayList<RequestContextEventItem>();
            }
            eventItems.add(item);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getReport()
    {
        long duration = getDuration();
        String indent = "    ";
        String newline = System.getProperty("line.separator");
        StringBuilder sb = new StringBuilder();
        sb.append(newline);
        sb.append("Event identifier:");
        sb.append(getIdentifier());
        sb.append(newline);
        for (RequestContextEventItem item : eventItems)
        {
            sb.append(indent);
            sb.append(item.getItemReport());
            sb.append(newline);
        }
        sb.append(indent);
        sb.append("event duration=");
        double seconds = ((double)duration) / 1000;
        DecimalFormat myFormatter = new DecimalFormat("###,###,##0.000");
        sb.append(myFormatter.format(seconds));
        sb.append("s.");

        return sb.toString();
    }
}
