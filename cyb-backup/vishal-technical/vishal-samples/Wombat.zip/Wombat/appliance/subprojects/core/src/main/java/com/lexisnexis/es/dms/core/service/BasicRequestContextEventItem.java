/**
 * 
 */
package com.lexisnexis.es.dms.core.service;

import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.lexisnexis.es.dms.core.transaction.RequestContextEventItem;

/**
 * Basic implementation of the event item interface. Captures events with automatic timestamp. <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */

public class BasicRequestContextEventItem implements RequestContextEventItem
{

    /**
     * A return code
     */
    private int returnCode = HttpURLConnection.HTTP_OK;

    /**
     * a description for this item
     */
    private final String description;

    /**
     * a creation timestamp
     */
    private final Date createTime;

    /**
     * creates a new event item with the given description.
     * @param description the description for the item
     */
    public BasicRequestContextEventItem(final String description)
    {
        createTime = new Date();
        if (description != null)
        {
            this.description = description;
        }
        else
        {
            this.description = "no description set";
        }
    }

    /*
     * (non-Javadoc)
     * @see com.lexisnexis.es.dms.transaction.RequestContextEventItem#getReturnCode()
     */
    @Override
    public int getReturnCode()
    {
        return returnCode;
    }

    /*
     * (non-Javadoc)
     * @see com.lexisnexis.es.dms.transaction.RequestContextEventItem#getDescription()
     */
    @Override
    public String getDescription()
    {
        return description;
    }

    /*
     * (non-Javadoc)
     * @see com.lexisnexis.es.dms.transaction.RequestContextEventItem#getEventItemSuccess()
     */
    @Override
    public boolean getEventItemSuccess()
    {
        return !isError();
    }

    /**
     * Determines whether the result code is in the range defined as 'errors'
     * @return true if the result code is an error
     */
    public boolean isError()
    {
        return returnCode >= LOWER_ERROR_THRESHOLD && returnCode <= UPPER_ERROR_THRESHOLD;
    }

    /*
     * (non-Javadoc)
     * @see com.lexisnexis.es.dms.transaction.RequestContextEventItem#getEventItemCreateTime()
     */
    @Override
    public Date getEventItemCreateTime()
    {
        return createTime;
    }

    @Override
    public void setReturnCode(final int code)
    {
        returnCode = code;
    }

    @Override
    public String getItemReport()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("Item:");
        sb.append(getDescription());
        sb.append(", returnCode:");
        sb.append(getReturnCode());
        sb.append(", createTime:");
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss:S");
        sb.append(sdf.format(getEventItemCreateTime()));
        return sb.toString();
    }

}
