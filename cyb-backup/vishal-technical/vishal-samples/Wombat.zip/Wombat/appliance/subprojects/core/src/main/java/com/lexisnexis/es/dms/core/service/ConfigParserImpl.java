/**
 * 
 */
package com.lexisnexis.es.dms.core.service;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.lexisnexis.es.dms.core.util.ConfigParser;
import com.lexisnexis.es.dms.core.util.LNConfigurationException;
import com.lexisnexis.es.dms.core.util.XMLReader;

/**
 * This class aim to extract the 'service' section from the config file.
 * @author KaleJ
 */
public class ConfigParserImpl implements ConfigParser
{

    /**
     * name of element containing services
     */
    public final static String SERVICES_SECTION = "service";

    /** Top level document node for the XML file. */
    final Document doc;

    /**
     * name of element containing request service order
     */
    public final static String REQUEST_LIST = "item";

    /**
     * @param fileLocation the file location as a string
     * @throws LNConfigurationException a configuration issue
     */
    public ConfigParserImpl(final String fileLocation) throws LNConfigurationException
    {
        XMLReader xmlRead = new XMLReader();
        doc = xmlRead.getDocument(fileLocation);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NodeList readSection(final String sectionName)
    {
        return doc.getDocumentElement().getElementsByTagName(sectionName);
    }
}
