/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Holds a map of type to list, i.e. for any given type we can hold a list of string values.<br>
 * <code>
 * <pre>
 * Example:
 *  DMSQueryAttributes attrs = new  DMSQueryAttributes();
 *  attrs.addAttribute(DMSQueryAttributes.Type.DOCUMENT_ID, "12345");
 *  attrs.addAttribute(DMSQueryAttributes.Type.DOCUMENT_ID, "76543");
 *  </pre>
 * </code> <code>attrs.getAttributes(DMSQueryAttributes.TYPE.DOCUMENT_ID)</code> will now return a list of 2
 * items: ["12345","76543"] <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class DMSQueryAttributes
{
    /** a map of attributes and values for the query */
    private Map<Type, List<String>> attributeMap = null;

    /**
     * An enum of all the different things we might request/search on
     */
    public enum Type
    {
        /** the unique id of a document */
        DOCUMENT_ID
    }

    /**
     * 
     */
    public DMSQueryAttributes()
    {
        // TODO Auto-generated constructor stub
    }

    /**
     * @param attributeMap
     */
    public DMSQueryAttributes(final Map<Type, List<String>> attributeMap)
    {
        super();
        this.attributeMap = attributeMap;
    }

    /**
     * Gets the map of attributes. If the map does not exist it will be created.
     * @return an attribute map, never null
     */
    private Map<Type, List<String>> getMap()
    {
        if (attributeMap == null)
        {
            attributeMap = new HashMap<Type, List<String>>();
        }
        return attributeMap;
    }

    /**
     * gets the list of attributes associated with a particular type. If the list does not currently exist an
     * empty list will be created, added to the map, and returned to the caller.
     * @param type the type of the required attribute(s)
     * @return the list of attributes of that type
     */
    public List<String> getAttributes(final Type type)
    {
        List<String> attributes = getMap().get(type);
        if (attributes == null)
        {
            attributes = new ArrayList<String>();
            getMap().put(type, attributes);
        }
        return attributes;
    }

    /**
     * adds an attribute to the list associated with the specified type.
     * @param type the type of the attribute
     * @param attributeValue the value of the attribute
     */
    public void addAttribute(final Type type, final String attributeValue)
    {
        getAttributes(type).add(attributeValue);
    }

    /**
     * adds a list of attributes to the list associated with the specified type.
     * @param type the type of the attribute
     * @param attributeValues a list of values
     */
    public void addAttributes(final Type type, final List<String> attributeValues)
    {
        getAttributes(type).addAll(attributeValues);
    }

    /**
     * removes the list of attributes associated with the specified type from the map.
     * @param type the type of the attribute
     */
    public void removeAttributes(final Type type)
    {
        getMap().remove(type);
    }

}
