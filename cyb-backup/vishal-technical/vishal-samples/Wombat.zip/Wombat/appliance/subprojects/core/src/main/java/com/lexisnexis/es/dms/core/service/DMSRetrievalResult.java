/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.service;

import com.lexisnexis.es.dms.core.transaction.DocumentRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RepositoryObject;

/**
 * Represents the outcome of an attempt to retrieve a document (by its id). <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class DMSRetrievalResult implements RepositoryObject
{
    /** The id of the document that was being retrieved */
    private String id = null;

    /** the retrieved document */
    private DocumentRepositoryObject docInfo = null;

    /**
     * Constructor for the result object
     * @param docId the id of the document (must not be null)
     * @param docInfo the document that was found (may be null if no doc found)
     */
    public DMSRetrievalResult(final String docId, final DocumentRepositoryObject docInfo)
    {
        assert (docId != null);
        id = docId;
        this.docInfo = docInfo;
    }

    /**
     * Whether the document with the specified id was found
     * @return true if the document was found
     */
    public boolean isFound()
    {
        return docInfo != null;
    }

    /**
     * @return the id of the document that was being retrieved. Never null.
     */
    @Override
    public String getId()
    {
        return id;
    }

    /**
     * @return the document that was retrieved. (may be null)
     */
    public DocumentRepositoryObject getDocumentRepositoryObject()
    {
        return docInfo;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName()
    {
        if (docInfo != null)
        {
            return docInfo.getDocumentFileName();
        }
        return null;
    }
}
