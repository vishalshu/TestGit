package com.lexisnexis.es.dms.core.service;

import com.lexisnexis.es.dms.core.transaction.RequestContext;

/**
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author connorb
 */
public interface DmsService
{

    /**
     * invokes the service with the supplied context.
     * @param currentContext the current request context
     * @return true if it is OK to continue with the next service
     */
    public DmsServiceResult process(RequestContext currentContext);

    /**
     * check whether this service instance is mandatory or not
     * @return the mandatory
     */
    public boolean getMandatory();

    /**
     * set the attribute for whether this service instance is mandatory or not
     * @param mandatory the mandatory to set
     */
    public void setMandatory(boolean mandatory);
}
