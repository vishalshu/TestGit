package com.lexisnexis.es.dms.core.service;

/**
 * This class maintains all the static constants and attributes required by the {@link DmsService}. Each of
 * the {@link DmsService} implementation must include this going forward. This was specifically done to keep
 * all the attributes in one place.
 * @author kalej
 */
public class DmsServiceAttributes
{

    /** Attribute name */
    public static final String ATTR_NAME = "name";

    /** Attribute class */
    public static final String ATTR_CLASS = "class";

    /** Attribute mandatory */
    public static final String ATR_MANDATORY = "mandatory";

    /** Name Attribute value: routing */
    public static final String ROUTING_SERVICE = "routing";

    /** Name Attribute value: repository */
    public static final String REPOSITORY_SERVICE = "repository";

    /** Name Attribute value: audit */
    public static final String AUDIT_SERVICE = "audit";

    /** Name Attribute value: migrator */
    public static final String MIGRATOR_SERVICE = "migrator";

    /** Name Attribute value: licence */
    public static final String LICENCE_SERVICE = "licence";

    /** Name Attribute value: security */
    public static final String SECURITY_SERVICE = "security";

    /** Is the process mandatory, so it will always be invoked irrespective of other prior to it fail */
    private final boolean mandatory;

    /** IThe name of the service */
    private String name;

    /**
     * @param mandatory whether the service is mandatory (in the context of a request)
     * @param name the name of the service
     * @param serviceClass the implementing class
     */
    public DmsServiceAttributes(final boolean mandatory, final String name, final String serviceClass)
    {
        super();
        this.mandatory = mandatory;
        this.name = name;
        this.serviceClass = serviceClass;
    }

    /**
     * Default constructor
     * @param mandatory the mandatory to set
     */
    public DmsServiceAttributes(final boolean mandatory)
    {
        this.mandatory = mandatory;
    }

    /**
     * the class that implements the service
     */
    private String serviceClass;

    /**
     * @return a string representing the class that implements the service
     */
    public String getServiceClass()
    {
        return serviceClass;
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @return the mandatory
     */
    public boolean isMandatory()
    {
        return mandatory;
    }

}