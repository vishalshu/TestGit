package com.lexisnexis.es.dms.core.service;

import java.util.List;

/**
 * <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public interface DmsServiceResult
{

    /**
     * @return true if actions in this service were successful and service processing can continue
     */
    public boolean isSuccess();

    /**
     * Contains more services that need to be processed before continuing with 'normal service'
     * @return a container referencing additional services to be processed. may be null.
     */
    public List<DmsService> getAdditionalServices();
}
