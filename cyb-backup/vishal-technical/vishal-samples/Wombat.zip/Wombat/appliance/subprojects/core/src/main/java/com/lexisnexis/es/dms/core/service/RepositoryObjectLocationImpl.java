/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.service;

import java.util.List;

import com.lexisnexis.es.dms.core.transaction.RepositoryObjectLocation;

/**
 * A simple implementation of the RepositoryObjectLocation interface <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class RepositoryObjectLocationImpl implements RepositoryObjectLocation
{

    /** the logical path for this document within the repository */
    private String logicalPath = null;

    /** the list of potential repositories for this document */
    private List<String> repositoryList = null;

    /**
     * @param docPath the logical path for this document within the repository
     */
    public RepositoryObjectLocationImpl(final String docPath)
    {
        this.logicalPath = docPath;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getLogicalPath()
    {
        return logicalPath;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getTargetRepository()
    {
        if (repositoryList != null)
        {
            return repositoryList.get(0);
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<String> getRepositoryList()
    {
        return repositoryList;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setRepositoryList(final List<String> repositories)
    {
        this.repositoryList = repositories;
    }

}
