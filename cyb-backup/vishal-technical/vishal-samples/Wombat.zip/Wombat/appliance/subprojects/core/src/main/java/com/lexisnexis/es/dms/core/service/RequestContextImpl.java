/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.service;

import com.lexisnexis.es.dms.core.security.Credentials;
import com.lexisnexis.es.dms.core.transaction.DocumentInfo;

/**
 * Simple implementation of a RequestContext <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class RequestContextImpl extends BasicRequestContext
{

    /**
     * Returns an incomplete RequestContext
     */
    public RequestContextImpl()
    {
        // anything we need to do here?
    }

    /**
     * Initialises the RequestContext
     * @param docInfo the document information
     * @param operation the task the user is trying to perform
     * @param credentials the credentials of the requesting user
     */
    public RequestContextImpl(final DocumentInfo docInfo,
                              final RequestType operation,
                              final Credentials credentials)
    {
        this();
        setRepositoryObjectInfo(docInfo);
        setUserCredentials(credentials);
        setRequestType(operation);
    }

}
