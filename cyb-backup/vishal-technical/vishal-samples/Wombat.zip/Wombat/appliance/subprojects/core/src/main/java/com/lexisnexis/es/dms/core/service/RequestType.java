/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */
package com.lexisnexis.es.dms.core.service;

/**
 * All possible operations that can be requested <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public enum RequestType
{
    /** add a new document to the repository */
    NEW_DOCUMENT,
    /** add new bulk documents to the repository */
    NEW_BULK_DOCUMENTS,
    /** add a new version of an existing document to the repository */
    CHECKIN_NEW_VERSION,
    /** get (latest?) version of an existing document from the repository and lock it */
    CHECKOUT_VERSION,
    /** get copies of specified documents without locking (read only?) */
    VIEW_DOCUMENTS,
    /** change the contents (or metadata) of a version of a document (without changing version) */
    MODIFY_VERSION,
    /** move the document from one location to another (all versions?) */
    MOVE_DOCUMENT,
    /** delete a document version (last version only?) */
    DELETE_VERSION,
    /** delete all versions of a document */
    DELETE_DOCUMENT,
    /** search for documents which match specified criteria */
    DOCUMENT_SEARCH,
    /** create a new (logical) folder in the hierarchy */
    CREATE_FOLDER,
    /** get the contents of a (logical) folder in the hierarchy */
    LIST_FOLDER_CONTENTS
}
