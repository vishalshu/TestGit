package com.lexisnexis.es.dms.core.service;

import java.util.List;

/**
 * An implementation of the DmsServiceResult Interface returned when a DmsService is processed. <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */

public class ServiceResult implements DmsServiceResult
{
    /**
     * holds whether the service was successfully processed
     */
    private boolean success = false;

    /**
     * The additional services that should now be processed as a result of processing this service
     */
    private List<DmsService> services = null;

    /**
     * create a new result object with success indicator an any additional services to be processed.
     * @param result true if the current service finished without issues.
     * @param moreServices additional services to be processed before continuing.
     */
    public ServiceResult(final boolean result, final List<DmsService> moreServices)
    {
        success = result;
        services = moreServices;
    }

    /*
     * (non-Javadoc)
     * @see com.lexisnexis.es.dms.service.DmsServiceResult#isSuccess()
     */
    @Override
    public boolean isSuccess()
    {
        return success;
    }

    /*
     * (non-Javadoc)
     * @see com.lexisnexis.es.dms.service.DmsServiceResult#getAdditionalServices()
     */
    @Override
    public List<DmsService> getAdditionalServices()
    {
        return services;
    }

}
