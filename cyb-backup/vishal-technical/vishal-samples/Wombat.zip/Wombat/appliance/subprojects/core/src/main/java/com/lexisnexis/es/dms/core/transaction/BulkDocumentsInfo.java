/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.transaction;

import java.util.List;

/**
 * Abstraction for creating bulk documents in the repository. Handling bulk documents in separate action class
 * seems better with performance perspective, because we don't require to create separate result object for
 * each document instance.<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 */

public interface BulkDocumentsInfo extends RepositoryObjectInfo
{
    /**
     * Get the documents which need to be created or which are created in the repository
     * @return list of documents
     */
    List<DocumentInfo> getDocuments();
}
