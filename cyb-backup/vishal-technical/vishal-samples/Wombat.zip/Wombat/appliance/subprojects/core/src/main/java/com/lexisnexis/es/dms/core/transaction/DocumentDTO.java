/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.transaction;

import java.io.InputStream;

/**
 * An extension to the DocumentInfo interface which supports setting the values <br/>
 * <br/>
 * <hr/>
 * @author OMahonyJ
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public interface DocumentDTO extends DocumentInfo
{
    /**
     * @param location the location of the document
     */
    public void setLocation(RepositoryObjectLocation location);

    /**
     * @param name the name of the document file
     */
    public void setDocumentFileName(String name);

    /**
     * @param mimeType the mime type of the document
     */
    public void setMimeType(String mimeType);

    /**
     * @param isVersioned true if the document is versioned
     */
    public void setVersioned(boolean isVersioned);

    /**
     * @param isMajorVersion true if this is a new Major version
     */
    public void setMajorVersion(boolean isMajorVersion);

    /**
     * @param contents the contents of the document
     */
    public void setContent(InputStream contents);
}
