package com.lexisnexis.es.dms.core.transaction;

import java.io.InputStream;

/**
 * Interface defining what a document offers <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public interface DocumentInfo extends RepositoryObjectInfo
{

    /**
     * @return the name of the document file
     */
    public String getDocumentFileName();

    /**
     * @return the mime type of the document
     */
    public String getMimeType();

    /**
     * @return true if the document is versioned
     */
    public boolean isVersioned();

    /**
     * @return true if this is a new Major version
     */
    public boolean isMajorVersion();

    /**
     * @return the contents of the document
     */
    public InputStream getContent();

}
