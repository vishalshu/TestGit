/**
 * 
 */
package com.lexisnexis.es.dms.core.transaction;

/**
 * Abstract factory interface to be implemented by all the concrete DocumentInfoFactory classes
 * @author vishalshu
 */
public interface DocumentInfoFactory
{

    /**
     * Create concrete DocumentInfo objects that may be specific to the name-space.
     * @return documentInfo
     */
    DocumentInfo getDocumentInfo();
}
