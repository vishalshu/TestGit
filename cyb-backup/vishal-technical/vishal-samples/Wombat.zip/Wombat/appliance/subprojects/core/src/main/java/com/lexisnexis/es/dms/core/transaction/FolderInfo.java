/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.transaction;

/**
 * An interface representing a logical folder in the dms. <br/>
 * <br/>
 * <hr/>
 * @author OMahonyJ
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public interface FolderInfo extends RepositoryObjectInfo
{

    /**
     * Returns if the folder is the root folder.
     * @return true if this is the root folder
     */
    boolean isRootFolder();

}
