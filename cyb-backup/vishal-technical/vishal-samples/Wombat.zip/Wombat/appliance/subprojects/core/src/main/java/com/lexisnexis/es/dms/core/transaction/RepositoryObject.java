/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.transaction;

/**
 * An interface representing objects in a document repository <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public interface RepositoryObject
{
    /**
     * @return A unique identifier for this object within its repository
     */
    public String getId();

    /**
     * @return the name of the object
     */
    public String getName();
}
