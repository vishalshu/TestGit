/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.transaction;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public interface RepositoryObjectInfo
{
    /**
     * A reference to the location of the repository object
     * @return the location of the repository object
     */
    public RepositoryObjectLocation getLocation();

}
