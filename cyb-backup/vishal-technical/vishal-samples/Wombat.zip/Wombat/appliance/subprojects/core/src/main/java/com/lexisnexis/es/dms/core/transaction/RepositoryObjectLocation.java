/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */
package com.lexisnexis.es.dms.core.transaction;

import java.util.List;

/**
 * Encapsulates the location(s) of a document. Both the logical location within the repository, and the list
 * of potential repositories that the document may be in. <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */
public interface RepositoryObjectLocation
{

    /**
     * @return the logical path of the document within the repository
     */
    public String getLogicalPath();

    /**
     * The name of the repository where the document SHOULD be (or should end up)
     * @return the name of the target repository
     */
    public String getTargetRepository();

    /**
     * The list of repositories where the document MIGHT be.
     * @return a list of repository names
     */
    public List<String> getRepositoryList();

    /**
     * sets the list of repositories where the document MIGHT be.
     * @param repositories a list of repository names
     */
    public void setRepositoryList(List<String> repositories);

}
