package com.lexisnexis.es.dms.core.transaction;

import java.util.List;

import com.lexisnexis.es.dms.core.security.Credentials;
import com.lexisnexis.es.dms.core.service.DMSQueryAttributes;
import com.lexisnexis.es.dms.core.service.RequestType;

/**
 * The fundamental core of the server process. All relevant information required by a service is obtained from
 * a RequestContext. <br/>
 * NOTE: Can changes this interface to make it use generic type for RepositoryObjectInfo or can make
 * set/getRepositoryObjectInfo methods generic.
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public interface RequestContext
{

    /**
     * A record of the 'events' in the life of this request. It is anticipated that each service called by the
     * request will have a corresponding event. this even will contain log style items of interest that happen
     * during the lifetime of the event Each item of interest is a RequestContestEventItem
     * @return a list of events
     * @see RequestContextEvent
     * @see RequestContextEventItem
     */
    public List<RequestContextEvent> getEvents();

    /**
     * The Credentials of the current user.
     * @return the credentials
     */
    public Credentials getUserCredentials();

    /**
     * The operation the user is requesting, what they are trying to do.
     * @return the RequestType from the user
     */
    public RequestType getRequestType();

    /**
     * The operation the user is requesting, what they are trying to do.
     * @param type the RequestType from the user
     */
    public void setRequestType(RequestType type);

    /**
     * This won't be a String, will change later
     * @param credentials the credentials
     */
    public void setUserCredentials(Credentials credentials);

    /**
     * Add an event to the context
     * @param event the event to add
     */
    public void addEvent(RequestContextEvent event);

    /**
     * Add an event item to an event in the context
     * @param eventIdentifier a string which identifies the event. Not null, if it doesn't exist, it will be
     *            created
     * @param eventItem the event item to add. If Null, nothing will be created
     */
    public void addEventItem(String eventIdentifier, RequestContextEventItem eventItem);

    /**
     * Add an event item to the current event in the context
     * @param eventItem the event item to add. If Null, or current event is null, nothing will be created
     */
    public void addEventItem(RequestContextEventItem eventItem);

    /**
     * Add an event item to an event in the context
     * @param eventIdentifier a string which identifies the event. Not null, if it doesn't exist, it will be
     *            created
     * @param eventDescription a description of the event item (something useful for later examination in the
     *            event of a problem). If Null, nothing will be created
     */
    public void addEventItem(String eventIdentifier, String eventDescription);

    /**
     * Add an event item to the current event
     * @param eventDescription a description of the event item (something useful for later examination in the
     *            event of a problem). If Null, nothing will be created
     */
    public void addEventItem(String eventDescription);

    /**
     * Get an event from the context
     * @param id the event id
     * @return the event object
     */
    public RequestContextEvent getEvent(String id);

    /**
     * Get the current event from the context
     * @return the event object
     */
    public RequestContextEvent getCurrentEvent();

    /**
     * Gets the object which encapsulates document information
     * @return the document information
     */
    public RepositoryObjectInfo getRepositoryObjectInfo();

    /**
     * Sets the object which encapsulates document information
     * @param info the document information
     */
    public void setRepositoryObjectInfo(RepositoryObjectInfo info);

    /**
     * Gets the object which encapsulates query information
     * @return the query attributes
     */
    public DMSQueryAttributes getQueryAttributes();

    /**
     * Sets the object which encapsulates query information
     * @param info the query attributes
     */
    public void setQueryAttributes(DMSQueryAttributes info);

    /**
     * gets the wrapper object that holds the results of the user action
     * @return the request result
     */
    public RequestResult getRequestResult();

    /**
     * sets the wrapper object that holds the results of the user action
     * @param result the request result
     */
    public void setRequestResult(RequestResult result);
}
