package com.lexisnexis.es.dms.core.transaction;

import java.util.Date;
import java.util.List;

/**
 * Records information about an event associated with a RequestContext. e.g. what happened when a particular
 * service was processed. <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */

public interface RequestContextEvent
{

    /**
     * An identifier for this event
     * @return the identifier of the event
     */
    public String getIdentifier();

    /**
     * A human readable description for this event, e.g. "processing of security service".
     * @return the description of the event
     */
    public String getDescription();

    /**
     * gets the system time when the event started. never null.
     * @return the time the event started
     */
    public Date getStartTime();

    /**
     * gets the system time when the event finished (null if the event is ongoing)
     * @return the time the event ended
     */
    public Date getEndTime();

    /**
     * gets the duration in milliseconds of the event. If the event has not finished it will return how long
     * it has taken so far.
     * @return the duration of the event
     */
    public long getDuration();

    /**
     * A collection of Items involved in this event, essentially a list of things that we wished to record
     * during the lifetime of the event
     * @return the event items
     */
    public List<RequestContextEventItem> getEventItems();

    /**
     * sets the endTime of the event.
     */
    public void stop();

    /**
     * Adds an event item to the event.
     * @param item the new item
     */
    public void addEventItem(RequestContextEventItem item);

    /**
     * gets a string report of the items recorded against the event
     * @return a summary of the items in this event
     */
    public String getReport();

}
