package com.lexisnexis.es.dms.core.transaction;

import java.net.HttpURLConnection;
import java.util.Date;

/**
 * An item or step in the process of an 'event' (RequestContextEvent) <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 * @see RequestContextEvent
 */

public interface RequestContextEventItem
{

    /**
     * indicates which results code are errors. Numbers greater than or equal to this are errors (subject to
     * upper limit)
     */
    public static int LOWER_ERROR_THRESHOLD = 400;

    /**
     * indicates which results code are errors. Numbers less than or equal to this are errors (subject to
     * lower limit)
     */
    public static int UPPER_ERROR_THRESHOLD = Integer.MAX_VALUE;

    /**
     * Error code to use when a user is creating a document that already exists
     */
    public static int DOCUMENT_ALREADY_EXISTS = HttpURLConnection.HTTP_CONFLICT;

    /**
     * Error code to use when repository not found
     */
    public static int NO_REPOSITORY = HttpURLConnection.HTTP_GONE;

    /**
     * Error code to use when an action has been requested that the system does not know how to implement
     */
    public static int UNIMPLEMENTED_REQUEST_TYPE = 551;

    /**
     * Error code to use when a value is required but not supplied
     */
    public static int MISSING_VALUE = 552;

    /**
     * Error code to use when a document is not found (that should exist)
     */
    public static int DOCUMENT_NOT_FOUND = HttpURLConnection.HTTP_NOT_FOUND;

    /**
     * Error code to use when a document is not found (that should exist)
     */
    public static int FOLDER_NOT_FOUND = HttpURLConnection.HTTP_NOT_FOUND;

    /**
     * Error code to use when a repository configuration is not valid
     */
    public static int INVALID_CONFIG = 553;

    /**
     * A return code for this event item. A non zero code indicates an error;
     * @return the return code
     */
    public int getReturnCode();

    /**
     * Sets the return code
     * @param code the return code
     */
    public void setReturnCode(int code);

    /**
     * A description for this event item e.g. "user found in access control list"
     * @return the item description
     */
    public String getDescription();

    /**
     * @return true if this step was processed without error
     */
    public boolean getEventItemSuccess();

    /**
     * @return the time this eventItem was created
     */
    public Date getEventItemCreateTime();

    /**
     * gets a summary of the item as a String
     * @return a summary of the item
     */
    public String getItemReport();
}
