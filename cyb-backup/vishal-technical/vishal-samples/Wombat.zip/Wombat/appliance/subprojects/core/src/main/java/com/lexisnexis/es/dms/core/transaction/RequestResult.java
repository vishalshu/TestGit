/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.transaction;

import java.util.List;

/**
 * Holds the repository objects that are returned by whatever action is called on the repository e.g. <br>
 * <ul>
 * <li>new document - a copy of the document
 * <li>retrieve document - the required document
 * <li>create folder - a reference to the folder
 * </ul>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public interface RequestResult
{
    /**
     * @return a list of repository objects
     */
    public List<RepositoryObject> getResults();

    /**
     * @return the maximum number of results returned in 1 page
     */
    public int getMaximumPageSize();

    /**
     * @return the actual number of results in this page.
     */
    public int getCurrentPageSize();

    /**
     * @return the total number of results across all pages
     */
    public long getTotalResultSize();
}
