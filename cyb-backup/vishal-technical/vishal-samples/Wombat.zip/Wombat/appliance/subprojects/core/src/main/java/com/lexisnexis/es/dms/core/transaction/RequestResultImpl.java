/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.transaction;

import java.util.ArrayList;
import java.util.List;

/**
 * holds the objects that are the results of the user request <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class RequestResultImpl implements RequestResult
{

    /** the maximum number of results that will be returned in a single page */
    private int maximumPageSize = 0;

    /** the total number of results for the 'query' (across all pages). */
    private long totalResultSize = 0;

    /** For paged results this is the starting index for this page */
    private long startIndex = 0;

    /**
     * Default constructor
     */
    public RequestResultImpl()
    {
        super();
    }

    /**
     * Constructor setting a page size (usually supplied by the client)
     * @param maximumPageSize the maximum number of results to return
     */
    public RequestResultImpl(final int maximumPageSize)
    {
        this();
        this.maximumPageSize = maximumPageSize;
    }

    /** the list of objects from the repository */
    private List<RepositoryObject> resultList = new ArrayList<RepositoryObject>();

    /**
     * {@inheritDoc}
     */
    @Override
    public List<RepositoryObject> getResults()
    {
        return resultList;
    }

    /**
     * @param repoObject
     */
    public void addResult(final RepositoryObject repoObject)
    {
        resultList.add(repoObject);
    }

    /**
     * @param results
     */
    public void setResults(final List<RepositoryObject> results)
    {
        resultList = results;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getMaximumPageSize()
    {
        return maximumPageSize;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getCurrentPageSize()
    {
        return resultList.size();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long getTotalResultSize()
    {
        return totalResultSize;
    }

    /**
     * @param numResults the total number of results the request would return if it were not paged
     */
    public void setTotalResultSize(final long numResults)
    {
        totalResultSize = numResults;
    }

    /**
     * @return the startIndex
     */
    public long getStartIndex()
    {
        return startIndex;
    }

    /**
     * @param startIndex the startIndex to set
     */
    public void setStartIndex(final long startIndex)
    {
        this.startIndex = startIndex;
    }
}
