/**
 * 
 */
package com.lexisnexis.es.dms.core.util;

import org.w3c.dom.NodeList;

/**
 * This will read the configuration file. Every DMSService will implement this interface to provide the
 * specific implementation to extract the required sections off the config file.
 * @author KaleJ
 */
public interface ConfigParser
{
    /**
     * Processes the services config <tt>section</tt>.
     * @param sectionName the name of the section to process
     * @return list of nodes for the section
     */
    NodeList readSection(String sectionName);
}
