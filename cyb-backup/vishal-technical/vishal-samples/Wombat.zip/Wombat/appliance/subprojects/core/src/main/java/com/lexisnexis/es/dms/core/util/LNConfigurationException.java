/**
 * 
 */
package com.lexisnexis.es.dms.core.util;

/**
 * @author omahonyj
 */
public class LNConfigurationException extends Exception
{
    /**
     * generated id for serialisation
     */
    private static final long serialVersionUID = -4705045407987186783L;

    /**
     * Construct the exception.
     * @param msg Message explaining what was happening when it all went pear shaped.
     * @param cause Underlying exception.
     */
    public LNConfigurationException(final String msg, final Throwable cause)
    {
        super(msg, cause);
    }

    /**
     * Construct the exception.
     * @param msg Message explaining what was happening when it all went pear shaped.
     */
    public LNConfigurationException(final String msg)
    {
        super(msg);
    }
}
