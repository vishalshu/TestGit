package com.lexisnexis.es.dms.core.util;

import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 * A Utility class to read the XML file. Currently has only one method which retrieves the {@link Document}
 * object.
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author KaleJ
 * 
 *         <pre>
 * $Log$
 * </pre>
 */
public class XMLReader
{
    /** Logger for this class */
    private static final Logger logger_ = Logger.getLogger(XMLReader.class);

    /**
     * This is a Utility method intended to receive an XML file and retrieve the {@link Document} object.
     * @param strXMLFilename the path/name of an xml file to parse
     * @return the document pointed to by the supplied filename
     * @throws LNConfigurationException Unable to process the configuration.
     */
    public Document getDocument(final String strXMLFilename)
                                                            throws LNConfigurationException
    {
        logger_.info("getDocument(String): processing config file " + strXMLFilename);

        try
        {
            Document doc = null;

            // Create an instance of the DocumentBuilderFactory
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            // Get the DocumentBuilder from the factory that we just got above.
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            InputStream is = Thread.currentThread().getContextClassLoader()
                                    .getResourceAsStream(strXMLFilename);
            // turn it into an in-memory object
            doc = docBuilder.parse(is);

            return doc;
        }
        catch (ParserConfigurationException e)
        {
            throw new LNConfigurationException("failed parsing " + strXMLFilename, e);
        }
        catch (SAXException e)
        {
            throw new LNConfigurationException("failed parsing " + strXMLFilename, e);
        }
        catch (IOException e)
        {
            throw new LNConfigurationException("failed reading " + strXMLFilename, e);
        }
    }
}