/**
 * 
 */
package com.lexisnexis.es.dms.core.util.exception;

/**
 * A runtime exception specific to LN DMS application
 * @author KaleJ
 */
public class SystemException extends RuntimeException
{
    /**
     * for serialisation
     */
    private static final long serialVersionUID = 5405145375225129466L;

    /**
     * @param cause the cause of the exception
     * @param msg a message for logging
     */
    public SystemException(Throwable cause, String msg)
    {
        super(msg, cause);
    }
}
