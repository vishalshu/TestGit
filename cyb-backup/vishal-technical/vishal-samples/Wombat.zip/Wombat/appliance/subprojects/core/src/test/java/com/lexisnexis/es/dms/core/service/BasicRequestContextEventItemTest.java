/**
 * 
 */
package com.lexisnexis.es.dms.core.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.lexisnexis.es.dms.core.transaction.RequestContextEventItem;

/**
 * <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */

public class BasicRequestContextEventItemTest
{

    /**
     * new items should automatically be timestamped
     */
    @Test
    public void createTime()
    {
        BasicRequestContextEventItem item = new BasicRequestContextEventItem("test");
        assertNotNull(item.getEventItemCreateTime());
    }

    /**
     * new items are given the description supplied, if no description then a default description is applied
     */
    @Test
    public void description()
    {
        BasicRequestContextEventItem item = new BasicRequestContextEventItem(null);
        assertNotNull(item.getDescription());

        item = new BasicRequestContextEventItem("test");
        assertEquals(item.getDescription(), "test");
    }

    /**
     * An item is a 'success' unless it is given a non zero return code
     */
    @Test
    public void success()
    {
        BasicRequestContextEventItem item = new BasicRequestContextEventItem("test");
        assertTrue(item.getEventItemSuccess());
        item.setReturnCode(0);
        assertTrue(item.getEventItemSuccess());
        item.setReturnCode(RequestContextEventItem.DOCUMENT_NOT_FOUND);
        assertFalse(item.getEventItemSuccess());
    }
}
