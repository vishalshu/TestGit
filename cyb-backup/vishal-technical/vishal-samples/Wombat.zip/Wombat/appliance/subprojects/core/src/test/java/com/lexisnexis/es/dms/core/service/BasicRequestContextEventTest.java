package com.lexisnexis.es.dms.core.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Test;

/**
 * Tests service event logging <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public class BasicRequestContextEventTest
{
    /**
     * The event description should be automatically created from the service
     */
    @Test
    public void description()
    {
        BasicRequestContextEvent event = new BasicRequestContextEvent("TestService");
        assertNotNull(event.getDescription());
    }

    /**
     * The start time should be automatically set
     */
    @Test
    public void startTime()
    {
        BasicRequestContextEvent event = new BasicRequestContextEvent("TestService");
        assertNotNull(event.getStartTime());
    }

    /**
     * There is a duration before the end time is set
     */
    @Test
    public void duration1()
    {
        BasicRequestContextEvent event = new BasicRequestContextEvent("TestService");
        dummyTask();
        assertTrue(event.getDuration() > 0);
    }

    /**
     * There is a duration after the end time is set
     */
    @Test
    public void duration2()
    {
        BasicRequestContextEvent event = new BasicRequestContextEvent("TestService");
        dummyTask();
        assertNull(event.getEndTime());
        assertTrue(event.getDuration() > 0);
        event.stop();
        assertTrue(event.getDuration() > 0);
    }

    /**
     * There is an event item created automatically when the event is created
     */
    @Test
    public void item()
    {
        BasicRequestContextEvent event = new BasicRequestContextEvent("TestService");
        assertNotNull(event.getEventItems());
    }

    /**
     * Tests that a report can be generated
     */
    @Test
    public void report()
    {
        BasicRequestContextEvent event = new BasicRequestContextEvent("TestService");
        String report = event.getReport();
        assertNotNull(report);
        assertTrue(report.trim().length() > 0);
        System.out.println(report);
    }

    /**
     * just waste a few processor cycles for time based testing
     */
    private void dummyTask()
    {
        System.out.println(new Date().getTime());
        for (int i = 1; i < 10000000; i++)
        {
            @SuppressWarnings("unused")
            double x = 1000 / i;
        }
        System.out.println(new Date().getTime());
    }

}
