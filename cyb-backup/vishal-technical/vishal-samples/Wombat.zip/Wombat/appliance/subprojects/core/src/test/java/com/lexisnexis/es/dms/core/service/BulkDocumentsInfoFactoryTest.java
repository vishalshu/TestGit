/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.service;

import java.io.FileNotFoundException;
import java.net.URISyntaxException;

import junit.framework.Assert;

import org.junit.Test;

import com.lexisnexis.es.dms.core.transaction.BulkDocumentsInfo;

/**
 * Test class for a test utility class, which doesn't have functional significance.<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class BulkDocumentsInfoFactoryTest
{

    /**
     * Test method to load files inside a folder
     * @throws FileNotFoundException
     * @throws URISyntaxException
     */
    @Test
    public void testGetDocuments() throws FileNotFoundException, URISyntaxException
    {
        RepositoryObjectFactory factory = new RepositoryObjectFactory();
        BulkDocumentsInfo bulkDocsInfo = factory
                                .getDocumentsFromFolder(TestConfigs.TEST_RESOURCES_PATH + "/wf_sc_1_2007",
                                                                        "lndms/client/00000001/00000002");
        Assert.assertTrue(bulkDocsInfo.getDocuments().size() > 2);

    }
}
