/**
 * 
 */
package com.lexisnexis.es.dms.core.service;

import org.junit.Test;

import com.lexisnexis.es.dms.core.util.LNConfigurationException;

/**
 * @author KaleJ
 */
public class ConfigParserImplTest
{
    /**
     * basic test of read function
     * @throws LNConfigurationException a configuration issue
     */
    @Test
    public void test() throws LNConfigurationException
    {
        ConfigParserImpl cpi = new ConfigParserImpl("TestServiceConfig.xml");

        cpi.readSection(ConfigParserImpl.SERVICES_SECTION);
    }
}
