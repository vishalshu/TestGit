/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

/**
 * Tests for the DMSQueryAttributes class. <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class DMSQueryAttributesTest
{
    /**
     * attribute lists are never null
     */
    @Test
    public void attributesNotNull()
    {
        DMSQueryAttributes dmsqa = new DMSQueryAttributes();
        assertNotNull(dmsqa.getAttributes(DMSQueryAttributes.Type.DOCUMENT_ID));
    }

    /**
     * adding an attribute of a type that is already mapped does not lose the original value
     */
    @Test
    public void attributesNotLost()
    {
        String id1 = "12345";
        String id2 = "76543";
        DMSQueryAttributes attrs = new DMSQueryAttributes();
        attrs.addAttribute(DMSQueryAttributes.Type.DOCUMENT_ID, id1);
        attrs.addAttribute(DMSQueryAttributes.Type.DOCUMENT_ID, id2);
        List<String> values = attrs.getAttributes(DMSQueryAttributes.Type.DOCUMENT_ID);
        assertTrue(values.get(0).equals(id1));
        assertTrue(values.get(1).equals(id2));
    }

    /**
     * We can clear out attributes of a specified type.
     */
    public void attributesCleared()
    {
        String id1 = "12345";
        DMSQueryAttributes attrs = new DMSQueryAttributes();
        attrs.addAttribute(DMSQueryAttributes.Type.DOCUMENT_ID, id1);
        assertNotNull(attrs.getAttributes(DMSQueryAttributes.Type.DOCUMENT_ID));
        attrs.removeAttributes(DMSQueryAttributes.Type.DOCUMENT_ID);
        assertNotNull(attrs.getAttributes(DMSQueryAttributes.Type.DOCUMENT_ID)); // list is never null
        assertTrue(attrs.getAttributes(DMSQueryAttributes.Type.DOCUMENT_ID).size() == 0); // list is empty
    }
}
