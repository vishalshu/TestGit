/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * Unit Test for RepositoryObjectLocationImpl <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class DocumentLocationImplTest
{
    /**
     * Creating the object automatically sets the path
     */
    @Test
    public void pathNotNull()
    {
        RepositoryObjectLocationImpl docLoc = new RepositoryObjectLocationImpl("Testloc");
        assertNotNull(docLoc.getLogicalPath());
    }

    /**
     * Creating the object doesn't give you any repositories
     */
    @Test
    public void reposNull()
    {
        RepositoryObjectLocationImpl docLoc = new RepositoryObjectLocationImpl("Testloc");
        assertNull(docLoc.getRepositoryList());
    }

    /**
     * Setting the repositories defines the target repository
     */
    @Test
    public void reposNotNull()
    {
        RepositoryObjectLocationImpl docLoc = new RepositoryObjectLocationImpl("Testloc");
        // target starts out as null
        assertNull(docLoc.getTargetRepository());
        List<String> repos = new ArrayList<String>();
        repos.add("SP1");
        repos.add("JR1");
        docLoc.setRepositoryList(repos);
        // target now defined
        assertNotNull(docLoc.getTargetRepository());
    }

    /**
     * The first repository in the list is the target repository
     */
    @Test
    public void targetNotNull()
    {
        RepositoryObjectLocationImpl docLoc = new RepositoryObjectLocationImpl("Testloc");
        List<String> repos = new ArrayList<String>();
        repos.add("SP1");
        repos.add("JR1");
        docLoc.setRepositoryList(repos);
        assertEquals(docLoc.getTargetRepository(), "SP1");
    }

}
