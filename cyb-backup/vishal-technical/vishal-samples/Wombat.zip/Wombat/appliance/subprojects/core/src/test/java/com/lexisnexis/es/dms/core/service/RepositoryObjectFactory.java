/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import com.lexisnexis.es.dms.core.transaction.BulkDocumentsInfo;
import com.lexisnexis.es.dms.core.transaction.DocumentDTO;
import com.lexisnexis.es.dms.core.transaction.DocumentInfo;

/**
 * Utility class for testing. Provides utility to load files/folders from the file system and get
 * RepositoryObjectInfo objects for the same.<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class RepositoryObjectFactory
{

    /**
     * @param filePath source file path from where file need to be read
     * @param fileName name of the file to be read
     * @param targetLogicalPath path to target document location e.g. lndms/00000001/00000002
     * @return populated DocumentInfo object
     * @throws FileNotFoundException
     */
    public DocumentInfo getDocumentInfo(final String filePath,
                                        final String fileName,
                                        final String targetLogicalPath) throws FileNotFoundException
    {
        DocumentDTO docInfo = null;

        docInfo = new BasicDocumentRepositoryObject();
        File f = new File(filePath + "/" + fileName);
        docInfo.setContent(new FileInputStream(f));
        docInfo.setDocumentFileName(fileName);
        docInfo.setMimeType("text/plain");
        docInfo.setLocation(new RepositoryObjectLocationImpl(targetLogicalPath));
        return docInfo;
    }

    /**
     * This methods serves as factory method to get BulkDocumentsInfo object which will be loaded with all the
     * DocumentInfo objects representing the files inside the folder specified by the folderPath
     * @param srcFolderPath relative path to folder from where files will be loaded
     * @param targetLogicalPath path to target document location e.g. lndms/00000001/00000002
     * @return populated BulkDocumentInfo object
     * @throws FileNotFoundException
     */
    public BulkDocumentsInfo getDocumentsFromFolder(final String srcFolderPath, final String targetLogicalPath) throws FileNotFoundException
    {
        BasicBulkDocumentsInfo info = new BasicBulkDocumentsInfo();
        info.setLocation(new RepositoryObjectLocationImpl(targetLogicalPath));

        File file = new File(srcFolderPath);
        String[] fileNames = null;

        if (file.isDirectory())
        {
            fileNames = file.list();
        }
        for (String fileName : fileNames)
        {
            DocumentInfo docInfo = getDocumentInfo(srcFolderPath, fileName, targetLogicalPath);
            info.addDocument(docInfo);
        }
        return info;
    }

}
