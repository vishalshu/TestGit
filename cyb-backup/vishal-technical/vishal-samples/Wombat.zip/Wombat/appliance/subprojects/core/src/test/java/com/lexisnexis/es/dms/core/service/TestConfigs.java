/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.core.service;

/**
 * Holds configuration constants for testing <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public interface TestConfigs
{
    /** path where all the documents required for tests reside */
    public static final String TEST_RESOURCES_PATH = "//lngtwyappt028v/integration-tests/createdoc";

}
