/**
 * 
 */
package com.lexisnexis.es.dms.licence;

import org.junit.Test;

/**
 * <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public class LicenceServiceTest
{
    /**
     * Tests when the context is null - should throw exception
     */
    @Test(expected = IllegalArgumentException.class)
    public void testNullContext()
    {
        LicenceService licenceService = new LicenceService();
        licenceService.process(null);
    }

}
