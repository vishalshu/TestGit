/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author vishalshu
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class DefaultWebdavFilter implements Filter
{
    /**
     * @see Filter#destroy()
     */
    @Override
    public void destroy()
    {
        // TODO
    }

    /**
     * Wraps HttpServletRequest into DefaultWebdavRequestWrapper and forwards it to next filter.
     * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
     */
    @Override
    public void doFilter(final ServletRequest request, final ServletResponse response,
                         final FilterChain chain) throws IOException, ServletException
    {
        WebdavServletRequestWrapper reqWrapper = new DefaultWebdavRequestWrapper();
        request.setAttribute("WebdavServletRequestWrapper", reqWrapper);
        chain.doFilter(request, response);
    }

    /**
     * @see Filter#init(FilterConfig)
     */
    @Override
    public void init(final FilterConfig fConfig) throws ServletException
    {
        // TODO
    }

}
