/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav;

import com.lexisnexis.es.dms.core.service.BasicDocumentRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.DocumentDTO;
import com.lexisnexis.es.dms.webdav.util.URLFolderData;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author vishalshu
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class DefaultWebdavRequestWrapper extends WebdavServletRequestWrapper
{

    /** the document information */
    BasicDocumentRepositoryObject documentInfo = new BasicDocumentRepositoryObject();

    /**
     * returns the doc info for this request {@inheritDoc}
     */
    @Override
    public DocumentDTO getDocumentInfo()
    {
        return documentInfo;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void processUrlData(final URLFolderData urlDocumentData)
    {
        documentInfo.setDepartment(urlDocumentData.getDepartment());
    }

}
