package com.lexisnexis.es.dms.webdav;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.lexisnexis.es.dms.core.service.DMSQueryAttributes;
import com.lexisnexis.es.dms.core.service.DMSRetrievalResult;
import com.lexisnexis.es.dms.core.service.RequestType;
import com.lexisnexis.es.dms.core.transaction.RepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectInfo;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.service.RequestProcessor;
import com.lexisnexis.es.dms.webdav.output.ObjectRenderer;
import com.lexisnexis.es.dms.webdav.output.XMLObjectRenderer;
import com.lexisnexis.es.utilities.exceptions.LNConfigurationException;

/**
 * Servlet implementation class WebdavServlet
 * @author vishalshu
 */
@SuppressWarnings("serial")
public class WebdavServlet extends HttpServlet
{

    /** Webdav find property */
    private static final String METHOD_PROPFIND = "PROPFIND";

    /** Webdav set property */
    private static final String METHOD_PROPPATCH = "PROPPATCH";

    /** Webdav Make Collection */
    private static final String METHOD_MKCOL = "MKCOL";

    /** Webdav COPY */
    private static final String METHOD_COPY = "COPY";

    /** Webdav MOVE */
    private static final String METHOD_MOVE = "MOVE";

    /** Webdav LOCK */
    private static final String METHOD_LOCK = "LOCK";

    /** Webdav UNLOCK */
    private static final String METHOD_UNLOCK = "UNLOCK";

    /**
     * spring application context associated with the servlet context.
     */
    private ApplicationContext applicationContext = null;

    /**
     * Request processor instance.
     */
    private RequestProcessor processor = null;

    /**
     * {@inheritDoc}
     */
    @Override
    public void init() throws ServletException
    {
        // Read xml applicationContext registered with the ServletContext
        applicationContext = WebApplicationContextUtils
                                .getRequiredWebApplicationContext(getServletContext());
        processor = applicationContext.getBean("requestProcessor", RequestProcessor.class);

    }

    /**
     * Handles the special WebDAV methods.
     */
    @Override
    protected void service(final HttpServletRequest req, final HttpServletResponse resp)
                                                                                        throws ServletException,
                                                                                        IOException
    {

        String method = req.getMethod();

        if (method.equals(METHOD_PROPFIND))
        {
            doPropfind(req, resp);
        }
        else if (method.equals(METHOD_PROPPATCH))
        {
            doProppatch(req, resp);
        }
        else if (method.equals(METHOD_MKCOL))
        {
            doMkcol(req, resp);
        }
        else if (method.equals(METHOD_COPY))
        {
            doCopy(req, resp);
        }
        else if (method.equals(METHOD_MOVE))
        {
            doMove(req, resp);
        }
        else if (method.equals(METHOD_LOCK))
        {
            doLock(req, resp);
        }
        else if (method.equals(METHOD_UNLOCK))
        {
            doUnlock(req, resp);
        }
        else
        {
            // DefaultServlet processing
            super.service(req, resp);
        }

    }

    /**
     * actions the webdav method: unlock
     * @param req the request
     * @param resp the response
     */
    private void doUnlock(final HttpServletRequest req, final HttpServletResponse resp)
    {
        // TODO Auto-generated method stub

    }

    /**
     * actions the webdav method: unlock
     * @param req the request
     * @param resp the response
     */
    private void doLock(final HttpServletRequest req, final HttpServletResponse resp)
    {
        // TODO Auto-generated method stub

    }

    /**
     * actions the webdav method: move
     * @param req the request
     * @param resp the response
     */
    private void doMove(final HttpServletRequest req, final HttpServletResponse resp)
    {
        // TODO Auto-generated method stub

    }

    /**
     * actions the webdav method: copy
     * @param req the request
     * @param resp the response
     */
    private void doCopy(final HttpServletRequest req, final HttpServletResponse resp)
    {
        // TODO Auto-generated method stub

    }

    /**
     * actions the webdav method: mkcol
     * @param req the request
     * @param resp the response
     * @throws ServletException if there is a problem actioning the request
     * @throws IOException if there is a problem interpreting the request
     */
    private void doMkcol(final HttpServletRequest req, final HttpServletResponse resp) throws ServletException,
                                                                                      IOException
    {
        WebdavServletRequestWrapper wrapper = ((WebdavServletRequestWrapper)req
                                .getAttribute("WebdavServletRequestWrapper"));
        wrapper.populateFolderInfo(req);

        // TODO credentials
        RequestContext currentContext = applicationContext.getBean("requestContext",
                                                                   RequestContext.class);
        currentContext.setRepositoryObjectInfo(wrapper.getDocumentInfo());
        currentContext.setRequestType(RequestType.CREATE_FOLDER);
        try
        {
            processor.process(currentContext);
        }
        catch (LNConfigurationException e)
        {
            throw new ServletException("Error in RequestProcessor.process()", e);
        }
    }

    /**
     * actions the webdav method: proppatch
     * @param req the request
     * @param resp the response
     */
    private void doProppatch(final HttpServletRequest req, final HttpServletResponse resp)
    {
        // TODO Auto-generated method stub

    }

    /**
     * actions the webdav method: propfind
     * @param req the request
     * @param resp the response
     * @throws ServletException
     * @throws IOException
     */
    private void doPropfind(final HttpServletRequest req, final HttpServletResponse resp) throws ServletException,
                                                                                         IOException
    {
        WebdavServletRequestWrapper wrapper = ((WebdavServletRequestWrapper)req
                                .getAttribute("WebdavServletRequestWrapper"));
        wrapper.populateFolderInfo(req);

        // TODO credentials
        RequestContext currentContext = applicationContext.getBean("requestContext",
                                                                   RequestContext.class);
        currentContext.setRepositoryObjectInfo(wrapper.getDocumentInfo());
        currentContext.setRequestType(RequestType.LIST_FOLDER_CONTENTS);
        try
        {
            processor.process(currentContext);
        }
        catch (LNConfigurationException e)
        {
            throw new ServletException("Error in RequestProcessor.process()", e);
        }

        // output results
        if (currentContext.getRequestResult() != null)
        {
            List<RepositoryObject> resultObjects = currentContext.getRequestResult().getResults();
            String output = "";
            ObjectRenderer renderer = new XMLObjectRenderer();
            RepositoryObjectInfo info = currentContext.getRepositoryObjectInfo();
            String folderName = info.getLocation().getLogicalPath();
            output = renderer.renderObjects(folderName, resultObjects);
            PrintWriter writer = resp.getWriter();
            writer.append(output);
            // temp for testing
            System.out.println(output);
        }
        else
        {
            resp.getWriter().append("folder not found");
        }
    }

    /**
     * process a 'get' request, i.e. fetch a document
     * @param req webdaveServletRequest
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(final HttpServletRequest req, final HttpServletResponse resp)
                                                                                      throws ServletException,
                                                                                      IOException
    {
        // super.doGet(req, resp);
        WebdavServletRequestWrapper wrapper = ((WebdavServletRequestWrapper)req
                                .getAttribute("WebdavServletRequestWrapper"));
        wrapper.populateDocumentInfo(req);

        // TODO credentials
        RequestContext currentContext = applicationContext.getBean("requestContext",
                                                                   RequestContext.class);
        // TODO how is (are) the document id(s) represented in the request?
        currentContext.setRepositoryObjectInfo(wrapper.getDocumentInfo());
        currentContext.setRequestType(RequestType.VIEW_DOCUMENTS);
        DMSQueryAttributes dmsqa = new DMSQueryAttributes();
        // can be tested with browser e.g. http://localhost:8080/lndms/default?docid=29-512
        String requiredDocIdDoc = req.getParameter("docid");
        dmsqa.addAttribute(DMSQueryAttributes.Type.DOCUMENT_ID, requiredDocIdDoc);
        currentContext.setQueryAttributes(dmsqa);
        try
        {
            processor.process(currentContext);
        }
        catch (LNConfigurationException e)
        {
            throw new ServletException("Error in RequestProcessor.process()", e);
        }
        List<RepositoryObject> resultObjects = currentContext.getRequestResult().getResults();
        RepositoryObject obj = null;
        if (resultObjects != null && resultObjects.size() > 0)
        {
            obj = currentContext.getRequestResult().getResults().get(0);
        }
        if (obj != null)
        {

            ServletOutputStream stream = null;
            BufferedInputStream buf = null;
            try
            {

                stream = resp.getOutputStream();

                // set response headers
                resp.setContentType(((DMSRetrievalResult)obj).getDocumentRepositoryObject().getMimeType());
                resp.addHeader("Content-Disposition", "attachment; filename=" + obj.getName());

                InputStream is = ((DMSRetrievalResult)obj).getDocumentRepositoryObject().getContent();

                resp.setContentLength(is.available());

                buf = new BufferedInputStream(is);
                int readBytes = 0;

                // read from the file; write to the ServletOutputStream
                while ((readBytes = buf.read()) != -1)
                {
                    stream.write(readBytes);
                }
            }
            catch (IOException ioe)
            {
                throw new ServletException(ioe.getMessage());
            }
            finally
            {
                if (stream != null)
                {
                    stream.close();
                }
                if (buf != null)
                {
                    buf.close();
                }
            }

        }
        else
        {
            resp.getWriter().append("file not found");
        }
    }

    /**
     * @param req webdaveServletRequest
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPut(final HttpServletRequest req, final HttpServletResponse resp)
                                                                                      throws ServletException,
                                                                                      IOException
    {
        super.doPut(req, resp);
        WebdavServletRequestWrapper wrapper = ((WebdavServletRequestWrapper)req
                                .getAttribute("WebdavServletRequestWrapper"));
        wrapper.populateDocumentInfo(req);

        // TODO credentials
        RequestContext currentContext = applicationContext.getBean("requestContext",
                                                                   RequestContext.class);
        currentContext.setRepositoryObjectInfo(wrapper.getDocumentInfo());
        currentContext.setRequestType(RequestType.NEW_DOCUMENT);

        try
        {
            processor.process(currentContext);
        }
        catch (LNConfigurationException e)
        {
            throw new ServletException("Error in RequestProcessor.process()", e);
        }
    }

    /**
     * @return the processor
     */
    public RequestProcessor getProcessor()
    {
        return processor;
    }

    /**
     * @param processor the processor to set
     */
    public void setProcessor(final RequestProcessor processor)
    {
        this.processor = processor;
    }
}
