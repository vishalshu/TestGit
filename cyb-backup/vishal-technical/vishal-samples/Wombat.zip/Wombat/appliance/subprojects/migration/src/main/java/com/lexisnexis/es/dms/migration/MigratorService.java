package com.lexisnexis.es.dms.migration;

import com.lexisnexis.es.dms.core.service.BasicDmsService;
import com.lexisnexis.es.dms.core.service.DmsServiceResult;
import com.lexisnexis.es.dms.core.service.ServiceResult;
import com.lexisnexis.es.dms.core.transaction.RequestContext;

/**
 * the MigratorService will transfer documents from one repository to another 'on the fly'. Originally
 * intended for use in the instance of a new repository replacing an old repository <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public class MigratorService extends BasicDmsService
{
    /**
     * (non-Javadoc)
     * @see com.lexisnexis.es.dms.core.service.BasicDmsService#process(com.lexisnexis.es.dms.core.transaction.RequestContext)
     */
    @Override
    public DmsServiceResult process(RequestContext currentContext)
    {
        if (currentContext != null)
        {
            // TODO actually check something!
            return new ServiceResult(false, null);
        }
        else
        {
            throw new IllegalArgumentException();
        }
    }
}
