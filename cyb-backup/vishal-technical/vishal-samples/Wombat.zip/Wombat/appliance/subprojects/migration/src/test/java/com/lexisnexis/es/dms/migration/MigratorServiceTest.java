/**
 * 
 */
package com.lexisnexis.es.dms.migration;

import org.junit.Test;

/**
 * <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */

public class MigratorServiceTest
{
    /**
     * Tests when the context is null - should throw exception
     */
    @Test (expected=IllegalArgumentException.class)
    public void testNullContext()
    {
        MigratorService migratorService = new MigratorService();
        migratorService.process(null);
    }

}
