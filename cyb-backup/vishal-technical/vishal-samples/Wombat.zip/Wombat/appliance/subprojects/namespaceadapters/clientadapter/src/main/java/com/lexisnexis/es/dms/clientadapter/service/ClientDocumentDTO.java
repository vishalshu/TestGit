/**
 * 
 */
package com.lexisnexis.es.dms.clientadapter.service;

import com.lexisnexis.es.dms.core.service.BasicDocumentRepositoryObject;

/**
 * DocumentDTO implementation for client name-space
 * @author vishalshu
 */
public class ClientDocumentDTO extends BasicDocumentRepositoryObject
{

    /**
     * clientCode for the document
     */
    private String clientCode;

    /**
     * fileCode for the document
     */
    private String fileCode;

    /**
     * workflowCode for the document
     */
    private String workflowCode;

    /**
     * @see ClientDocumentContext
     */
    private ClientDocumentContext clientDocumentContext;

    /**
     * This can be used to indicate whether this document belongs to <i>Client context only</i>, <i>Client &
     * File context</i>, <i>Client & Workflow context</i> or <i>Client, File & Workflow context</i>
     * @author vishalshu
     */
    public enum ClientDocumentContext
    {
        /**
         * Indicates that document is linked with <i>client only</i>
         */
        CLIENT_CONTEXT,
        /**
         * Indicates that document is linked with <i>client & file </i>
         */
        FILE_CONTEXT,
        /**
         * Indicates that document is linked with <i>client & workflow </i>
         */
        WORKFLOW_CONTEXT,
        /**
         * Indicates that document is linked with <i>client, file & workflow </i>
         */
        FILE_WORKFLOW_CONTEXT
    }

    /**
     * @return clientCode
     */
    public String getClientCode()
    {
        return clientCode;
    }

    /**
     * @param clientCode
     */
    public void setClientCode(final String clientCode)
    {
        this.clientCode = clientCode;
    }

    /**
     * @return fileCode
     */
    public String getFileCode()
    {
        return fileCode;
    }

    /**
     * @param fileCode
     */
    public void setFileCode(final String fileCode)
    {
        this.fileCode = fileCode;
    }

    /**
     * @return workflowCode
     */
    public String getWorkflowCode()
    {
        return workflowCode;
    }

    /**
     * @param workflowCode
     */
    public void setWorkflowCode(final String workflowCode)
    {
        this.workflowCode = workflowCode;
    }

    /**
     * @return clientDocumentContext
     * @see ClientDocumentContext
     */
    public ClientDocumentContext getClientDocumentContext()
    {
        if (getFileCode() != null)
        {
            if (getWorkflowCode() != null)
            {
                clientDocumentContext = ClientDocumentContext.FILE_WORKFLOW_CONTEXT;
            }
            else
            {
                clientDocumentContext = ClientDocumentContext.FILE_CONTEXT;
            }
        }
        else
        {
            if (getWorkflowCode() != null)
            {
                clientDocumentContext = ClientDocumentContext.WORKFLOW_CONTEXT;
            }
            else
            {
                clientDocumentContext = ClientDocumentContext.CLIENT_CONTEXT;
            }

        }

        return clientDocumentContext;
    }

}
