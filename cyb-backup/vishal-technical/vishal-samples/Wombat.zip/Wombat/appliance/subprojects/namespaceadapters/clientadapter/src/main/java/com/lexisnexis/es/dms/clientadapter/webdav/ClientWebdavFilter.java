package com.lexisnexis.es.dms.clientadapter.webdav;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet Filter implementation class ClientWebdavFilter
 * @author vishalshu
 */
public class ClientWebdavFilter implements Filter
{

    /**
     * @see Filter#destroy()
     */
    @Override
    public void destroy()
    {
        // TODO
    }

    /**
     * Wraps HttpServletRequest into ClientWebdavRequestWrapper and forwards it to next filter.
     * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
     */
    @Override
    public void doFilter(final ServletRequest request, final ServletResponse response,
                         final FilterChain chain) throws IOException, ServletException
    {
        final ClientWebdavRequestWrapper reqWrapper = new ClientWebdavRequestWrapper();
        request.setAttribute("WebdavServletRequestWrapper", reqWrapper);
        chain.doFilter(request, response);
    }

    /**
     * @see Filter#init(FilterConfig)
     */
    @Override
    public void init(final FilterConfig fConfig) throws ServletException
    {
        // TODO
    }

}
