/**
 * 
 */
package com.lexisnexis.es.dms.clientadapter.webdav;

import com.lexisnexis.es.dms.clientadapter.service.ClientDocumentDTO;
import com.lexisnexis.es.dms.core.transaction.DocumentDTO;
import com.lexisnexis.es.dms.webdav.WebdavServletRequestWrapper;
import com.lexisnexis.es.dms.webdav.util.URLFolderData;

/**
 * Wraps all the webdav request coming for client namespace. Responsible for providing Implementation of
 * DocumentInfoFacotry interface.
 * @author vishalshu
 */
public class ClientWebdavRequestWrapper extends WebdavServletRequestWrapper
{

    /**
     * documentInfo holder.
     */
    private final ClientDocumentDTO documentInfo = new ClientDocumentDTO();

    @Override
    protected void processUrlData(final URLFolderData urlDocumentData)
    {
        documentInfo.setClientCode(urlDocumentData.getClientCode());
        documentInfo.setFileCode(urlDocumentData.getMatterCode());
        documentInfo.setWorkflowCode(urlDocumentData.getWorkflowCode());
        documentInfo.setDepartment(urlDocumentData.getDepartment());
    }

    @Override
    protected DocumentDTO getDocumentInfo()
    {
        return documentInfo;
    }

}
