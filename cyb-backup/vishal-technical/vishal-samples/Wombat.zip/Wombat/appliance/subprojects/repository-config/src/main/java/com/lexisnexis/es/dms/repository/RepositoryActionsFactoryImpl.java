/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository;

import com.lexisnexis.es.dms.core.service.RequestType;
import com.lexisnexis.es.dms.repository.actions.CreateBulkDocumentsAction;
import com.lexisnexis.es.dms.repository.actions.CreateDocumentAction;
import com.lexisnexis.es.dms.repository.actions.CreateFolderAction;
import com.lexisnexis.es.dms.repository.actions.ListFolderContentsAction;
import com.lexisnexis.es.dms.repository.actions.RepositoryAction;
import com.lexisnexis.es.dms.repository.actions.RetrieveDocumentsAction;

/**
 * An implementation of {@RepositoryActionsFactory}<br/>
 * Responsible for orchestration of dms actions for specific repository implementation. Action implementations
 * are injected at the time of instantiation of the object. <br/>
 * <hr/>
 * @author shuklav
 */

public class RepositoryActionsFactoryImpl implements RepositoryActionsFactory
{
    /** The path of the initial folder for this repository, e.g. the root dms folder for this application */
    private String startPath;

    /** Action instance to create new document */
    private final CreateDocumentAction createDocumentAction;

    /** Action instance to create folder */
    private final CreateFolderAction createFolderAction;

    /** Action instance to retrieve document */
    private final RetrieveDocumentsAction retrieveDocumentsByIdAction;

    /** Action instance to create bulk documents */
    private final CreateBulkDocumentsAction createBulkDocumentsAction;

    /** Action instance to list contents of folder */
    private final ListFolderContentsAction listFolderContentsAction;

    /**
     * @param createDocumentAction
     * @param createFolderAction
     * @param retrieveDocumentsByIdAction
     * @param createBulkDocumentsAction
     */
    public RepositoryActionsFactoryImpl(final CreateDocumentAction createDocumentAction,
                                               final CreateFolderAction createFolderAction,
                                               final RetrieveDocumentsAction retrieveDocumentsByIdAction,
                                        final CreateBulkDocumentsAction createBulkDocumentsAction,
                                        final ListFolderContentsAction listFolderContentsAction)
    {
        this.createDocumentAction = createDocumentAction;
        this.createFolderAction = createFolderAction;
        this.retrieveDocumentsByIdAction = retrieveDocumentsByIdAction;
        this.createBulkDocumentsAction = createBulkDocumentsAction;
        this.listFolderContentsAction = listFolderContentsAction;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RepositoryAction getRepositoryAction(final RequestType requestType) throws UnsupportedRepositoryActionException
    {
        final RepositoryAction repoAction;

        switch (requestType)
        {
            case NEW_DOCUMENT:
                repoAction = createDocumentAction;
                break;
            case CREATE_FOLDER:
                repoAction = createFolderAction;
                break;
            case VIEW_DOCUMENTS:
                repoAction = retrieveDocumentsByIdAction;
                break;
            case NEW_BULK_DOCUMENTS:
                repoAction = createBulkDocumentsAction;
                break;
            case LIST_FOLDER_CONTENTS:
                repoAction = listFolderContentsAction;
                break;
            default:
                repoAction = null;
                break;
        }

        if (repoAction == null)
        {
            throw new UnsupportedRepositoryActionException(requestType.toString() + " : action is not yet supported.");
        }

        return repoAction;

    }

    // /**
    // * @param requestType
    // * @param clazz
    // * @param <T> Type for the return type which must pass instance of test for RepositoryAction
    // * @return RepositoryAction of type T
    // * @throws UnsupportedRepositoryActionException
    // */
    //
    // public <T extends RepositoryAction> T getRepositoryAction(final RequestType requestType, final T clazz)
    // throws UnsupportedRepositoryActionException
    // {
    // final RepositoryAction repoAction = getRepositoryAction(requestType);
    //
    // if(repoAction instanceof clazz.getClass()){
    //
    // }
    // T returnedAction = null;
    // try{
    // returnedAction = (T)repoAction;
    // }catch(ClassCastException cce){
    // throw new UnsupportedRepositoryActionException(requestType.toString() + " doesn't map to "+
    // clazz.getClass().getName() +" action.");
    // }
    // return ;
    //
    // }

    /**
     * @see RepositoryActionsFactoryImpl#startPath
     * @param startPath the startPath to set
     */
    public void setStartPath(final String startPath)
    {
        this.startPath = startPath;
    }

}
