package com.lexisnexis.es.dms.repository;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.lexisnexis.es.dms.core.service.BasicDmsService;
import com.lexisnexis.es.dms.core.service.BasicRequestContextEventItem;
import com.lexisnexis.es.dms.core.service.DmsServiceResult;
import com.lexisnexis.es.dms.core.service.ServiceResult;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestContextEventItem;
import com.lexisnexis.es.dms.core.transaction.RequestResult;
import com.lexisnexis.es.dms.repository.actions.RepositoryAction;

/**
 * RepositoryService handles the actual access to a dms: document creation, amendment etc. <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public class RepositoryService extends BasicDmsService implements ApplicationContextAware
{

    /** repository action factory instance that provides repository actions */
    private RepositoryActionsFactory repoActionsFactory;

    /**
     * Spring applicatioin context
     */
    private ApplicationContext applicationContext;

    /**
     * @see com.lexisnexis.es.dms.core.service.DmsService#process(com.lexisnexis.es.dms.core.transaction.RequestContext)
     */
    @Override
    public DmsServiceResult process(final RequestContext currentContext)
    {
        if (currentContext != null)
        {
            // Get the route for repositories from request context.
            String repoName = currentContext.getRepositoryObjectInfo().getLocation().getTargetRepository();

            // Look up the repositories found in the route
            try
            {
                repoActionsFactory = applicationContext.getBean(repoName, RepositoryActionsFactory.class);
            }
            catch (BeansException be)
            {
                RequestContextEventItem item = new BasicRequestContextEventItem("Error in repository configuration:" + repoName);
                item.setReturnCode(RequestContextEventItem.INVALID_CONFIG);
                currentContext.addEventItem(RepositoryService.class.getName(), item);
                return new ServiceResult(false, null);
            }
            currentContext.addEventItem("repository found:" + repoName);

            // Look up the RepositoryAction instance for current RequestType
            RepositoryAction repoAction;
            try
            {
                repoAction = repoActionsFactory.getRepositoryAction(currentContext
                                            .getRequestType());
            }
            catch (UnsupportedRepositoryActionException e)
            {
                RequestContextEventItem item = new BasicRequestContextEventItem("The request type is unimplemented : " + currentContext.getRequestType());
                item.setReturnCode(RequestContextEventItem.UNIMPLEMENTED_REQUEST_TYPE);
                currentContext.addEventItem(RepositoryService.class.getName(), item);
                return new ServiceResult(false, null);

            }

            // Perform the actual stuff
            RequestResult result = repoAction.execute(currentContext);
            // put any returned objects in the context
            currentContext.setRequestResult(result);

            return new ServiceResult(true, null);
        }
        else
        {
            throw new IllegalArgumentException();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setApplicationContext(final ApplicationContext applicationContext) throws BeansException
    {
        this.applicationContext = applicationContext;

    }

    /**
     * @return the applicationContext
     */
    public ApplicationContext getApplicationContext()
    {
        return applicationContext;
    }

}
