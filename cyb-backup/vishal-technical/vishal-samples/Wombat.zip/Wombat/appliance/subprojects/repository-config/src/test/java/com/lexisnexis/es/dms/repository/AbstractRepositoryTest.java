/*
 * Copyright (c) 2011 LexisNexis Axxia. All rights reserved.
 */

package com.lexisnexis.es.dms.repository;

import org.junit.Before;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lexisnexis.es.dms.core.service.TestConfigs;

/**
 * Abstract util class for all the unit test classes of repository-config project<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.4
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public abstract class AbstractRepositoryTest
{
    /**
     * applicationContext to be used to perform unit test
     */
    protected ApplicationContext appContext;

    /** path where all the documents required for tests reside */
    public String testResourcesPath = TestConfigs.TEST_RESOURCES_PATH;

    /**
     * setup before performing test
     */
    @Before
    public final void setup()
    {
        appContext = new ClassPathXmlApplicationContext("springconfig/test-repository-config-beans.xml");

    }
}
