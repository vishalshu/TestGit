/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository;

/**
 * Test class for {@link RepositoryActionsFactory}<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class RepositoryActionsFactoryTest extends AbstractRepositoryTest
{
    // TODO: Need to add tests for this
}
