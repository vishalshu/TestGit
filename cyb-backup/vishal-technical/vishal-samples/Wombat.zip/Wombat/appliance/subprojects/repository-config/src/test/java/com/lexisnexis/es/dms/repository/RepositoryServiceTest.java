/**
 * 
 */
package com.lexisnexis.es.dms.repository;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;

import com.lexisnexis.es.dms.core.service.DmsServiceResult;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.repository.actions.RepositoryAction;

/**
 * JUnit test class for {@link RepositoryService}, which uses {@link RepositoryActionsFactory} and
 * {@link RepositoryAction} to serve the incoming request. Hence, this test class serves as Integration test
 * class for these two classes. <br/>
 * @see RepositoryService
 * @see RepositoryActionsFactory
 * @see RepositoryAction <br>
 *      <hr>
 *      Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 *      <hr/>
 * @author omahonyj
 */

public class RepositoryServiceTest extends AbstractRepositoryTest
{

    /**
     * Tests when the context is null - should throw exception
     */
    @Test(expected = IllegalArgumentException.class)
    public void testNullContext()
    {
        final RepositoryService serviceInstance = appContext.getBean("repositoryService",
                                                                     RepositoryService.class);

        serviceInstance.process(null);
    }

    /**
     * test create document action
     */
    @Test
    public void testCreateDocument()
    {
        // lookup test request context
        final RequestContext requestContext = appContext.getBean("createDocumentRequestContext",
                                                                 RequestContext.class);

        final RepositoryService serviceInstance = appContext.getBean("repositoryService",
                                                                     RepositoryService.class);

        // set repositories list
        final List<String> repositories = new ArrayList<String>();
        repositories.add("mockRepository");
        requestContext.getRepositoryObjectInfo().getLocation().setRepositoryList(repositories);

        // execute method under test
        final DmsServiceResult result = serviceInstance.process(requestContext);

        // assertion criteria
        Assert.assertTrue(result.isSuccess());

    }

    /**
     * test create document action for alfresco repository
     */
    @Test
    public void testInvalidRepositoryConfiguration()
    {
        // lookup test request context
        final RequestContext requestContext = appContext.getBean("createDocumentRequestContext",
                                                                 RequestContext.class);

        final RepositoryService serviceInstance = appContext.getBean("repositoryService",
                                                                     RepositoryService.class);

        // set repositories list
        final List<String> repositories = new ArrayList<String>();
        repositories.add("invalidRepositoryName");
        requestContext.getRepositoryObjectInfo().getLocation().setRepositoryList(repositories);

        // execute method under test
        final DmsServiceResult result = serviceInstance.process(requestContext);

        // assertion criteria
        Assert.assertTrue(!result.isSuccess());

    }

}
