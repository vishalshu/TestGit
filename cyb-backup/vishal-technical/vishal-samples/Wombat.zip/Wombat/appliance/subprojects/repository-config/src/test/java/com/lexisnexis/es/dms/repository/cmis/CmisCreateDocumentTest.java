/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository.cmis;

import org.junit.Test;

import com.lexisnexis.es.dms.repository.AbstractRepositoryTest;
import com.lexisnexis.es.dms.repository.RepositoryException;
import com.lexisnexis.es.dms.repository.actions.CreateDocumentAction;
import com.lexisnexis.es.dms.repository.util.RepositoryActionTestsUtil;

/**
 * Test cmis implementation of {@link CreateDocumentAction}<br/>
 * NOTE: Treat these as integration-cum-unit test cases for repository-config, repository & cmisadapter
 * projects. Othere possible place for these unit tests are in cmisadapter project or as integration test.
 * Issue in keeping this inside CMIS project is that it requires repository configuration which can't be kept
 * in cmis project. If we keep it in integration test project, code coverage for unit tests will go hugely
 * down for cmis, repository & repository-config projects.<br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class CmisCreateDocumentTest extends AbstractRepositoryTest
{
    /**
     * Test document creation for alfresco repository
     * @throws RepositoryException
     */
    @Test
    public void testAlfrescoCreateDocumentAction() throws RepositoryException
    {

        // lookup action object
        CreateDocumentAction createDocAction = appContext.getBean("alfrescoCreateDocumentAction",
                                                                       CreateDocumentAction.class);

        RepositoryActionTestsUtil.testCreateDocumentAction(appContext,
                                                           createDocAction,
                                                           testResourcesPath, "Sample.xlsx");
    }

    /**
     * Test document creation for jackrabbit repository
     * @throws RepositoryException
     */
    @Test
    public void testJackrabbitCreateDocumentAction() throws RepositoryException
    {

        // lookup action object
        CreateDocumentAction createDocAction = appContext.getBean("jackrabbitCreateDocumentAction",
                                                                       CreateDocumentAction.class);

        RepositoryActionTestsUtil.testCreateDocumentAction(appContext,
                                                           createDocAction,
                                                           testResourcesPath, "Sample.xlsx");
    }

    /**
     * Test document creation for sharepoint repository
     * @throws RepositoryException
     */
    @Test
    public void testSharepointCreateDocumentAction() throws RepositoryException
    {

        // lookup action object
        CreateDocumentAction createDocAction = appContext.getBean("sharepointCreateDocumentAction",
                                                                       CreateDocumentAction.class);

        RepositoryActionTestsUtil.testCreateDocumentAction(appContext,
                                                           createDocAction,
                                                           testResourcesPath, "Sample.xlsx");
    }

}
