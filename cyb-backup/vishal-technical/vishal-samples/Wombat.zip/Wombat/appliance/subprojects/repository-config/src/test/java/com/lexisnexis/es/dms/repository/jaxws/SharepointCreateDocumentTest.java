/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository.jaxws;

import java.net.URISyntaxException;
import java.rmi.RemoteException;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lexisnexis.es.dms.repository.RepositoryException;
import com.lexisnexis.es.dms.repository.util.RepositoryActionTestsUtil;
import com.lexisnexis.es.dms.sharepoint.adapter.jaxws.SharepointCreateDocument;
import com.sun.xml.bind.v2.TODO;

/**
 * This tests the Lists webservice of Sharepoint<br/>
 * Tests the fact that you can connect to it using the username and password<br/>
 * At the moment it fetches the list of repositories and print them out<br/>
 * <br/>
 * Note: To test it enter valid username and password in the respective variables<br/>
 * <br/> {@link TODO} At the moment all the code is kept here because of major refactoring being done.
 * <hr/>
 * @author KaleJ
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class SharepointCreateDocumentTest
{
    /**
     * applicationContext to be used to perform unit test
     */
    protected ApplicationContext appContext;

    /**
     * setup before performing test
     */
    @Before
    public void setup()
    {
        appContext = new ClassPathXmlApplicationContext("springconfig/test-repository-config-beans.xml");

    }

    /**
     * This tests creation of documet in sharepoint via webservice call
     * @param filename
     * @throws RepositoryException
     */
    public void addDocument(final String filename) throws RepositoryException
    {

        SharepointCreateDocument createDocAction = appContext
                                .getBean("sharepointJAXWSCreateDocumentAction",
                                         SharepointCreateDocument.class);

        createDocAction.setFileName(filename);

        RepositoryActionTestsUtil.testCreateDocumentAction(appContext, createDocAction);
    }

    /**
     * Load test function to add multiple documents into Sharepoint List
     * @throws RemoteException
     * @throws URISyntaxException
     * @throws RepositoryException
     */
    @Test
    public void testAddMultipleDocument() throws RemoteException,
                                                     URISyntaxException,
                                                     RepositoryException
    {
        int count = 5;
        int i = 0;
        while (i < count)
        {
            addDocument(getTimestampFilename() + "_" + (i++) + ".txt");
        }
    }

    /**
     * tests the addition of single document
     * @throws RemoteException
     * @throws URISyntaxException
     * @throws RepositoryException
     */
    @Test
    public void testSingleAddDocument() throws RemoteException, URISyntaxException, RepositoryException
    {
        addDocument(getTimestampFilename() + ".txt");
    }

    /**
     * @return File name appended with timstamp
     */
    private String getTimestampFilename()
    {
        return "jee_upload_" + getTimestamp();
    }

    /**
     * @return unique id to be included into the filename
     */
    private String getTimestamp()
    {
        String timestamp = "";
        timestamp += Calendar.getInstance().get(Calendar.DATE);
        timestamp += Calendar.getInstance().get(Calendar.MONTH);
        timestamp += Calendar.getInstance().get(Calendar.YEAR);
        timestamp += "_" + Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        timestamp += Calendar.getInstance().get(Calendar.MINUTE);
        timestamp += Calendar.getInstance().get(Calendar.SECOND);

        return timestamp;
    }
}
