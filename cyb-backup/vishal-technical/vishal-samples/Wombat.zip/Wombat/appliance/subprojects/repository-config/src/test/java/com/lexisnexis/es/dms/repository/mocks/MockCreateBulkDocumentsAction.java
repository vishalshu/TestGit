/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository.mocks;

import com.lexisnexis.es.dms.core.service.BasicDocumentRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestResult;
import com.lexisnexis.es.dms.core.transaction.RequestResultImpl;
import com.lexisnexis.es.dms.repository.actions.CreateBulkDocumentsAction;

/**
 * Mock {@link CreateBulkDocumentsAction} implementation to test dependent components.<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class MockCreateBulkDocumentsAction implements CreateBulkDocumentsAction
{

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestResult execute(final RequestContext requestContext)
    {

        final RequestResultImpl result = new RequestResultImpl();
        result.addResult(new BasicDocumentRepositoryObject());
        result.addResult(new BasicDocumentRepositoryObject());
        result.addResult(new BasicDocumentRepositoryObject());
        return result;
    }

}
