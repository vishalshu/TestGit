/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository.util;

import junit.framework.Assert;

import org.apache.chemistry.opencmis.client.api.Repository;

import com.lexisnexis.es.dms.adapter.cmis.CmisRepositoryFactory;
import com.lexisnexis.es.dms.repository.RepositoryException;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class RepositoryConfigTestsUtil
{

    /**
     * tests for repository instance lookup. This is a utility method that can be called from repository
     * specific test method for createDocumentAction.
     * @param cmisRepoFactory
     * @throws RepositoryException
     */

    public static void testRepositoryLookup(final CmisRepositoryFactory cmisRepoFactory) throws RepositoryException
    {

        final Repository repo = cmisRepoFactory.getRepository();
        Assert.assertNotNull(repo);
        Assert.assertNotNull(repo.getId());
    }
}
