/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository.webservice.sharepoint;

import java.io.ByteArrayInputStream;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.stream.XMLStreamException;

import org.apache.axiom.om.OMElement;
import org.junit.Before;
import org.junit.Test;

import com.lexisnexis.es.dms.sharepoint.adapter.webservice.data.SpList;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListCollection;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListCollectionResponse;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListItems;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListItemsResponse;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.Query_type0;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.Query_type0.Factory;
import com.lexisnexis.es.dms.sharepoint.authentication.NtlmJcifsCredentials;
import com.sun.org.apache.xerces.internal.impl.PropertyManager;
import com.sun.org.apache.xerces.internal.impl.XMLStreamReaderImpl;
import com.sun.xml.bind.v2.TODO;

/**
 * This tests the Lists webservice of Sharepoint<br/>
 * Tests the fact that you can connect to it using the username and password<br/>
 * At the moment it fetches the list of repositories and print them out<br/>
 * <br/>
 * Note: To test it enter valid username and password in the respective variables<br/>
 * <br/> {@link TODO} At the moment all the code is kept here because of major refactoring being done.
 * <hr/>
 * @author KaleJ
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class TestListsWebservice
{
    /** Username of the test user */
    private final String username = "kalej";

    /** Password of the test user */
    private final String password = "UrmiJee1!1";

    /** Domain of the test user */
    private final String domain = "legal.regn.net";

    @Before
    public void init()
    {
        // Authenticate using the Username & Password
        authenticate();
    }

    /**
     * This function lists the Sharepoint repositories
     * @throws RemoteException
     */
    @Test
    public void printSharepointLists() throws RemoteException
    {
        ListsStub lists = new ListsStub();
        GetListCollection req = new GetListCollection();
        GetListCollectionResponse res = lists.getListCollection(req);

        List<SpList> listCollection = new ArrayList<SpList>();
        @SuppressWarnings("rawtypes")
        Iterator children = res.getGetListCollectionResult().getExtraElement().getChildElements();
        while (children.hasNext())
        {
            OMElement element = (OMElement)children.next();
            SpList newList = new SpList(element);
            listCollection.add(newList);
        }

        for (SpList list : listCollection)
        {
            System.out.println(list.getTitle());

        }

    }

    @Test
    public void getListItem() throws XMLStreamException, Exception
    {
        ListsStub lists = new ListsStub();
        GetListItems req = new GetListItems();

        String query = "<Query><Where><Lt><FieldRef Name=\"Name\" /><Value Type=\"Counter\">3</Value></Lt></Where></Query>";

        Query_type0 qt = Query_type0.Factory.parse(new XMLStreamReaderImpl(new ByteArrayInputStream(query
                                .getBytes()), new PropertyManager(PropertyManager.CONTEXT_READER)));

        req.setQuery(qt);
        req.setListName("Shared Documents");

        GetListItemsResponse resp = lists.getListItems(req);
        List<SpList> listCollection = new ArrayList<SpList>();
        Iterator children = resp.getGetListItemsResult().getExtraElement().getChildElements();
        while (children.hasNext())
        {
            OMElement element = (OMElement)children.next();
            SpList newList = new SpList(element);
            listCollection.add(newList);
        }

        for (SpList list : listCollection)
        {
            System.out.println(list.getTitle());

        }
    }

    /**
     * This function Authenticates the User and Populate the Http header
     */
    private void authenticate()
    {
        NtlmJcifsCredentials.register(username, password, domain);
    }
}
