/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository;

import com.lexisnexis.es.dms.core.service.RequestType;
import com.lexisnexis.es.dms.repository.actions.RepositoryAction;

/**
 * An interface defining methods to get {@link RepositoryAction} instances. <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 */

public interface RepositoryActionsFactory
{
    /**
     * @param requestType RequestType for the RepositoryAction
     * @return initialized RepositoryAction instance
     * @throws UnsupportedRepositoryActionException thrown when {@link RequestType} is not supported
     */
    RepositoryAction getRepositoryAction(final RequestType requestType) throws UnsupportedRepositoryActionException;
}
