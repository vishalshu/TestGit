/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository;

/**
 * Represents exceptions thrown when interacting with document repository<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 */

public class RepositoryException extends Exception
{

    /** generated id for serialisation */
    private static final long serialVersionUID = 1L;

    /**
     * Construct the exception.
     * @param msg Message explaining what was happening when it all went pear shaped.
     */
    public RepositoryException(final String msg)
    {
        super(msg);
    }

}
