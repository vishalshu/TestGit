/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository;

/**
 * Thrown when an exception is not attempt is made to perform repository action that is not supported by
 * repository service. <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 */

public class UnsupportedRepositoryActionException extends Exception
{

    /**
     * generated id for serialisation
     */
    private static final long serialVersionUID = 6621620855844799886L;

    /**
     * Construct the exception.
     * @param msg Message explaining what was happening when it all went pear shaped.
     */
    public UnsupportedRepositoryActionException(final String msg)
    {
        super(msg);
    }

}
