/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository.actions;

/**
 * A marker abstraction for RequestType#LIST_FOLDER_CONTENTS action.<br/>
 * <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public interface ListFolderContentsAction extends RepositoryAction
{
    /**
     * Marker interface
     */
}
