/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository.actions;

import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestResult;

/**
 * Generic abstraction for all the DMS Actions which can be performed by RepositoryActionsAdapter
 * implementations. <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 */

public interface RepositoryAction
{
    /**
     * Perform action associated with the action instance
     * @param requestContext the current context
     * @return generic return value for the executed DMS action.
     */
    RequestResult execute(final RequestContext requestContext);

}
