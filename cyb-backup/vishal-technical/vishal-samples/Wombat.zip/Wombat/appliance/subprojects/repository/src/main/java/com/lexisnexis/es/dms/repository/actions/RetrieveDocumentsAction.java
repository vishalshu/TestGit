/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.repository.actions;

import com.lexisnexis.es.dms.core.service.RequestType;

/**
 * A marker abstraction for {@link RequestType#VIEW_DOCUMENTS} action.<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 */

public interface RetrieveDocumentsAction extends RepositoryAction
{
    /**
     * Marker interface
     */
}
