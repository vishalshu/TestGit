/*
 * Copyright (c) 2011 LexisNexis Axxia. All rights reserved.
 */

package com.lexisnexis.es.dms.routing;

/**
 * Manages rules for initial processing of document paths by their domain. Typical domains might be "client",
 * "finance" etc. <br/>
 * <br/>
 * <hr/>
 * @author connorb
 * @version $Revision$
 * @since 1.4
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public interface DomainRules
{
    // TODO
}
