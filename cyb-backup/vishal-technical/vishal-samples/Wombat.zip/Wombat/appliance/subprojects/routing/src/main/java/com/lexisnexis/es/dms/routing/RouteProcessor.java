/*
 * Copyright (c) 2011 LexisNexis Axxia. All rights reserved.
 */

package com.lexisnexis.es.dms.routing;

/**
 * Owns the routing tables, and processes paths against the routing tables resolved to a location. <br/>
 * <br/>
 * <hr/>
 * @author connorb
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */
public class RouteProcessor
{
    // TODO
}
