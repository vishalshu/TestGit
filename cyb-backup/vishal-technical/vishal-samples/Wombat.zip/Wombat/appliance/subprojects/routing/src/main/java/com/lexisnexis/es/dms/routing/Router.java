package com.lexisnexis.es.dms.routing;

import java.util.ArrayList;
import java.util.List;

import com.lexisnexis.es.dms.core.service.BasicDmsService;
import com.lexisnexis.es.dms.core.service.DmsServiceResult;
import com.lexisnexis.es.dms.core.service.ServiceResult;
import com.lexisnexis.es.dms.core.transaction.BulkDocumentsInfo;
import com.lexisnexis.es.dms.core.transaction.DocumentInfo;
import com.lexisnexis.es.dms.core.transaction.FolderInfo;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectInfo;
import com.lexisnexis.es.dms.core.transaction.RequestContext;

/**
 * <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author connorb
 */
public class Router extends BasicDmsService
{
    /*
     * (non-Javadoc)
     * @see
     * com.lexisnexis.es.dms.service.BasicDmsService#process(com.lexisnexis.es.dms.transaction.RequestContext)
     */
    @Override
    public DmsServiceResult process(final RequestContext currentContext)
    {
        // TODO add actual routing logic
        List<String> dummy = new ArrayList<String>();
        final RepositoryObjectInfo repoObjectInfo = currentContext.getRepositoryObjectInfo();

        String docFileName = null;
        if (repoObjectInfo instanceof DocumentInfo)
        {

            docFileName = ((DocumentInfo)currentContext.getRepositoryObjectInfo()).getDocumentFileName();
        }

        if (repoObjectInfo instanceof FolderInfo)
        {
            docFileName = ((FolderInfo)repoObjectInfo).getLocation().getLogicalPath();
        }

        if (repoObjectInfo instanceof BulkDocumentsInfo)
        {
            docFileName = ((BulkDocumentsInfo)repoObjectInfo).getDocuments().get(0).getDocumentFileName();
        }
        // Arbitrary routing logic
        if (docFileName != null && docFileName.contains("alf"))
        {
            dummy.add("ALF1");
        }

        if (docFileName != null && docFileName.contains("jr"))
        {
            dummy.add("JR1");
        }

        if (docFileName != null && docFileName.contains("sp"))
        {
            dummy.add("SP1");
        }

        if (dummy.size() == 0)
        {
            dummy.add("ALF1");
        }

        currentContext.getRepositoryObjectInfo().getLocation().setRepositoryList(dummy);
        currentContext.addEventItem("Dummy routing processed: " + dummy);
        return new ServiceResult(true, null);
    }

}
