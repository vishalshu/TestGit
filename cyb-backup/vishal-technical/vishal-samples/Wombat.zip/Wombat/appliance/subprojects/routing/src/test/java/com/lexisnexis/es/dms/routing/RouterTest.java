/*
 * Copyright (c) 2011 LexisNexis Axxia.
 * All rights reserved.
 */

package com.lexisnexis.es.dms.routing;

/**
 *
 *
 * <br/><br/><hr/>
 * @author connorb
 * @version $Revision$
 * @since 1.4
 *
 * <pre>
 * $Id$
 * </pre>
 */
public class RouterTest
{
    /**
     * @param testName Test name to run.
     */
    public RouterTest(String testName)
    {
       // super(testName);
    }

  /*  *//**
     * Main for test runs.
     *
     * @param args Command line args - ignored.
     *//*
    public static void main(String[] args)
    {
        TestRunner.run(suite());
    }

    *//**
     * Provide a TestSuite to the TestRunner
     *
     * @return A test suite for these test cases.
     *//*
    public static Test suite()
    {
        return new TestSuite(RouterTest.class);
    }*/

    /*
     * --------------- Helper Methods, setup data ---------------
     */

    /*
     * --------------- Test cases -------------------------------
     */

}
