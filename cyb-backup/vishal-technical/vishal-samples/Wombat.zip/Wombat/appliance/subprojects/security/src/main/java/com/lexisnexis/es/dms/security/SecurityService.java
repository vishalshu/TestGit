package com.lexisnexis.es.dms.security;

import com.lexisnexis.es.dms.core.service.BasicDmsService;
import com.lexisnexis.es.dms.core.service.DmsServiceResult;
import com.lexisnexis.es.dms.core.service.ServiceResult;
import com.lexisnexis.es.dms.core.transaction.RequestContext;

/**
 * Examines the context to determine whether the current user has the clearance to perform the requested
 * transaction. <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public class SecurityService extends BasicDmsService
{
    /*
     * (non-Javadoc)
     * @see com.lexisnexis.es.dms.service.DmsService#process(com.lexisnexis.es.dms.transaction.Context)
     */
    @Override
    public DmsServiceResult process(final RequestContext currentContext)
    {
        if (currentContext != null)
        {
            // TODO actually check something!
            return new ServiceResult(true, null);
        }
        else
        {
            throw new IllegalArgumentException();
        }
    }

}
