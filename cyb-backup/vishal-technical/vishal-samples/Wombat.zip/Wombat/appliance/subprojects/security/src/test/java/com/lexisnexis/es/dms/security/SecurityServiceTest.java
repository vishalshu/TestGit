package com.lexisnexis.es.dms.security;

import org.junit.Test;

/**
 * Test the SecurityService class.
 * <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */

public class SecurityServiceTest
{
    /**
     * Tests when the context is null - should throw exception
     */
    @Test (expected=IllegalArgumentException.class)
    public void testNullContext()
    {
        SecurityService securityService = new SecurityService();
        securityService.process(null);
    }

}
