/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.service;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author OMahonyJ
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class LNServiceException extends Exception
{

    /**
     * generated id for serialisation
     */
    private static final long serialVersionUID = -4210533233426640898L;

    /**
     * Construct the exception.
     * @param msg Message explaining what was happening when it all went pear shaped.
     */
    public LNServiceException(final String msg)
    {
        super(msg);
    }

    /**
     * Construct the exception.
     * @param msg Message explaining what was happening when it all went pear shaped.
     * @param cause Underlying exception.
     */
    public LNServiceException(final String msg, final Throwable cause)
    {
        super(msg, cause);
    }

}
