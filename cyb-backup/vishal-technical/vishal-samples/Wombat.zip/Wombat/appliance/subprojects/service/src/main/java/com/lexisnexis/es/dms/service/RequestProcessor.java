package com.lexisnexis.es.dms.service;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

import com.lexisnexis.es.dms.core.service.BasicRequestContextEvent;
import com.lexisnexis.es.dms.core.service.BasicRequestContextEventItem;
import com.lexisnexis.es.dms.core.service.DmsService;
import com.lexisnexis.es.dms.core.service.DmsServiceResult;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestContextEvent;
import com.lexisnexis.es.utilities.exceptions.LNConfigurationException;

/**
 * Receives incoming requests to the server, and feeds them to the current set of services <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */

public class RequestProcessor
{
    /**
     * A reference to an implementation of the SeviceLookup interface
     */
    private ServiceLookup serviceLookup = null;

    /**
     * process the request. Accesses the list of services that have been defined for this application and
     * executes each one in turn.
     * @param currentContext the request context
     * @throws LNConfigurationException a configuration issue
     * @throws FileNotFoundException if file does not exist
     */
    public void process(final RequestContext currentContext) throws FileNotFoundException,
                                                            LNConfigurationException
    {
        if (currentContext != null)
        {
            List<DmsService> manifest = serviceLookup.getRequestServices();
            Stack<DmsService> serviceStack = new Stack<DmsService>();
            boolean keepGoing = true;
            // set up the services in a stack
            populateStack(serviceStack, manifest);
            while (!serviceStack.empty())
            {
                DmsService service = serviceStack.pop();
                // only process the service if everything is OK so far, or it is mandatory
                if (keepGoing || service.getMandatory())
                {
                    RequestContextEvent event = new BasicRequestContextEvent(service);
                    currentContext.addEvent(event);
                    DmsServiceResult serviceResult = service.process(currentContext);
                    if (serviceResult.getAdditionalServices() != null)
                    {
                        // if we have additional services, add them to the stack
                        populateStack(serviceStack, serviceResult.getAdditionalServices());
                        event.addEventItem(new BasicRequestContextEventItem("services added"));
                    }
                    keepGoing = keepGoing & serviceResult.isSuccess();
                    event.addEventItem(new BasicRequestContextEventItem("processed"));
                    // TODO this (conditionally) goes to a log:
                    System.out.println(event.getReport());
                }
            }
        }
        else
        {
            throw new IllegalArgumentException();
        }
    }

    /**
     * takes a list of services and pushes them onto the top of a stack of services. the order of the list is
     * maintained, so that, on return, the first item in the list will be the first one to pop off the stack.
     * @param serviceStack a stack of services
     * @param servicesList services that will be pushed on to the stack (pushed on in reverse order)
     */
    private void populateStack(final Stack<DmsService> serviceStack,
                               final List<DmsService> servicesList)
    {
        // Reverse the list so that the first one in the list will be 'popped' first off the stack.
        // We do this on a copy so we don't be mess up the original list order
        List<DmsService> servicesCopy = new ArrayList<DmsService>(servicesList);
        Collections.reverse(servicesCopy);
        serviceStack.addAll(servicesCopy);
    }

    /**
     * @return the serviceLookup
     */
    public ServiceLookup getServiceLookup()
    {
        return serviceLookup;
    }

    /**
     * @param serviceLookup the serviceLookup to set
     */
    public void setServiceLookup(final ServiceLookup serviceLookup)
    {
        this.serviceLookup = serviceLookup;
    }

}
