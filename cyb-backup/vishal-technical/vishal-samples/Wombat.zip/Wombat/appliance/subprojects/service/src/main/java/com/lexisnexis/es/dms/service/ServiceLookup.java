package com.lexisnexis.es.dms.service;

import java.util.List;

import com.lexisnexis.es.dms.core.service.DmsService;
import com.lexisnexis.es.utilities.exceptions.LNConfigurationException;

/**
 * Interface defining the methods provided by a service locator. <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */
public interface ServiceLookup
{

    /**
     * @return the list of services
     * @throws LNConfigurationException a configuration issue
     */
    public List<DmsService> getRequestServices() throws LNConfigurationException;

}
