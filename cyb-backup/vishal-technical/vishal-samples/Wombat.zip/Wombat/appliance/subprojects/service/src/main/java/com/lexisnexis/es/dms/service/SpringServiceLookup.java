/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */
package com.lexisnexis.es.dms.service;

import java.util.List;

import com.lexisnexis.es.dms.core.service.DmsService;
import com.lexisnexis.es.utilities.exceptions.LNConfigurationException;

/**
 * The ServiceLookup implementation class, which is responsible for providing list of services that need to be
 * applied to incoming requests. <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 */

public class SpringServiceLookup implements ServiceLookup
{

    /**
     * The services list injected by spring container
     */
    private final List<DmsService> servicesList;

    /**
     * @param servicesList the list of services injected by the springn container
     */
    public SpringServiceLookup(final List<DmsService> servicesList)
    {
        super();
        this.servicesList = servicesList;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<DmsService> getRequestServices() throws LNConfigurationException
    {
        if (servicesList == null || servicesList.size() == 0)
        {
            throw new LNConfigurationException("No services defined.");
        }

        return servicesList;
    }
}
