package com.lexisnexis.es.dms.service;

import java.io.FileNotFoundException;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lexisnexis.es.utilities.exceptions.LNConfigurationException;

/**
 * A test class for the RequestProcessor. <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */

public class RequestProcessorTest
{
    /**
     * applicationContext to be used to perform unit test
     */
    private ApplicationContext appContext;

    /**
     * setup before performing test
     */
    @Before
    public void setup()
    {
        appContext = new ClassPathXmlApplicationContext("springconfig/test-services-applicationContext.xml");

    }

    /**
     * Tests when the context is null
     * @throws LNConfigurationException a configuration issue
     * @throws FileNotFoundException if file does not exist
     * @throws LNServiceException if there is an issue with getting services
     */
    @Test(expected = IllegalArgumentException.class)
    public void testNullContext() throws FileNotFoundException, LNConfigurationException, LNServiceException
    {
        RequestProcessor rp = new RequestProcessor();
        rp.process(null);
    }

    // TODO add more tests when we have a RequestContext implementation

}
