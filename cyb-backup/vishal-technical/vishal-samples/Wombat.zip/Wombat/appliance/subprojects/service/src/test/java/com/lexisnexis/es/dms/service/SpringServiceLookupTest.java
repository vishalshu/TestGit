/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.service;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lexisnexis.es.dms.core.service.DmsService;
import com.lexisnexis.es.utilities.exceptions.LNConfigurationException;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class SpringServiceLookupTest
{
    /**
     * applicationContext to be used to perform unit test
     */
    private ApplicationContext appContext;

    /**
     * setup before performing test
     */
    @Before
    public void setup()
    {
        appContext = new ClassPathXmlApplicationContext("springconfig/services-applicationContext.xml",
                                                                           "springconfig/test-services-applicationContext.xml");

    }

    /**
     * Tests when no services are defined in spring config file
     * @throws LNConfigurationException a configuration issue
     */
    @Test(expected = LNConfigurationException.class)
    public void invalidOrNoServicesTest() throws LNConfigurationException
    {
        SpringServiceLookup serviceLookup = appContext.getBean("invalidOrNoServicesTest",
                                                                       SpringServiceLookup.class);
        // this line should cause the exception, so no need to assign result to anything
        serviceLookup.getRequestServices();
    }

    /**
     * Tests when the service xml file does contain services
     * @throws LNConfigurationException a configuration issue
     */
    @Test
    public void validServicesTest() throws LNConfigurationException
    {
        SpringServiceLookup serviceLookup = appContext.getBean("springServiceLookup",
                                                               SpringServiceLookup.class);

        List<DmsService> servicesList = serviceLookup.getRequestServices();
        assertTrue(servicesList != null);
        assertTrue(servicesList.size() != 0);
    }
}
