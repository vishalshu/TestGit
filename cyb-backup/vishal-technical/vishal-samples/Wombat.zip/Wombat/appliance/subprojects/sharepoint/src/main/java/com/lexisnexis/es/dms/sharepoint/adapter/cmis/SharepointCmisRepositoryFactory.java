/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.sharepoint.adapter.cmis;

import java.util.Map;

import org.apache.chemistry.opencmis.client.api.Repository;

import com.lexisnexis.es.dms.adapter.cmis.CmisRepositoryFactory;
import com.lexisnexis.es.dms.repository.RepositoryException;

/**
 * Factory used for CMIS access to a sharepoint repository. <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class SharepointCmisRepositoryFactory extends CmisRepositoryFactory
{

    /**
     * @param sessionParameters
     */
    public SharepointCmisRepositoryFactory(final Map<String, String> sessionParameters)
    {
        super(sessionParameters);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Repository getRepository() throws RepositoryException
    {
        if (repositories != null && repositories.size() > 0)
        {
            // for sharepoint, we need a specific repository ("Shared Documents?), for the others, there is
            // just one repository
            for (Repository rep : repositories)
            {
                if (rep.getName().equalsIgnoreCase("Shared Documents"))
                {
                    return rep;
                }

            }
        }
        throw new RepositoryException("Could not fetch a valid repository instance");
    }

}
