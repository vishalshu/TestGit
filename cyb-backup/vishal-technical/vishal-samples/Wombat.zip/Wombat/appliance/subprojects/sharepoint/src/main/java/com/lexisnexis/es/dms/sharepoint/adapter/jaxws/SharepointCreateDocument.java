/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.sharepoint.adapter.jaxws;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.Holder;

import org.apache.axis2.databinding.ADBException;

import com.lexisnexis.es.dms.core.service.BasicDocumentRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestResult;
import com.lexisnexis.es.dms.core.transaction.RequestResultImpl;
import com.lexisnexis.es.dms.repository.actions.CreateDocumentAction;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.Copy;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.CopyIntoItems;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.CopyResult;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.CopyResultCollection;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.DestinationUrlCollection;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.FieldInformationCollection;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.Lists;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.ListsSoap;
import com.lexisnexis.es.dms.sharepoint.authentication.NtlmJcifsCredentials;

/**
 * Webservice client to add document into Sharepoint.<br/>
 * <br/>
 * <hr/>
 * @author kalej
 */

public class SharepointCreateDocument implements CreateDocumentAction
{
    /** Document folder location inside the Sharepoint repository */
    private final String documentPath = "lndms/client/00000001/00000002";

    /** Repository path for the Sharepoint */
    private final String repositoryPath;

    /** Document name to be created in the Sharepoint repository */
    private String fileName = "tempName.txt";

    /**
     * C'tor called by the bean declarations
     * @param repoPath Repository path for the Sharepoint
     */
    public SharepointCreateDocument(final String repoPath)
    {
        repositoryPath = repoPath;
    }

    /**
     * Sets the filename to be stored in Sharepoint repository
     * @param fname file name
     */
    public void setFileName(final String fname)
    {
        fileName = fname;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestResult execute(final RequestContext requestContext)
    {
        try
        {
            // TODO: At the moment, we are just using the document from the resource
            addDocument(Thread.currentThread().getContextClassLoader().getResource("docToUpload.txt"));
        }
        catch (RemoteException re)
        {
            re.printStackTrace();
        }
        catch (URISyntaxException ue)
        {
            ue.printStackTrace();
        }
        catch (ADBException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return new RequestResultImpl()
        {
            /**
             * {@inheritDoc}
             */
            @Override
            public List<RepositoryObject> getResults()
            {
                List<RepositoryObject> result = new ArrayList<RepositoryObject>();

                BasicDocumentRepositoryObject ro = new BasicDocumentRepositoryObject();
                ro.setId(fileName);
                result.add(ro);

                return result;
            }
        };
    }

    /**
     * This function will add the Document to Sharepoint
     * @param docUrl URL of the document that needs to be uploaded
     * @throws RemoteException
     * @throws URISyntaxException
     * @throws ADBException
     */
    private void addDocument(final URL docUrl) throws RemoteException, URISyntaxException, ADBException
    {
        authenticate();

        try
        {
            CopyIntoItems request = new CopyIntoItems();

            DestinationUrlCollection destUrls = new DestinationUrlCollection();
            String sharepointFilePath = repositoryPath + documentPath + "/" + fileName;

            // destUrls.addString(sharepointFilePath);
            destUrls.getString().add(sharepointFilePath);

            // request.setDestinationUrls(destUrls);

            // request.setSourceUrl(docUrl.toString());

            File file = new File(docUrl.toURI());

            byte[] fileDataBytes = null;
            try
            {
                FileInputStream fileDataSource = new FileInputStream(file);
                // TODO: what to do is file sizeis greater than int ?
                int length = (int)file.length();
                fileDataBytes = new byte[length];
                fileDataSource.read(fileDataBytes, 0, length);
                // request.setStream(fileDataBytes);
            }
            catch (FileNotFoundException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            catch (IOException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            FieldInformationCollection fic = new FieldInformationCollection();
            // fic.getFieldInformation().add(new FieldInformation[0]); // why add an empty list ?
            // request.setFields(fic);

            Holder<Long> copyIntoItemsResult = new Holder<Long>();
            Holder<CopyResultCollection> results = new Holder<CopyResultCollection>();
            Copy copy = new Copy();
            copy.getCopySoap().copyIntoItems(docUrl.toString(), destUrls,
                                                                fic,
                                                                fileDataBytes,
                                                                copyIntoItemsResult,
                                                                results);

            /*
             * Iterator children = response.getResults() .getOMElement(response.MY_QNAME,
             * OMAbstractFactory.getOMFactory()) .getChildren(); while (children.hasNext()) { OMElement
             * element = (OMElement)children.next(); SpListItem item = new SpListItem(element);
             * System.out.println(item.getId()); }
             */

            for (CopyResult result : results.value.getCopyResult())
            {
                System.out.println(result.getErrorMessage() == null ? "Added Document: " + fileName :
                                                                   result.getErrorMessage());

            }

            checkInFile(sharepointFilePath);

        }
        finally
        {
            // copy.cleanup();
        }
    }

    /**
     * Function to checkin the document
     * @param sharepointFilePath
     * @throws RemoteException
     */
    private void checkInFile(final String sharepointFilePath) throws RemoteException
    {
        // Need to Check in the file, as Sharepoint keeps it checked out
        Lists lists = new Lists();
        ListsSoap listsSoap = lists.getListsSoap();
        // CheckInFile checkIn = new CheckInFile();
        // checkIn.setComment("Checking in after adding the document");
        // checkIn.setPageUrl(sharepointFilePath);
        listsSoap
                                .checkInFile(sharepointFilePath,
                                             "Checking in after adding the document",
                                             "2"); // "OverwriteCheckIn"
    }

    /**
     * This function Authenticates the User and Populate the Http header
     */
    private void authenticate()
    {
        NtlmJcifsCredentials.register("CampbePa", "August2011", "legal.regn.net");
    }
}
