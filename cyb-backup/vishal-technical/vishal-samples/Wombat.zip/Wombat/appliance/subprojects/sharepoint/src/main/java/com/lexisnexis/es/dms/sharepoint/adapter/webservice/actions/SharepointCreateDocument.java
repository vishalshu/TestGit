/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.sharepoint.adapter.webservice.actions;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;

import org.apache.axis2.databinding.ADBException;

import com.lexisnexis.es.dms.core.service.BasicDocumentRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.DocumentInfo;
import com.lexisnexis.es.dms.core.transaction.RepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestResult;
import com.lexisnexis.es.dms.core.transaction.RequestResultImpl;
import com.lexisnexis.es.dms.repository.actions.CreateDocumentAction;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.copy.CopyStub;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.copy.CopyStub.CopyIntoItems;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.copy.CopyStub.CopyIntoItemsResponse;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.copy.CopyStub.CopyResult;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.copy.CopyStub.DestinationUrlCollection;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.copy.CopyStub.FieldInformation;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.copy.CopyStub.FieldInformationCollection;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub;
import com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.CheckInFile;
import com.lexisnexis.es.dms.sharepoint.authentication.NtlmJcifsCredentials;

/**
 * Webservice client to add document into Sharepoint.<br/>
 * <br/>
 * <hr/>
 * @author kalej
 */
@Deprecated
public class SharepointCreateDocument implements CreateDocumentAction
{
    /** Document folder location inside the Sharepoint repository */
    private String documentPath = "";

    /** Repository path for the Sharepoint */
    private final String repositoryPath;

    /** Document name to be created in the Sharepoint repository */
    private String fileName = "tempName.txt";

    /**
     * C'tor called by the bean declarations
     * @param repoPath Repository path for the Sharepoint
     */
    public SharepointCreateDocument(final String repoPath)
    {
        repositoryPath = repoPath;
    }

    /**
     * Sets the filename to be stored in Sharepoint repository
     * @param fname file name
     */
    public void setFileName(final String fname)
    {
        fileName = fname;
    }

    /**
     * 
     */
    public SharepointCreateDocument()
    {
        repositoryPath = "";
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestResult execute(final RequestContext requestContext)
    {
        try
        {
            final DocumentInfo info = (DocumentInfo)requestContext.getRepositoryObjectInfo();
            documentPath = info.getLocation().getLogicalPath();

            // TODO: At the moment, we are just using the document from the resource
            addDocument(Thread.currentThread().getContextClassLoader().getResource("docToUpload.txt"));
        }
        catch (RemoteException re)
        {
            re.printStackTrace();
        }
        catch (URISyntaxException ue)
        {
            ue.printStackTrace();
        }
        catch (ADBException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return new RequestResultImpl()
        {
            /**
             * {@inheritDoc}
             */
            @Override
            public List<RepositoryObject> getResults()
            {
                List<RepositoryObject> result = new ArrayList<RepositoryObject>();

                BasicDocumentRepositoryObject ro = new BasicDocumentRepositoryObject();
                ro.setId(fileName);
                result.add(ro);

                return result;
            }
        };
    }

    /**
     * This function will add the Document to Sharepoint
     * @param docUrl URL of the document that needs to be uploaded
     * @throws RemoteException
     * @throws URISyntaxException
     * @throws ADBException
     */
    private void addDocument(final URL docUrl) throws RemoteException, URISyntaxException, ADBException
    {
        authenticate();

        CopyStub copy = new CopyStub();

        try
        {
            CopyIntoItems request = new CopyIntoItems();

            DestinationUrlCollection destUrls = new DestinationUrlCollection();
            String sharepointFilePath = repositoryPath + documentPath + "/" + fileName;

            destUrls.addString(sharepointFilePath);
            request.setDestinationUrls(destUrls);

            request.setSourceUrl(docUrl.toString());

            File file = new File(docUrl.toURI());
            FileDataSource fileDataSource = new FileDataSource(file);
            DataHandler dataHandler = new DataHandler(fileDataSource);
            request.setStream(dataHandler);

            FieldInformationCollection fic = new FieldInformationCollection();
            fic.setFieldInformation(new FieldInformation[0]);
            request.setFields(fic);

            CopyIntoItemsResponse response = copy.copyIntoItems(request);

            /*
             * Iterator children = response.getResults() .getOMElement(response.MY_QNAME,
             * OMAbstractFactory.getOMFactory()) .getChildren(); while (children.hasNext()) { OMElement
             * element = (OMElement)children.next(); SpListItem item = new SpListItem(element);
             * System.out.println(item.getId()); }
             */

            for (CopyResult result : response.getResults().getCopyResult())
            {
                System.out.println(result.getErrorMessage() == null ? "Added Document: " + fileName :
                                                                   result.getErrorMessage());

            }

            checkInFile(sharepointFilePath);

        }
        finally
        {
            copy.cleanup();
        }
    }

    /**
     * Function to checkin the document
     * @param sharepointFilePath
     * @throws RemoteException
     */
    private void checkInFile(final String sharepointFilePath) throws RemoteException
    {
        // Need to Check in the file, as Sharepoint keeps it checked out
        ListsStub lists = new ListsStub();
        CheckInFile checkIn = new CheckInFile();
        checkIn.setComment("Checking in after adding the document");
        checkIn.setPageUrl(sharepointFilePath);
        lists.checkInFile(checkIn);
    }

    /**
     * This function Authenticates the User and Populate the Http header
     */
    private void authenticate()
    {
        NtlmJcifsCredentials.register("username", "password", "legal.regn.net");
    }
}
