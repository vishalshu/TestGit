/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.sharepoint.adapter.webservice.actions;

import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestResult;
import com.lexisnexis.es.dms.repository.actions.CreateFolderAction;

/**
 * Sharepoint implementation for CreateFolder.<br/>
 * <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 */
@Deprecated
public class SharepointCreateFolder implements CreateFolderAction
{

    /**
     * {@inheritDoc}
     */
    @Override
    public RequestResult execute(final RequestContext requestContext)
    {
        // TODO Auto-generated method stub
        return null;
    }

}
