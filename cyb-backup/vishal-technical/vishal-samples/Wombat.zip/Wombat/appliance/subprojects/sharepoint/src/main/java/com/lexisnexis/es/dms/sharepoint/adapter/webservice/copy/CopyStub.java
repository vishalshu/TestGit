/**
 * CopyStub.java This file was auto-generated from WSDL by the Apache Axis2 version: 1.5.5 Built on : May 28,
 * 2011 (08:30:56 CEST)
 */
package com.lexisnexis.es.dms.sharepoint.adapter.webservice.copy;


/*
 * CopyStub java implementation
 */
@Deprecated
public class CopyStub extends org.apache.axis2.client.Stub
{
    protected org.apache.axis2.description.AxisOperation[] _operations;

    // hashmaps to keep the fault mapping
    private final java.util.HashMap faultExceptionNameMap = new java.util.HashMap();

    private final java.util.HashMap faultExceptionClassNameMap = new java.util.HashMap();

    private final java.util.HashMap faultMessageMap = new java.util.HashMap();

    private static int counter = 0;

    private static synchronized java.lang.String getUniqueSuffix()
    {
        // reset the counter if it is greater than 99999
        if (counter > 99999)
        {
            counter = 0;
        }
        counter = counter + 1;
        return java.lang.Long.toString(java.lang.System.currentTimeMillis()) + "_" + counter;
    }

    private void populateAxisService() throws org.apache.axis2.AxisFault
    {

        // creating the Service with a unique name
        _service = new org.apache.axis2.description.AxisService("Copy" + getUniqueSuffix());
        addAnonymousOperations();

        // creating the operations
        org.apache.axis2.description.AxisOperation __operation;

        _operations = new org.apache.axis2.description.AxisOperation[3];

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                          "copyIntoItemsLocal"));
        _service.addOperation(__operation);

        _operations[0] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                          "getItem"));
        _service.addOperation(__operation);

        _operations[1] = __operation;

        __operation = new org.apache.axis2.description.OutInAxisOperation();

        __operation.setName(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                          "copyIntoItems"));
        _service.addOperation(__operation);

        _operations[2] = __operation;

    }

    // populates the faults
    private void populateFaults()
    {

    }

    /**
     * Constructor that takes in a configContext
     */

    public CopyStub(final org.apache.axis2.context.ConfigurationContext configurationContext,
                    final java.lang.String targetEndpoint)
                                                          throws org.apache.axis2.AxisFault
    {
        this(configurationContext, targetEndpoint, false);
    }

    /**
     * Constructor that takes in a configContext and useseperate listner
     */
    public CopyStub(final org.apache.axis2.context.ConfigurationContext configurationContext,
                    final java.lang.String targetEndpoint, final boolean useSeparateListener)
                                                                                             throws org.apache.axis2.AxisFault
    {
        // To populate AxisService
        populateAxisService();
        populateFaults();

        _serviceClient = new org.apache.axis2.client.ServiceClient(configurationContext, _service);

        _serviceClient.getOptions().setTo(new org.apache.axis2.addressing.EndpointReference(
                                                                                            targetEndpoint));
        _serviceClient.getOptions().setUseSeparateListener(useSeparateListener);

        // Set the soap version
        _serviceClient
                                .getOptions()
                                .setSoapVersionURI(org.apache.axiom.soap.SOAP12Constants.SOAP_ENVELOPE_NAMESPACE_URI);

    }

    /**
     * Default Constructor
     */
    public CopyStub(final org.apache.axis2.context.ConfigurationContext configurationContext) throws org.apache.axis2.AxisFault
    {

        this(configurationContext, "http://lngtwyappd022v/_vti_bin/copy.asmx");

    }

    /**
     * Default Constructor
     */
    public CopyStub() throws org.apache.axis2.AxisFault
    {

        this("http://lngtwyappd022v/_vti_bin/copy.asmx");

    }

    /**
     * Constructor taking the target endpoint
     */
    public CopyStub(final java.lang.String targetEndpoint) throws org.apache.axis2.AxisFault
    {
        this(null, targetEndpoint);
    }

    /**
     * Auto generated method signature
     * @see com.sts.copy.Copy#copyIntoItemsLocal
     * @param copyIntoItemsLocal0
     */

    public CopyStub.CopyIntoItemsLocalResponse copyIntoItemsLocal(

    final CopyStub.CopyIntoItemsLocal copyIntoItemsLocal0)

    throws java.rmi.RemoteException

    {
        org.apache.axis2.context.MessageContext _messageContext = null;
        try
        {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient
                                    .createClient(_operations[0].getName());
            _operationClient
                                    .getOptions()
                                    .setAction("http://schemas.microsoft.com/sharepoint/soap/CopyIntoItemsLocal");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                                         org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                                         "&");

            // create a message context
            _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;

            env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    copyIntoItemsLocal0,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                                  "copyIntoItemsLocal")));

            // adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            // execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient
                                    .getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement(),
                                             CopyStub.CopyIntoItemsLocalResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

            return (CopyStub.CopyIntoItemsLocalResponse)object;

        }
        catch (org.apache.axis2.AxisFault f)
        {

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt != null)
            {
                if (faultExceptionNameMap.containsKey(faultElt.getQName()))
                {
                    // make the fault by reflection
                    try
                    {
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap
                                                .get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex =
                                                 (java.lang.Exception)exceptionClass.newInstance();
                        // message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt
                                                .getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt, messageClass, null);
                        java.lang.reflect.Method m = exceptionClass
                                                .getMethod("setFaultMessage",
                                                           new java.lang.Class[] {messageClass});
                        m.invoke(ex, new java.lang.Object[] {messageObject});

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }
                    catch (java.lang.ClassCastException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.ClassNotFoundException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.NoSuchMethodException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.reflect.InvocationTargetException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.IllegalAccessException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.InstantiationException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }
                else
                {
                    throw f;
                }
            }
            else
            {
                throw f;
            }
        }
        finally
        {
            if (_messageContext.getTransportOut() != null)
            {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
    }

    /**
     * Auto generated method signature for Asynchronous Invocations
     * @see com.sts.copy.Copy#startcopyIntoItemsLocal
     * @param copyIntoItemsLocal0
     */
    public void startcopyIntoItemsLocal(

    final CopyStub.CopyIntoItemsLocal copyIntoItemsLocal0,

    final CopyCallbackHandler callback)

    throws java.rmi.RemoteException
    {

        org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[0]
                                .getName());
        _operationClient.getOptions()
                                .setAction("http://schemas.microsoft.com/sharepoint/soap/CopyIntoItemsLocal");
        _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

        addPropertyToOperationClient(_operationClient,
                                     org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                                     "&");

        // create SOAP envelope with that payload
        org.apache.axiom.soap.SOAPEnvelope env = null;
        final org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

        // Style is Doc.

        env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    copyIntoItemsLocal0,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                                  "copyIntoItemsLocal")));

        // adding SOAP soap_headers
        _serviceClient.addHeadersToEnvelope(env);
        // create message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message context to the operation client
        _operationClient.addMessageContext(_messageContext);

        _operationClient.setCallback(new org.apache.axis2.client.async.AxisCallback()
        {
            public void onMessage(final org.apache.axis2.context.MessageContext resultContext)
            {
                try
                {
                    org.apache.axiom.soap.SOAPEnvelope resultEnv = resultContext.getEnvelope();

                    java.lang.Object object = fromOM(resultEnv.getBody().getFirstElement(),
                                                                         CopyStub.CopyIntoItemsLocalResponse.class,
                                                                         getEnvelopeNamespaces(resultEnv));
                    callback.receiveResultcopyIntoItemsLocal(
                                            (CopyStub.CopyIntoItemsLocalResponse)object);

                }
                catch (org.apache.axis2.AxisFault e)
                {
                    callback.receiveErrorcopyIntoItemsLocal(e);
                }
            }

            public void onError(final java.lang.Exception error)
            {
                if (error instanceof org.apache.axis2.AxisFault)
                {
                    org.apache.axis2.AxisFault f = (org.apache.axis2.AxisFault)error;
                    org.apache.axiom.om.OMElement faultElt = f.getDetail();
                    if (faultElt != null)
                    {
                        if (faultExceptionNameMap.containsKey(faultElt.getQName()))
                        {
                            // make the fault by reflection
                            try
                            {
                                java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap
                                                        .get(faultElt.getQName());
                                java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                                java.lang.Exception ex =
                                                         (java.lang.Exception)exceptionClass.newInstance();
                                // message class
                                java.lang.String messageClassName = (java.lang.String)faultMessageMap
                                                        .get(faultElt.getQName());
                                java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                                java.lang.Object messageObject = fromOM(faultElt, messageClass, null);
                                java.lang.reflect.Method m = exceptionClass
                                                        .getMethod("setFaultMessage",
                                                                   new java.lang.Class[] {messageClass});
                                m.invoke(ex, new java.lang.Object[] {messageObject});

                                callback.receiveErrorcopyIntoItemsLocal(new java.rmi.RemoteException(ex
                                                        .getMessage(), ex));
                            }
                            catch (java.lang.ClassCastException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItemsLocal(f);
                            }
                            catch (java.lang.ClassNotFoundException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItemsLocal(f);
                            }
                            catch (java.lang.NoSuchMethodException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItemsLocal(f);
                            }
                            catch (java.lang.reflect.InvocationTargetException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItemsLocal(f);
                            }
                            catch (java.lang.IllegalAccessException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItemsLocal(f);
                            }
                            catch (java.lang.InstantiationException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItemsLocal(f);
                            }
                            catch (org.apache.axis2.AxisFault e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItemsLocal(f);
                            }
                        }
                        else
                        {
                            callback.receiveErrorcopyIntoItemsLocal(f);
                        }
                    }
                    else
                    {
                        callback.receiveErrorcopyIntoItemsLocal(f);
                    }
                }
                else
                {
                    callback.receiveErrorcopyIntoItemsLocal(error);
                }
            }

            public void onFault(final org.apache.axis2.context.MessageContext faultContext)
            {
                org.apache.axis2.AxisFault fault = org.apache.axis2.util.Utils
                                        .getInboundFaultFromMessageContext(faultContext);
                onError(fault);
            }

            public void onComplete()
            {
                try
                {
                    _messageContext.getTransportOut().getSender().cleanup(_messageContext);
                }
                catch (org.apache.axis2.AxisFault axisFault)
                {
                    callback.receiveErrorcopyIntoItemsLocal(axisFault);
                }
            }
        });

        org.apache.axis2.util.CallbackReceiver _callbackReceiver = null;
        if (_operations[0].getMessageReceiver() == null && _operationClient.getOptions()
                                    .isUseSeparateListener())
        {
            _callbackReceiver = new org.apache.axis2.util.CallbackReceiver();
            _operations[0].setMessageReceiver(
                                    _callbackReceiver);
        }

        // execute the operation client
        _operationClient.execute(false);

    }

    /**
     * Auto generated method signature
     * @see com.sts.copy.Copy#getItem
     * @param getItem2
     */

    public CopyStub.GetItemResponse getItem(

    final CopyStub.GetItem getItem2)

    throws java.rmi.RemoteException

    {
        org.apache.axis2.context.MessageContext _messageContext = null;
        try
        {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient
                                    .createClient(_operations[1].getName());
            _operationClient.getOptions().setAction("http://schemas.microsoft.com/sharepoint/soap/GetItem");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                                         org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                                         "&");

            // create a message context
            _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;

            env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    getItem2,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                                  "getItem")));

            // adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            // execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient
                                    .getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement(),
                                             CopyStub.GetItemResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

            return (CopyStub.GetItemResponse)object;

        }
        catch (org.apache.axis2.AxisFault f)
        {

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt != null)
            {
                if (faultExceptionNameMap.containsKey(faultElt.getQName()))
                {
                    // make the fault by reflection
                    try
                    {
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap
                                                .get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex =
                                                 (java.lang.Exception)exceptionClass.newInstance();
                        // message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt
                                                .getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt, messageClass, null);
                        java.lang.reflect.Method m = exceptionClass
                                                .getMethod("setFaultMessage",
                                                           new java.lang.Class[] {messageClass});
                        m.invoke(ex, new java.lang.Object[] {messageObject});

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }
                    catch (java.lang.ClassCastException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.ClassNotFoundException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.NoSuchMethodException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.reflect.InvocationTargetException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.IllegalAccessException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.InstantiationException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }
                else
                {
                    throw f;
                }
            }
            else
            {
                throw f;
            }
        }
        finally
        {
            if (_messageContext.getTransportOut() != null)
            {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
    }

    /**
     * Auto generated method signature for Asynchronous Invocations
     * @see com.sts.copy.Copy#startgetItem
     * @param getItem2
     */
    public void startgetItem(

    final CopyStub.GetItem getItem2,

    final CopyCallbackHandler callback)

    throws java.rmi.RemoteException
    {

        org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[1]
                                .getName());
        _operationClient.getOptions().setAction("http://schemas.microsoft.com/sharepoint/soap/GetItem");
        _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

        addPropertyToOperationClient(_operationClient,
                                     org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                                     "&");

        // create SOAP envelope with that payload
        org.apache.axiom.soap.SOAPEnvelope env = null;
        final org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

        // Style is Doc.

        env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    getItem2,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                                  "getItem")));

        // adding SOAP soap_headers
        _serviceClient.addHeadersToEnvelope(env);
        // create message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message context to the operation client
        _operationClient.addMessageContext(_messageContext);

        _operationClient.setCallback(new org.apache.axis2.client.async.AxisCallback()
        {
            public void onMessage(final org.apache.axis2.context.MessageContext resultContext)
            {
                try
                {
                    org.apache.axiom.soap.SOAPEnvelope resultEnv = resultContext.getEnvelope();

                    java.lang.Object object = fromOM(resultEnv.getBody().getFirstElement(),
                                                                         CopyStub.GetItemResponse.class,
                                                                         getEnvelopeNamespaces(resultEnv));
                    callback.receiveResultgetItem(
                                            (CopyStub.GetItemResponse)object);

                }
                catch (org.apache.axis2.AxisFault e)
                {
                    callback.receiveErrorgetItem(e);
                }
            }

            public void onError(final java.lang.Exception error)
            {
                if (error instanceof org.apache.axis2.AxisFault)
                {
                    org.apache.axis2.AxisFault f = (org.apache.axis2.AxisFault)error;
                    org.apache.axiom.om.OMElement faultElt = f.getDetail();
                    if (faultElt != null)
                    {
                        if (faultExceptionNameMap.containsKey(faultElt.getQName()))
                        {
                            // make the fault by reflection
                            try
                            {
                                java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap
                                                        .get(faultElt.getQName());
                                java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                                java.lang.Exception ex =
                                                         (java.lang.Exception)exceptionClass.newInstance();
                                // message class
                                java.lang.String messageClassName = (java.lang.String)faultMessageMap
                                                        .get(faultElt.getQName());
                                java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                                java.lang.Object messageObject = fromOM(faultElt, messageClass, null);
                                java.lang.reflect.Method m = exceptionClass
                                                        .getMethod("setFaultMessage",
                                                                   new java.lang.Class[] {messageClass});
                                m.invoke(ex, new java.lang.Object[] {messageObject});

                                callback
                                                        .receiveErrorgetItem(new java.rmi.RemoteException(ex
                                                                                .getMessage(), ex));
                            }
                            catch (java.lang.ClassCastException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorgetItem(f);
                            }
                            catch (java.lang.ClassNotFoundException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorgetItem(f);
                            }
                            catch (java.lang.NoSuchMethodException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorgetItem(f);
                            }
                            catch (java.lang.reflect.InvocationTargetException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorgetItem(f);
                            }
                            catch (java.lang.IllegalAccessException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorgetItem(f);
                            }
                            catch (java.lang.InstantiationException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorgetItem(f);
                            }
                            catch (org.apache.axis2.AxisFault e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorgetItem(f);
                            }
                        }
                        else
                        {
                            callback.receiveErrorgetItem(f);
                        }
                    }
                    else
                    {
                        callback.receiveErrorgetItem(f);
                    }
                }
                else
                {
                    callback.receiveErrorgetItem(error);
                }
            }

            public void onFault(final org.apache.axis2.context.MessageContext faultContext)
            {
                org.apache.axis2.AxisFault fault = org.apache.axis2.util.Utils
                                        .getInboundFaultFromMessageContext(faultContext);
                onError(fault);
            }

            public void onComplete()
            {
                try
                {
                    _messageContext.getTransportOut().getSender().cleanup(_messageContext);
                }
                catch (org.apache.axis2.AxisFault axisFault)
                {
                    callback.receiveErrorgetItem(axisFault);
                }
            }
        });

        org.apache.axis2.util.CallbackReceiver _callbackReceiver = null;
        if (_operations[1].getMessageReceiver() == null && _operationClient.getOptions()
                                    .isUseSeparateListener())
        {
            _callbackReceiver = new org.apache.axis2.util.CallbackReceiver();
            _operations[1].setMessageReceiver(
                                    _callbackReceiver);
        }

        // execute the operation client
        _operationClient.execute(false);

    }

    /**
     * Auto generated method signature
     * @see com.sts.copy.Copy#copyIntoItems
     * @param copyIntoItems4
     */

    public CopyStub.CopyIntoItemsResponse copyIntoItems(

    final CopyStub.CopyIntoItems copyIntoItems4)

    throws java.rmi.RemoteException

    {
        org.apache.axis2.context.MessageContext _messageContext = null;
        try
        {
            org.apache.axis2.client.OperationClient _operationClient = _serviceClient
                                    .createClient(_operations[2].getName());
            _operationClient.getOptions()
                                    .setAction("http://schemas.microsoft.com/sharepoint/soap/CopyIntoItems");
            _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

            addPropertyToOperationClient(_operationClient,
                                         org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                                         "&");

            // create a message context
            _messageContext = new org.apache.axis2.context.MessageContext();

            // create SOAP envelope with that payload
            org.apache.axiom.soap.SOAPEnvelope env = null;

            env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    copyIntoItems4,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                                  "copyIntoItems")));

            // adding SOAP soap_headers
            _serviceClient.addHeadersToEnvelope(env);
            // set the message context with that soap envelope
            _messageContext.setEnvelope(env);

            // add the message contxt to the operation client
            _operationClient.addMessageContext(_messageContext);

            // execute the operation client
            _operationClient.execute(true);

            org.apache.axis2.context.MessageContext _returnMessageContext = _operationClient
                                    .getMessageContext(
                                           org.apache.axis2.wsdl.WSDLConstants.MESSAGE_LABEL_IN_VALUE);
            org.apache.axiom.soap.SOAPEnvelope _returnEnv = _returnMessageContext.getEnvelope();

            java.lang.Object object = fromOM(
                                             _returnEnv.getBody().getFirstElement(),
                                             CopyStub.CopyIntoItemsResponse.class,
                                              getEnvelopeNamespaces(_returnEnv));

            return (CopyStub.CopyIntoItemsResponse)object;

        }
        catch (org.apache.axis2.AxisFault f)
        {

            org.apache.axiom.om.OMElement faultElt = f.getDetail();
            if (faultElt != null)
            {
                if (faultExceptionNameMap.containsKey(faultElt.getQName()))
                {
                    // make the fault by reflection
                    try
                    {
                        java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap
                                                .get(faultElt.getQName());
                        java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                        java.lang.Exception ex =
                                                 (java.lang.Exception)exceptionClass.newInstance();
                        // message class
                        java.lang.String messageClassName = (java.lang.String)faultMessageMap.get(faultElt
                                                .getQName());
                        java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                        java.lang.Object messageObject = fromOM(faultElt, messageClass, null);
                        java.lang.reflect.Method m = exceptionClass
                                                .getMethod("setFaultMessage",
                                                           new java.lang.Class[] {messageClass});
                        m.invoke(ex, new java.lang.Object[] {messageObject});

                        throw new java.rmi.RemoteException(ex.getMessage(), ex);
                    }
                    catch (java.lang.ClassCastException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.ClassNotFoundException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.NoSuchMethodException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.reflect.InvocationTargetException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.IllegalAccessException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                    catch (java.lang.InstantiationException e)
                    {
                        // we cannot intantiate the class - throw the original Axis fault
                        throw f;
                    }
                }
                else
                {
                    throw f;
                }
            }
            else
            {
                throw f;
            }
        }
        finally
        {
            if (_messageContext.getTransportOut() != null)
            {
                _messageContext.getTransportOut().getSender().cleanup(_messageContext);
            }
        }
    }

    /**
     * Auto generated method signature for Asynchronous Invocations
     * @see com.sts.copy.Copy#startcopyIntoItems
     * @param copyIntoItems4
     */
    public void startcopyIntoItems(

    final CopyStub.CopyIntoItems copyIntoItems4,

    final CopyCallbackHandler callback)

    throws java.rmi.RemoteException
    {

        org.apache.axis2.client.OperationClient _operationClient = _serviceClient.createClient(_operations[2]
                                .getName());
        _operationClient.getOptions().setAction("http://schemas.microsoft.com/sharepoint/soap/CopyIntoItems");
        _operationClient.getOptions().setExceptionToBeThrownOnSOAPFault(true);

        addPropertyToOperationClient(_operationClient,
                                     org.apache.axis2.description.WSDL2Constants.ATTR_WHTTP_QUERY_PARAMETER_SEPARATOR,
                                     "&");

        // create SOAP envelope with that payload
        org.apache.axiom.soap.SOAPEnvelope env = null;
        final org.apache.axis2.context.MessageContext _messageContext = new org.apache.axis2.context.MessageContext();

        // Style is Doc.

        env = toEnvelope(getFactory(_operationClient.getOptions().getSoapVersionURI()),
                                                    copyIntoItems4,
                                                    optimizeContent(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                                  "copyIntoItems")));

        // adding SOAP soap_headers
        _serviceClient.addHeadersToEnvelope(env);
        // create message context with that soap envelope
        _messageContext.setEnvelope(env);

        // add the message context to the operation client
        _operationClient.addMessageContext(_messageContext);

        _operationClient.setCallback(new org.apache.axis2.client.async.AxisCallback()
        {
            public void onMessage(final org.apache.axis2.context.MessageContext resultContext)
            {
                try
                {
                    org.apache.axiom.soap.SOAPEnvelope resultEnv = resultContext.getEnvelope();

                    java.lang.Object object = fromOM(resultEnv.getBody().getFirstElement(),
                                                                         CopyStub.CopyIntoItemsResponse.class,
                                                                         getEnvelopeNamespaces(resultEnv));
                    callback.receiveResultcopyIntoItems(
                                            (CopyStub.CopyIntoItemsResponse)object);

                }
                catch (org.apache.axis2.AxisFault e)
                {
                    callback.receiveErrorcopyIntoItems(e);
                }
            }

            public void onError(final java.lang.Exception error)
            {
                if (error instanceof org.apache.axis2.AxisFault)
                {
                    org.apache.axis2.AxisFault f = (org.apache.axis2.AxisFault)error;
                    org.apache.axiom.om.OMElement faultElt = f.getDetail();
                    if (faultElt != null)
                    {
                        if (faultExceptionNameMap.containsKey(faultElt.getQName()))
                        {
                            // make the fault by reflection
                            try
                            {
                                java.lang.String exceptionClassName = (java.lang.String)faultExceptionClassNameMap
                                                        .get(faultElt.getQName());
                                java.lang.Class exceptionClass = java.lang.Class.forName(exceptionClassName);
                                java.lang.Exception ex =
                                                         (java.lang.Exception)exceptionClass.newInstance();
                                // message class
                                java.lang.String messageClassName = (java.lang.String)faultMessageMap
                                                        .get(faultElt.getQName());
                                java.lang.Class messageClass = java.lang.Class.forName(messageClassName);
                                java.lang.Object messageObject = fromOM(faultElt, messageClass, null);
                                java.lang.reflect.Method m = exceptionClass
                                                        .getMethod("setFaultMessage",
                                                                   new java.lang.Class[] {messageClass});
                                m.invoke(ex, new java.lang.Object[] {messageObject});

                                callback.receiveErrorcopyIntoItems(new java.rmi.RemoteException(ex
                                                        .getMessage(), ex));
                            }
                            catch (java.lang.ClassCastException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItems(f);
                            }
                            catch (java.lang.ClassNotFoundException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItems(f);
                            }
                            catch (java.lang.NoSuchMethodException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItems(f);
                            }
                            catch (java.lang.reflect.InvocationTargetException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItems(f);
                            }
                            catch (java.lang.IllegalAccessException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItems(f);
                            }
                            catch (java.lang.InstantiationException e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItems(f);
                            }
                            catch (org.apache.axis2.AxisFault e)
                            {
                                // we cannot intantiate the class - throw the original Axis fault
                                callback.receiveErrorcopyIntoItems(f);
                            }
                        }
                        else
                        {
                            callback.receiveErrorcopyIntoItems(f);
                        }
                    }
                    else
                    {
                        callback.receiveErrorcopyIntoItems(f);
                    }
                }
                else
                {
                    callback.receiveErrorcopyIntoItems(error);
                }
            }

            public void onFault(final org.apache.axis2.context.MessageContext faultContext)
            {
                org.apache.axis2.AxisFault fault = org.apache.axis2.util.Utils
                                        .getInboundFaultFromMessageContext(faultContext);
                onError(fault);
            }

            public void onComplete()
            {
                try
                {
                    _messageContext.getTransportOut().getSender().cleanup(_messageContext);
                }
                catch (org.apache.axis2.AxisFault axisFault)
                {
                    callback.receiveErrorcopyIntoItems(axisFault);
                }
            }
        });

        org.apache.axis2.util.CallbackReceiver _callbackReceiver = null;
        if (_operations[2].getMessageReceiver() == null && _operationClient.getOptions()
                                    .isUseSeparateListener())
        {
            _callbackReceiver = new org.apache.axis2.util.CallbackReceiver();
            _operations[2].setMessageReceiver(
                                    _callbackReceiver);
        }

        // execute the operation client
        _operationClient.execute(false);

    }

    /**
     * A utility method that copies the namepaces from the SOAPEnvelope
     */
    private java.util.Map getEnvelopeNamespaces(final org.apache.axiom.soap.SOAPEnvelope env)
    {
        java.util.Map returnMap = new java.util.HashMap();
        java.util.Iterator namespaceIterator = env.getAllDeclaredNamespaces();
        while (namespaceIterator.hasNext())
        {
            org.apache.axiom.om.OMNamespace ns = (org.apache.axiom.om.OMNamespace)namespaceIterator.next();
            returnMap.put(ns.getPrefix(), ns.getNamespaceURI());
        }
        return returnMap;
    }

    private final javax.xml.namespace.QName[] opNameArray = null;

    private boolean optimizeContent(final javax.xml.namespace.QName opName)
    {

        if (opNameArray == null)
        {
            return false;
        }
        for (int i = 0; i < opNameArray.length; i++)
        {
            if (opName.equals(opNameArray[i]))
            {
                return true;
            }
        }
        return false;
    }

    // http://lngtwyappd022v/_vti_bin/copy.asmx
    public static class GetItemResponse
                            implements org.apache.axis2.databinding.ADBBean
    {

        public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                                                                                               "http://schemas.microsoft.com/sharepoint/soap/",
                                                                                               "GetItemResponse",
                                                                                               "ns1");

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for GetItemResult
         */

        protected org.apache.axis2.databinding.types.UnsignedInt localGetItemResult;

        /**
         * Auto generated getter method
         * @return org.apache.axis2.databinding.types.UnsignedInt
         */
        public org.apache.axis2.databinding.types.UnsignedInt getGetItemResult()
        {
            return localGetItemResult;
        }

        /**
         * Auto generated setter method
         * @param param GetItemResult
         */
        public void setGetItemResult(final org.apache.axis2.databinding.types.UnsignedInt param)
        {

            this.localGetItemResult = param;

        }

        /**
         * field for Fields
         */

        protected FieldInformationCollection localFields;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localFieldsTracker = false;

        /**
         * Auto generated getter method
         * @return FieldInformationCollection
         */
        public FieldInformationCollection getFields()
        {
            return localFields;
        }

        /**
         * Auto generated setter method
         * @param param Fields
         */
        public void setFields(final FieldInformationCollection param)
        {

            if (param != null)
            {
                // update the setting tracker
                localFieldsTracker = true;
            }
            else
            {
                localFieldsTracker = false;

            }

            this.localFields = param;

        }

        /**
         * field for Stream
         */

        protected javax.activation.DataHandler localStream;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localStreamTracker = false;

        /**
         * Auto generated getter method
         * @return javax.activation.DataHandler
         */
        public javax.activation.DataHandler getStream()
        {
            return localStream;
        }

        /**
         * Auto generated setter method
         * @param param Stream
         */
        public void setStream(final javax.activation.DataHandler param)
        {

            if (param != null)
            {
                // update the setting tracker
                localStreamTracker = true;
            }
            else
            {
                localStreamTracker = false;

            }

            this.localStream = param;

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         MY_QNAME)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  GetItemResponse.this.serialize(MY_QNAME,
                                                                                                 factory,
                                                                                                 xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          MY_QNAME, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            java.lang.String prefix = null;
            java.lang.String namespace = null;

            prefix = parentQName.getPrefix();
            namespace = parentQName.getNamespaceURI();

            if ((namespace != null) && (namespace.trim().length() > 0))
            {
                java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                if (writerPrefix != null)
                {
                    xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                }
                else
                {
                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);
                    }

                    xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }
            }
            else
            {
                xmlWriter.writeStartElement(parentQName.getLocalPart());
            }

            if (serializeType)
            {

                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   namespacePrefix + ":GetItemResponse",
                                   xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   "GetItemResponse",
                                   xmlWriter);
                }

            }

            namespace = "http://schemas.microsoft.com/sharepoint/soap/";
            if (!namespace.equals(""))
            {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null)
                {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "GetItemResult", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);

                }
                else
                {
                    xmlWriter.writeStartElement(namespace, "GetItemResult");
                }

            }
            else
            {
                xmlWriter.writeStartElement("GetItemResult");
            }

            if (localGetItemResult == null)
            {
                // write the nil attribute

                throw new org.apache.axis2.databinding.ADBException("GetItemResult cannot be null!!");

            }
            else
            {

                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(localGetItemResult));

            }

            xmlWriter.writeEndElement();
            if (localFieldsTracker)
            {
                if (localFields == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("Fields cannot be null!!");
                }
                localFields
                                        .serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "Fields"),
                                                   factory,
                                                   xmlWriter);
            }
            if (localStreamTracker)
            {
                namespace = "http://schemas.microsoft.com/sharepoint/soap/";
                if (!namespace.equals(""))
                {
                    prefix = xmlWriter.getPrefix(namespace);

                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);

                        xmlWriter.writeStartElement(prefix, "Stream", namespace);
                        xmlWriter.writeNamespace(prefix, namespace);
                        xmlWriter.setPrefix(prefix, namespace);

                    }
                    else
                    {
                        xmlWriter.writeStartElement(namespace, "Stream");
                    }

                }
                else
                {
                    xmlWriter.writeStartElement("Stream");
                }

                if (localStream != null)
                {
                    xmlWriter.writeDataHandler(localStream);
                }

                xmlWriter.writeEndElement();
            }
            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            java.util.ArrayList elementList = new java.util.ArrayList();
            java.util.ArrayList attribList = new java.util.ArrayList();

            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                      "GetItemResult"));

            if (localGetItemResult != null)
            {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(localGetItemResult));
            }
            else
            {
                throw new org.apache.axis2.databinding.ADBException("GetItemResult cannot be null!!");
            }
            if (localFieldsTracker)
            {
                elementList
                                        .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                           "Fields"));

                if (localFields == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("Fields cannot be null!!");
                }
                elementList.add(localFields);
            }
            if (localStreamTracker)
            {
                elementList
                                        .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                           "Stream"));

                elementList.add(localStream);
            }

            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
                                                                                        elementList.toArray(),
                                                                                        attribList.toArray());

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static GetItemResponse parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                GetItemResponse object =
                                         new GetItemResponse();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null)
                    {
                        java.lang.String fullTypeName = reader
                                                .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                   "type");
                        if (fullTypeName != null)
                        {
                            java.lang.String nsPrefix = null;
                            if (fullTypeName.indexOf(":") > -1)
                            {
                                nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                            }
                            nsPrefix = nsPrefix == null ? "" : nsPrefix;

                            java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);

                            if (!"GetItemResponse".equals(type))
                            {
                                // find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext()
                                                        .getNamespaceURI(nsPrefix);
                                return (GetItemResponse)ExtensionMapper.getTypeObject(
                                                                                      nsUri, type, reader);
                            }

                        }

                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    reader.next();

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "GetItemResult")
                                                .equals(reader.getName()))
                    {

                        java.lang.String content = reader.getElementText();

                        object.setGetItemResult(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToUnsignedInt(content));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {
                        // A start element we are not expecting indicates an invalid parameter was passed
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "Fields").equals(reader
                                                .getName()))
                    {

                        object.setFields(FieldInformationCollection.Factory.parse(reader));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "Stream").equals(reader
                                                .getName()))
                    {
                        reader.next();
                        if (isReaderMTOMAware(reader)
                                            &&
                                            java.lang.Boolean.TRUE
                                                                    .equals(reader
                                                                                            .getProperty(org.apache.axiom.om.OMConstants.IS_BINARY)))
                        {
                            // MTOM aware reader - get the datahandler directly and put it in the object
                            object
                                                    .setStream(
                                                    (javax.activation.DataHandler)reader
                                                                            .getProperty(org.apache.axiom.om.OMConstants.DATA_HANDLER));
                        }
                        else
                        {
                            if (reader.getEventType() == javax.xml.stream.XMLStreamConstants.START_ELEMENT && reader
                                                        .getName()
                                                        .equals(new javax.xml.namespace.QName(org.apache.axiom.om.impl.MTOMConstants.XOP_NAMESPACE_URI,
                                                                                              org.apache.axiom.om.impl.MTOMConstants.XOP_INCLUDE)))
                            {
                                java.lang.String id = org.apache.axiom.om.util.ElementHelper
                                                        .getContentID(reader, "UTF-8");
                                object
                                                        .setStream(((org.apache.axiom.soap.impl.builder.MTOMStAXSOAPModelBuilder)((org.apache.axiom.om.impl.llom.OMStAXWrapper)reader)
                                                                                .getBuilder())
                                                                                .getDataHandler(id));
                                reader.next();

                                reader.next();

                            }
                            else if (reader.hasText())
                            {
                                // Do the usual conversion
                                java.lang.String content = reader.getText();
                                object
                                                        .setStream(
                                                        org.apache.axis2.databinding.utils.ConverterUtil
                                                                                .convertToBase64Binary(content));

                                reader.next();

                            }
                        }

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement())
                    {
                        // A start element we are not expecting indicates a trailing invalid property
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class CopyIntoItems
                            implements org.apache.axis2.databinding.ADBBean
    {

        public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                                                                                               "http://schemas.microsoft.com/sharepoint/soap/",
                                                                                               "CopyIntoItems",
                                                                                               "ns1");

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for SourceUrl
         */

        protected java.lang.String localSourceUrl;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localSourceUrlTracker = false;

        /**
         * Auto generated getter method
         * @return java.lang.String
         */
        public java.lang.String getSourceUrl()
        {
            return localSourceUrl;
        }

        /**
         * Auto generated setter method
         * @param param SourceUrl
         */
        public void setSourceUrl(final java.lang.String param)
        {

            if (param != null)
            {
                // update the setting tracker
                localSourceUrlTracker = true;
            }
            else
            {
                localSourceUrlTracker = false;

            }

            this.localSourceUrl = param;

        }

        /**
         * field for DestinationUrls
         */

        protected DestinationUrlCollection localDestinationUrls;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localDestinationUrlsTracker = false;

        /**
         * Auto generated getter method
         * @return DestinationUrlCollection
         */
        public DestinationUrlCollection getDestinationUrls()
        {
            return localDestinationUrls;
        }

        /**
         * Auto generated setter method
         * @param param DestinationUrls
         */
        public void setDestinationUrls(final DestinationUrlCollection param)
        {

            if (param != null)
            {
                // update the setting tracker
                localDestinationUrlsTracker = true;
            }
            else
            {
                localDestinationUrlsTracker = false;

            }

            this.localDestinationUrls = param;

        }

        /**
         * field for Fields
         */

        protected FieldInformationCollection localFields;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localFieldsTracker = false;

        /**
         * Auto generated getter method
         * @return FieldInformationCollection
         */
        public FieldInformationCollection getFields()
        {
            return localFields;
        }

        /**
         * Auto generated setter method
         * @param param Fields
         */
        public void setFields(final FieldInformationCollection param)
        {

            if (param != null)
            {
                // update the setting tracker
                localFieldsTracker = true;
            }
            else
            {
                localFieldsTracker = false;

            }

            this.localFields = param;

        }

        /**
         * field for Stream
         */

        protected javax.activation.DataHandler localStream;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localStreamTracker = false;

        /**
         * Auto generated getter method
         * @return javax.activation.DataHandler
         */
        public javax.activation.DataHandler getStream()
        {
            return localStream;
        }

        /**
         * Auto generated setter method
         * @param param Stream
         */
        public void setStream(final javax.activation.DataHandler param)
        {

            if (param != null)
            {
                // update the setting tracker
                localStreamTracker = true;
            }
            else
            {
                localStreamTracker = false;

            }

            this.localStream = param;

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         MY_QNAME)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  CopyIntoItems.this.serialize(MY_QNAME,
                                                                                               factory,
                                                                                               xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          MY_QNAME, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            java.lang.String prefix = null;
            java.lang.String namespace = null;

            prefix = parentQName.getPrefix();
            namespace = parentQName.getNamespaceURI();

            if ((namespace != null) && (namespace.trim().length() > 0))
            {
                java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                if (writerPrefix != null)
                {
                    xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                }
                else
                {
                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);
                    }

                    xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }
            }
            else
            {
                xmlWriter.writeStartElement(parentQName.getLocalPart());
            }

            if (serializeType)
            {

                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   namespacePrefix + ":CopyIntoItems",
                                   xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   "CopyIntoItems",
                                   xmlWriter);
                }

            }
            if (localSourceUrlTracker)
            {
                namespace = "http://schemas.microsoft.com/sharepoint/soap/";
                if (!namespace.equals(""))
                {
                    prefix = xmlWriter.getPrefix(namespace);

                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);

                        xmlWriter.writeStartElement(prefix, "SourceUrl", namespace);
                        xmlWriter.writeNamespace(prefix, namespace);
                        xmlWriter.setPrefix(prefix, namespace);

                    }
                    else
                    {
                        xmlWriter.writeStartElement(namespace, "SourceUrl");
                    }

                }
                else
                {
                    xmlWriter.writeStartElement("SourceUrl");
                }

                if (localSourceUrl == null)
                {
                    // write the nil attribute

                    throw new org.apache.axis2.databinding.ADBException("SourceUrl cannot be null!!");

                }
                else
                {

                    xmlWriter.writeCharacters(localSourceUrl);

                }

                xmlWriter.writeEndElement();
            }
            if (localDestinationUrlsTracker)
            {
                if (localDestinationUrls == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("DestinationUrls cannot be null!!");
                }
                localDestinationUrls
                                        .serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "DestinationUrls"),
                                                   factory,
                                                   xmlWriter);
            }
            if (localFieldsTracker)
            {
                if (localFields == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("Fields cannot be null!!");
                }
                localFields
                                        .serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "Fields"),
                                                   factory,
                                                   xmlWriter);
            }
            if (localStreamTracker)
            {
                namespace = "http://schemas.microsoft.com/sharepoint/soap/";
                if (!namespace.equals(""))
                {
                    prefix = xmlWriter.getPrefix(namespace);

                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);

                        xmlWriter.writeStartElement(prefix, "Stream", namespace);
                        xmlWriter.writeNamespace(prefix, namespace);
                        xmlWriter.setPrefix(prefix, namespace);

                    }
                    else
                    {
                        xmlWriter.writeStartElement(namespace, "Stream");
                    }

                }
                else
                {
                    xmlWriter.writeStartElement("Stream");
                }

                if (localStream != null)
                {
                    xmlWriter.writeDataHandler(localStream);
                }

                xmlWriter.writeEndElement();
            }
            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            java.util.ArrayList elementList = new java.util.ArrayList();
            java.util.ArrayList attribList = new java.util.ArrayList();

            if (localSourceUrlTracker)
            {
                elementList
                                        .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                           "SourceUrl"));

                if (localSourceUrl != null)
                {
                    elementList.add(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(localSourceUrl));
                }
                else
                {
                    throw new org.apache.axis2.databinding.ADBException("SourceUrl cannot be null!!");
                }
            }
            if (localDestinationUrlsTracker)
            {
                elementList
                                        .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                           "DestinationUrls"));

                if (localDestinationUrls == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("DestinationUrls cannot be null!!");
                }
                elementList.add(localDestinationUrls);
            }
            if (localFieldsTracker)
            {
                elementList
                                        .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                           "Fields"));

                if (localFields == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("Fields cannot be null!!");
                }
                elementList.add(localFields);
            }
            if (localStreamTracker)
            {
                elementList
                                        .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                           "Stream"));

                elementList.add(localStream);
            }

            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
                                                                                        elementList.toArray(),
                                                                                        attribList.toArray());

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static CopyIntoItems parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                CopyIntoItems object =
                                       new CopyIntoItems();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null)
                    {
                        java.lang.String fullTypeName = reader
                                                .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                   "type");
                        if (fullTypeName != null)
                        {
                            java.lang.String nsPrefix = null;
                            if (fullTypeName.indexOf(":") > -1)
                            {
                                nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                            }
                            nsPrefix = nsPrefix == null ? "" : nsPrefix;

                            java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);

                            if (!"CopyIntoItems".equals(type))
                            {
                                // find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext()
                                                        .getNamespaceURI(nsPrefix);
                                return (CopyIntoItems)ExtensionMapper.getTypeObject(
                                                                                    nsUri, type, reader);
                            }

                        }

                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    reader.next();

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "SourceUrl").equals(reader
                                                .getName()))
                    {

                        java.lang.String content = reader.getElementText();

                        object.setSourceUrl(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(content));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "DestinationUrls")
                                                .equals(reader.getName()))
                    {

                        object.setDestinationUrls(DestinationUrlCollection.Factory.parse(reader));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "Fields").equals(reader
                                                .getName()))
                    {

                        object.setFields(FieldInformationCollection.Factory.parse(reader));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "Stream").equals(reader
                                                .getName()))
                    {
                        reader.next();
                        if (isReaderMTOMAware(reader)
                                            &&
                                            java.lang.Boolean.TRUE
                                                                    .equals(reader
                                                                                            .getProperty(org.apache.axiom.om.OMConstants.IS_BINARY)))
                        {
                            // MTOM aware reader - get the datahandler directly and put it in the object
                            object
                                                    .setStream(
                                                    (javax.activation.DataHandler)reader
                                                                            .getProperty(org.apache.axiom.om.OMConstants.DATA_HANDLER));
                        }
                        else
                        {
                            if (reader.getEventType() == javax.xml.stream.XMLStreamConstants.START_ELEMENT && reader
                                                        .getName()
                                                        .equals(new javax.xml.namespace.QName(org.apache.axiom.om.impl.MTOMConstants.XOP_NAMESPACE_URI,
                                                                                              org.apache.axiom.om.impl.MTOMConstants.XOP_INCLUDE)))
                            {
                                java.lang.String id = org.apache.axiom.om.util.ElementHelper
                                                        .getContentID(reader, "UTF-8");
                                object
                                                        .setStream(((org.apache.axiom.soap.impl.builder.MTOMStAXSOAPModelBuilder)((org.apache.axiom.om.impl.llom.OMStAXWrapper)reader)
                                                                                .getBuilder())
                                                                                .getDataHandler(id));
                                reader.next();

                                reader.next();

                            }
                            else if (reader.hasText())
                            {
                                // Do the usual conversion
                                java.lang.String content = reader.getText();
                                object
                                                        .setStream(
                                                        org.apache.axis2.databinding.utils.ConverterUtil
                                                                                .convertToBase64Binary(content));

                                reader.next();

                            }
                        }

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement())
                    {
                        // A start element we are not expecting indicates a trailing invalid property
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class CopyResult
                            implements org.apache.axis2.databinding.ADBBean
    {
        /*
         * This type was generated from the piece of schema that had name = CopyResult Namespace URI =
         * http://schemas.microsoft.com/sharepoint/soap/ Namespace Prefix = ns1
         */

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for ErrorCode This was an Attribute!
         */

        protected CopyErrorCode localErrorCode;

        /**
         * Auto generated getter method
         * @return CopyErrorCode
         */
        public CopyErrorCode getErrorCode()
        {
            return localErrorCode;
        }

        /**
         * Auto generated setter method
         * @param param ErrorCode
         */
        public void setErrorCode(final CopyErrorCode param)
        {

            this.localErrorCode = param;

        }

        /**
         * field for ErrorMessage This was an Attribute!
         */

        protected java.lang.String localErrorMessage;

        /**
         * Auto generated getter method
         * @return java.lang.String
         */
        public java.lang.String getErrorMessage()
        {
            return localErrorMessage;
        }

        /**
         * Auto generated setter method
         * @param param ErrorMessage
         */
        public void setErrorMessage(final java.lang.String param)
        {

            this.localErrorMessage = param;

        }

        /**
         * field for DestinationUrl This was an Attribute!
         */

        protected java.lang.String localDestinationUrl;

        /**
         * Auto generated getter method
         * @return java.lang.String
         */
        public java.lang.String getDestinationUrl()
        {
            return localDestinationUrl;
        }

        /**
         * Auto generated setter method
         * @param param DestinationUrl
         */
        public void setDestinationUrl(final java.lang.String param)
        {

            this.localDestinationUrl = param;

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         parentQName)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  CopyResult.this.serialize(parentQName,
                                                                                            factory,
                                                                                            xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          parentQName, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            java.lang.String prefix = null;
            java.lang.String namespace = null;

            prefix = parentQName.getPrefix();
            namespace = parentQName.getNamespaceURI();

            if ((namespace != null) && (namespace.trim().length() > 0))
            {
                java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                if (writerPrefix != null)
                {
                    xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                }
                else
                {
                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);
                    }

                    xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }
            }
            else
            {
                xmlWriter.writeStartElement(parentQName.getLocalPart());
            }

            if (serializeType)
            {

                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   namespacePrefix + ":CopyResult",
                                   xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   "CopyResult",
                                   xmlWriter);
                }

            }

            if (localErrorCode != null)
            {
                writeAttribute("",
                                           "ErrorCode",
                                           localErrorCode.toString(), xmlWriter);
            }

            else
            {
                throw new org.apache.axis2.databinding.ADBException("required attribute localErrorCode is null");
            }

            if (localErrorMessage != null)
            {

                writeAttribute("",
                                                         "ErrorMessage",
                                                         org.apache.axis2.databinding.utils.ConverterUtil
                                                                                 .convertToString(localErrorMessage),
                               xmlWriter);

            }

            if (localDestinationUrl != null)
            {

                writeAttribute("",
                                                         "DestinationUrl",
                                                         org.apache.axis2.databinding.utils.ConverterUtil
                                                                                 .convertToString(localDestinationUrl),
                               xmlWriter);

            }

            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            java.util.ArrayList elementList = new java.util.ArrayList();
            java.util.ArrayList attribList = new java.util.ArrayList();

            attribList.add(
                                    new javax.xml.namespace.QName("", "ErrorCode"));

            attribList.add(localErrorCode.toString());

            attribList.add(
                                    new javax.xml.namespace.QName("", "ErrorMessage"));

            attribList.add(org.apache.axis2.databinding.utils.ConverterUtil
                                    .convertToString(localErrorMessage));

            attribList.add(
                                    new javax.xml.namespace.QName("", "DestinationUrl"));

            attribList.add(org.apache.axis2.databinding.utils.ConverterUtil
                                    .convertToString(localDestinationUrl));

            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
                                                                                        elementList.toArray(),
                                                                                        attribList.toArray());

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static CopyResult parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                CopyResult object =
                                    new CopyResult();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null)
                    {
                        java.lang.String fullTypeName = reader
                                                .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                   "type");
                        if (fullTypeName != null)
                        {
                            java.lang.String nsPrefix = null;
                            if (fullTypeName.indexOf(":") > -1)
                            {
                                nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                            }
                            nsPrefix = nsPrefix == null ? "" : nsPrefix;

                            java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);

                            if (!"CopyResult".equals(type))
                            {
                                // find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext()
                                                        .getNamespaceURI(nsPrefix);
                                return (CopyResult)ExtensionMapper.getTypeObject(
                                                                                 nsUri, type, reader);
                            }

                        }

                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    // handle attribute "ErrorCode"
                    java.lang.String tempAttribErrorCode =

                    reader.getAttributeValue(null, "ErrorCode");

                    if (tempAttribErrorCode != null)
                    {
                        java.lang.String content = tempAttribErrorCode;

                        object
                                                .setErrorCode(
                                                        CopyErrorCode.Factory.fromString(reader,
                                                                                         tempAttribErrorCode));

                    }
                    else
                    {

                        throw new org.apache.axis2.databinding.ADBException("Required attribute ErrorCode is missing");

                    }
                    handledAttributes.add("ErrorCode");

                    // handle attribute "ErrorMessage"
                    java.lang.String tempAttribErrorMessage =

                    reader.getAttributeValue(null, "ErrorMessage");

                    if (tempAttribErrorMessage != null)
                    {
                        java.lang.String content = tempAttribErrorMessage;

                        object
                                                .setErrorMessage(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(tempAttribErrorMessage));

                    }
                    else
                    {

                    }
                    handledAttributes.add("ErrorMessage");

                    // handle attribute "DestinationUrl"
                    java.lang.String tempAttribDestinationUrl =

                    reader.getAttributeValue(null, "DestinationUrl");

                    if (tempAttribDestinationUrl != null)
                    {
                        java.lang.String content = tempAttribDestinationUrl;

                        object
                                                .setDestinationUrl(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(tempAttribDestinationUrl));

                    }
                    else
                    {

                    }
                    handledAttributes.add("DestinationUrl");

                    reader.next();

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class Guid
                            implements org.apache.axis2.databinding.ADBBean
    {

        public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                                                                                               "http://microsoft.com/wsdl/types/",
                                                                                               "guid",
                                                                                               "ns2");

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://microsoft.com/wsdl/types/"))
            {
                return "ns2";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for Guid
         */

        protected java.lang.String localGuid;

        /**
         * Auto generated getter method
         * @return java.lang.String
         */
        public java.lang.String getGuid()
        {
            return localGuid;
        }

        /**
         * Auto generated setter method
         * @param param Guid
         */
        public void setGuid(final java.lang.String param)
        {

            if (org.apache.axis2.databinding.utils.ConverterUtil
                                    .convertToString(param)
                                    .matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"))
            {
                this.localGuid = param;
            }
            else
            {
                throw new java.lang.RuntimeException();
            }

        }

        public java.lang.String toString()
        {

            return localGuid.toString();

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         MY_QNAME)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  Guid.this.serialize(MY_QNAME,
                                                                                      factory,
                                                                                      xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          MY_QNAME, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            // We can safely assume an element has only one type associated with it

            java.lang.String namespace = parentQName.getNamespaceURI();
            java.lang.String localName = parentQName.getLocalPart();

            if (!namespace.equals(""))
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null)
                {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, localName, namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);

                }
                else
                {
                    xmlWriter.writeStartElement(namespace, localName);
                }

            }
            else
            {
                xmlWriter.writeStartElement(localName);
            }

            // add the type details if this is used in a simple type
            if (serializeType)
            {
                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://microsoft.com/wsdl/types/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                           namespacePrefix + ":guid",
                                           xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                           "guid",
                                           xmlWriter);
                }
            }

            if (localGuid == null)
            {

                throw new org.apache.axis2.databinding.ADBException("Value cannot be null !!");

            }
            else
            {

                xmlWriter.writeCharacters(localGuid);

            }

            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            // We can safely assume an element has only one type associated with it
            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(MY_QNAME,
                                                                                        new java.lang.Object[] {
                                                                                                                org.apache.axis2.databinding.utils.reader.ADBXMLStreamReader.ELEMENT_TEXT,
                                                                                                                org.apache.axis2.databinding.utils.ConverterUtil
                                                                                                                                        .convertToString(localGuid)
                            },
                                                                                        null);

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            public static Guid fromString(final java.lang.String value,
                                                    final java.lang.String namespaceURI)
            {
                Guid returnValue = new Guid();

                returnValue.setGuid(
                                        org.apache.axis2.databinding.utils.ConverterUtil
                                                                .convertToString(value));

                return returnValue;
            }

            public static Guid fromString(final javax.xml.stream.XMLStreamReader xmlStreamReader,
                                                                    final java.lang.String content)
            {
                if (content.indexOf(":") > -1)
                {
                    java.lang.String prefix = content.substring(0, content.indexOf(":"));
                    java.lang.String namespaceUri = xmlStreamReader.getNamespaceContext()
                                            .getNamespaceURI(prefix);
                    return Guid.Factory.fromString(content, namespaceUri);
                }
                else
                {
                    return Guid.Factory.fromString(content, "");
                }
            }

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static Guid parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                Guid object =
                              new Guid();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    while (!reader.isEndElement())
                    {
                        if (reader.isStartElement() || reader.hasText())
                        {

                            if (reader.isStartElement() || reader.hasText())
                            {

                                java.lang.String content = reader.getElementText();

                                object.setGuid(
                                                        org.apache.axis2.databinding.utils.ConverterUtil
                                                                                .convertToString(content));

                            } // End of if for expected property start element

                            else
                            {
                                // A start element we are not expecting indicates an invalid parameter was
                                // passed
                                throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                            .getLocalName());
                            }

                        }
                        else
                        {
                            reader.next();
                        }
                    } // end of while loop

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class CopyErrorCode
                            implements org.apache.axis2.databinding.ADBBean
    {

        public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                                                                                               "http://schemas.microsoft.com/sharepoint/soap/",
                                                                                               "CopyErrorCode",
                                                                                               "ns1");

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for CopyErrorCode
         */

        protected java.lang.String localCopyErrorCode;

        private static java.util.HashMap _table_ = new java.util.HashMap();

        // Constructor

        protected CopyErrorCode(final java.lang.String value, final boolean isRegisterValue)
        {
            localCopyErrorCode = value;
            if (isRegisterValue)
            {

                _table_.put(localCopyErrorCode, this);

            }

        }

        public static final java.lang.String _Success =
                                                        org.apache.axis2.databinding.utils.ConverterUtil
                                                                                .convertToString("Success");

        public static final java.lang.String _DestinationInvalid =
                                                                   org.apache.axis2.databinding.utils.ConverterUtil
                                                                                           .convertToString("DestinationInvalid");

        public static final java.lang.String _DestinationMWS =
                                                               org.apache.axis2.databinding.utils.ConverterUtil
                                                                                       .convertToString("DestinationMWS");

        public static final java.lang.String _SourceInvalid =
                                                              org.apache.axis2.databinding.utils.ConverterUtil
                                                                                      .convertToString("SourceInvalid");

        public static final java.lang.String _DestinationCheckedOut =
                                                                      org.apache.axis2.databinding.utils.ConverterUtil
                                                                                              .convertToString("DestinationCheckedOut");

        public static final java.lang.String _InvalidUrl =
                                                           org.apache.axis2.databinding.utils.ConverterUtil
                                                                                   .convertToString("InvalidUrl");

        public static final java.lang.String _Unknown =
                                                        org.apache.axis2.databinding.utils.ConverterUtil
                                                                                .convertToString("Unknown");

        public static final CopyErrorCode Success =
                                                    new CopyErrorCode(_Success, true);

        public static final CopyErrorCode DestinationInvalid =
                                                               new CopyErrorCode(_DestinationInvalid, true);

        public static final CopyErrorCode DestinationMWS =
                                                           new CopyErrorCode(_DestinationMWS, true);

        public static final CopyErrorCode SourceInvalid =
                                                          new CopyErrorCode(_SourceInvalid, true);

        public static final CopyErrorCode DestinationCheckedOut =
                                                                  new CopyErrorCode(_DestinationCheckedOut,
                                                                                    true);

        public static final CopyErrorCode InvalidUrl =
                                                       new CopyErrorCode(_InvalidUrl, true);

        public static final CopyErrorCode Unknown =
                                                    new CopyErrorCode(_Unknown, true);

        public java.lang.String getValue()
        {
            return localCopyErrorCode;
        }

        public boolean equals(final java.lang.Object obj)
        {
            return (obj == this);
        }

        public int hashCode()
        {
            return toString().hashCode();
        }

        public java.lang.String toString()
        {

            return localCopyErrorCode.toString();

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         MY_QNAME)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  CopyErrorCode.this.serialize(MY_QNAME,
                                                                                               factory,
                                                                                               xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          MY_QNAME, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            // We can safely assume an element has only one type associated with it

            java.lang.String namespace = parentQName.getNamespaceURI();
            java.lang.String localName = parentQName.getLocalPart();

            if (!namespace.equals(""))
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null)
                {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, localName, namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);

                }
                else
                {
                    xmlWriter.writeStartElement(namespace, localName);
                }

            }
            else
            {
                xmlWriter.writeStartElement(localName);
            }

            // add the type details if this is used in a simple type
            if (serializeType)
            {
                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                           namespacePrefix + ":CopyErrorCode",
                                           xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                           "CopyErrorCode",
                                           xmlWriter);
                }
            }

            if (localCopyErrorCode == null)
            {

                throw new org.apache.axis2.databinding.ADBException("Value cannot be null !!");

            }
            else
            {

                xmlWriter.writeCharacters(localCopyErrorCode);

            }

            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            // We can safely assume an element has only one type associated with it
            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(MY_QNAME,
                                                                                        new java.lang.Object[] {
                                                                                                                org.apache.axis2.databinding.utils.reader.ADBXMLStreamReader.ELEMENT_TEXT,
                                                                                                                org.apache.axis2.databinding.utils.ConverterUtil
                                                                                                                                        .convertToString(localCopyErrorCode)
                            },
                                                                                        null);

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            public static CopyErrorCode fromValue(final java.lang.String value)
                                                                               throws java.lang.IllegalArgumentException
            {
                CopyErrorCode enumeration = (CopyErrorCode)

                _table_.get(value);

                if (enumeration == null)
                {
                    throw new java.lang.IllegalArgumentException();
                }
                return enumeration;
            }

            public static CopyErrorCode fromString(final java.lang.String value,
                                                   final java.lang.String namespaceURI)
                                                                                       throws java.lang.IllegalArgumentException
            {
                try
                {

                    return fromValue(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(value));

                }
                catch (java.lang.Exception e)
                {
                    throw new java.lang.IllegalArgumentException();
                }
            }

            public static CopyErrorCode fromString(final javax.xml.stream.XMLStreamReader xmlStreamReader,
                                                                    final java.lang.String content)
            {
                if (content.indexOf(":") > -1)
                {
                    java.lang.String prefix = content.substring(0, content.indexOf(":"));
                    java.lang.String namespaceUri = xmlStreamReader.getNamespaceContext()
                                            .getNamespaceURI(prefix);
                    return CopyErrorCode.Factory.fromString(content, namespaceUri);
                }
                else
                {
                    return CopyErrorCode.Factory.fromString(content, "");
                }
            }

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static CopyErrorCode parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                CopyErrorCode object = null;
                // initialize a hash map to keep values
                java.util.Map attributeMap = new java.util.HashMap();
                java.util.List extraAttributeList = new java.util.ArrayList();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    while (!reader.isEndElement())
                    {
                        if (reader.isStartElement() || reader.hasText())
                        {

                            java.lang.String content = reader.getElementText();

                            if (content.indexOf(":") > 0)
                            {
                                // this seems to be a Qname so find the namespace and send
                                prefix = content.substring(0, content.indexOf(":"));
                                namespaceuri = reader.getNamespaceURI(prefix);
                                object = CopyErrorCode.Factory.fromString(content, namespaceuri);
                            }
                            else
                            {
                                // this seems to be not a qname send and empty namespace incase of it is
                                // check is done in fromString method
                                object = CopyErrorCode.Factory.fromString(content, "");
                            }

                        }
                        else
                        {
                            reader.next();
                        }
                    } // end of while loop

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class CopyIntoItemsResponse
                            implements org.apache.axis2.databinding.ADBBean
    {

        public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                                                                                               "http://schemas.microsoft.com/sharepoint/soap/",
                                                                                               "CopyIntoItemsResponse",
                                                                                               "ns1");

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for CopyIntoItemsResult
         */

        protected org.apache.axis2.databinding.types.UnsignedInt localCopyIntoItemsResult;

        /**
         * Auto generated getter method
         * @return org.apache.axis2.databinding.types.UnsignedInt
         */
        public org.apache.axis2.databinding.types.UnsignedInt getCopyIntoItemsResult()
        {
            return localCopyIntoItemsResult;
        }

        /**
         * Auto generated setter method
         * @param param CopyIntoItemsResult
         */
        public void setCopyIntoItemsResult(final org.apache.axis2.databinding.types.UnsignedInt param)
        {

            this.localCopyIntoItemsResult = param;

        }

        /**
         * field for Results
         */

        protected CopyResultCollection localResults;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localResultsTracker = false;

        /**
         * Auto generated getter method
         * @return CopyResultCollection
         */
        public CopyResultCollection getResults()
        {
            return localResults;
        }

        /**
         * Auto generated setter method
         * @param param Results
         */
        public void setResults(final CopyResultCollection param)
        {

            if (param != null)
            {
                // update the setting tracker
                localResultsTracker = true;
            }
            else
            {
                localResultsTracker = false;

            }

            this.localResults = param;

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         MY_QNAME)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  CopyIntoItemsResponse.this
                                                                                          .serialize(MY_QNAME,
                                                                                                     factory,
                                                                                                     xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          MY_QNAME, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            java.lang.String prefix = null;
            java.lang.String namespace = null;

            prefix = parentQName.getPrefix();
            namespace = parentQName.getNamespaceURI();

            if ((namespace != null) && (namespace.trim().length() > 0))
            {
                java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                if (writerPrefix != null)
                {
                    xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                }
                else
                {
                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);
                    }

                    xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }
            }
            else
            {
                xmlWriter.writeStartElement(parentQName.getLocalPart());
            }

            if (serializeType)
            {

                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   namespacePrefix + ":CopyIntoItemsResponse",
                                   xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   "CopyIntoItemsResponse",
                                   xmlWriter);
                }

            }

            namespace = "http://schemas.microsoft.com/sharepoint/soap/";
            if (!namespace.equals(""))
            {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null)
                {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "CopyIntoItemsResult", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);

                }
                else
                {
                    xmlWriter.writeStartElement(namespace, "CopyIntoItemsResult");
                }

            }
            else
            {
                xmlWriter.writeStartElement("CopyIntoItemsResult");
            }

            if (localCopyIntoItemsResult == null)
            {
                // write the nil attribute

                throw new org.apache.axis2.databinding.ADBException("CopyIntoItemsResult cannot be null!!");

            }
            else
            {

                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(localCopyIntoItemsResult));

            }

            xmlWriter.writeEndElement();
            if (localResultsTracker)
            {
                if (localResults == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("Results cannot be null!!");
                }
                localResults
                                        .serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "Results"),
                                                   factory,
                                                   xmlWriter);
            }
            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            java.util.ArrayList elementList = new java.util.ArrayList();
            java.util.ArrayList attribList = new java.util.ArrayList();

            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                      "CopyIntoItemsResult"));

            if (localCopyIntoItemsResult != null)
            {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(localCopyIntoItemsResult));
            }
            else
            {
                throw new org.apache.axis2.databinding.ADBException("CopyIntoItemsResult cannot be null!!");
            }
            if (localResultsTracker)
            {
                elementList
                                        .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                           "Results"));

                if (localResults == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("Results cannot be null!!");
                }
                elementList.add(localResults);
            }

            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
                                                                                        elementList.toArray(),
                                                                                        attribList.toArray());

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static CopyIntoItemsResponse parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                CopyIntoItemsResponse object =
                                               new CopyIntoItemsResponse();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null)
                    {
                        java.lang.String fullTypeName = reader
                                                .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                   "type");
                        if (fullTypeName != null)
                        {
                            java.lang.String nsPrefix = null;
                            if (fullTypeName.indexOf(":") > -1)
                            {
                                nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                            }
                            nsPrefix = nsPrefix == null ? "" : nsPrefix;

                            java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);

                            if (!"CopyIntoItemsResponse".equals(type))
                            {
                                // find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext()
                                                        .getNamespaceURI(nsPrefix);
                                return (CopyIntoItemsResponse)ExtensionMapper.getTypeObject(
                                                                                            nsUri,
                                                                                            type,
                                                                                            reader);
                            }

                        }

                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    reader.next();

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "CopyIntoItemsResult")
                                                .equals(reader.getName()))
                    {

                        java.lang.String content = reader.getElementText();

                        object.setCopyIntoItemsResult(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToUnsignedInt(content));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {
                        // A start element we are not expecting indicates an invalid parameter was passed
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "Results").equals(reader
                                                .getName()))
                    {

                        object.setResults(CopyResultCollection.Factory.parse(reader));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement())
                    {
                        // A start element we are not expecting indicates a trailing invalid property
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class ExtensionMapper
    {

        public static java.lang.Object getTypeObject(final java.lang.String namespaceURI,
                                                       final java.lang.String typeName,
                                                       final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
        {

            if ("http://schemas.microsoft.com/sharepoint/soap/".equals(namespaceURI) &&
                  "CopyResult".equals(typeName))
            {

                return CopyResult.Factory.parse(reader);

            }

            if ("http://schemas.microsoft.com/sharepoint/soap/".equals(namespaceURI) &&
                  "FieldInformationCollection".equals(typeName))
            {

                return FieldInformationCollection.Factory.parse(reader);

            }

            if ("http://schemas.microsoft.com/sharepoint/soap/".equals(namespaceURI) &&
                  "CopyErrorCode".equals(typeName))
            {

                return CopyErrorCode.Factory.parse(reader);

            }

            if ("http://schemas.microsoft.com/sharepoint/soap/".equals(namespaceURI) &&
                  "DestinationUrlCollection".equals(typeName))
            {

                return DestinationUrlCollection.Factory.parse(reader);

            }

            if ("http://microsoft.com/wsdl/types/".equals(namespaceURI) &&
                  "guid".equals(typeName))
            {

                return Guid.Factory.parse(reader);

            }

            if ("http://schemas.microsoft.com/sharepoint/soap/".equals(namespaceURI) &&
                  "FieldInformation".equals(typeName))
            {

                return FieldInformation.Factory.parse(reader);

            }

            if ("http://schemas.microsoft.com/sharepoint/soap/".equals(namespaceURI) &&
                  "FieldType".equals(typeName))
            {

                return FieldType.Factory.parse(reader);

            }

            if ("http://schemas.microsoft.com/sharepoint/soap/".equals(namespaceURI) &&
                  "CopyResultCollection".equals(typeName))
            {

                return CopyResultCollection.Factory.parse(reader);

            }

            throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI
                                                                + " "
                                                                + typeName);
        }

    }

    public static class FieldInformationCollection
                            implements org.apache.axis2.databinding.ADBBean
    {
        /*
         * This type was generated from the piece of schema that had name = FieldInformationCollection
         * Namespace URI = http://schemas.microsoft.com/sharepoint/soap/ Namespace Prefix = ns1
         */

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for FieldInformation This was an Array!
         */

        protected FieldInformation[] localFieldInformation;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localFieldInformationTracker = false;

        /**
         * Auto generated getter method
         * @return FieldInformation[]
         */
        public FieldInformation[] getFieldInformation()
        {
            return localFieldInformation;
        }

        /**
         * validate the array for FieldInformation
         */
        protected void validateFieldInformation(final FieldInformation[] param)
        {

        }

        /**
         * Auto generated setter method
         * @param param FieldInformation
         */
        public void setFieldInformation(final FieldInformation[] param)
        {

            validateFieldInformation(param);

            if (param != null)
            {
                // update the setting tracker
                localFieldInformationTracker = true;
            }
            else
            {
                localFieldInformationTracker = true;

            }

            this.localFieldInformation = param;
        }

        /**
         * Auto generated add method for the array for convenience
         * @param param FieldInformation
         */
        public void addFieldInformation(final FieldInformation param)
        {
            if (localFieldInformation == null)
            {
                localFieldInformation = new FieldInformation[] {};
            }

            // update the setting tracker
            localFieldInformationTracker = true;

            java.util.List list =
                                  org.apache.axis2.databinding.utils.ConverterUtil
                                                          .toList(localFieldInformation);
            list.add(param);
            this.localFieldInformation =
                                         (FieldInformation[])list.toArray(
                                                                 new FieldInformation[list.size()]);

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         parentQName)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  FieldInformationCollection.this
                                                                                          .serialize(parentQName,
                                                                                                     factory,
                                                                                                     xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          parentQName, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            java.lang.String prefix = null;
            java.lang.String namespace = null;

            prefix = parentQName.getPrefix();
            namespace = parentQName.getNamespaceURI();

            if ((namespace != null) && (namespace.trim().length() > 0))
            {
                java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                if (writerPrefix != null)
                {
                    xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                }
                else
                {
                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);
                    }

                    xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }
            }
            else
            {
                xmlWriter.writeStartElement(parentQName.getLocalPart());
            }

            if (serializeType)
            {

                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   namespacePrefix + ":FieldInformationCollection",
                                   xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   "FieldInformationCollection",
                                   xmlWriter);
                }

            }
            if (localFieldInformationTracker)
            {
                if (localFieldInformation != null)
                {
                    for (int i = 0; i < localFieldInformation.length; i++)
                    {
                        if (localFieldInformation[i] != null)
                        {
                            localFieldInformation[i]
                                                    .serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                             "FieldInformation"),
                                                               factory,
                                                               xmlWriter);
                        }
                        else
                        {

                            // write null attribute
                            java.lang.String namespace2 = "http://schemas.microsoft.com/sharepoint/soap/";
                            if (!namespace2.equals(""))
                            {
                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                if (prefix2 == null)
                                {
                                    prefix2 = generatePrefix(namespace2);

                                    xmlWriter.writeStartElement(prefix2, "FieldInformation", namespace2);
                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                    xmlWriter.setPrefix(prefix2, namespace2);

                                }
                                else
                                {
                                    xmlWriter.writeStartElement(namespace2, "FieldInformation");
                                }

                            }
                            else
                            {
                                xmlWriter.writeStartElement("FieldInformation");
                            }

                            // write the nil attribute
                            writeAttribute("xsi",
                                           "http://www.w3.org/2001/XMLSchema-instance",
                                           "nil",
                                           "1",
                                           xmlWriter);
                            xmlWriter.writeEndElement();

                        }

                    }
                }
                else
                {

                    // write null attribute
                    java.lang.String namespace2 = "http://schemas.microsoft.com/sharepoint/soap/";
                    if (!namespace2.equals(""))
                    {
                        java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                        if (prefix2 == null)
                        {
                            prefix2 = generatePrefix(namespace2);

                            xmlWriter.writeStartElement(prefix2, "FieldInformation", namespace2);
                            xmlWriter.writeNamespace(prefix2, namespace2);
                            xmlWriter.setPrefix(prefix2, namespace2);

                        }
                        else
                        {
                            xmlWriter.writeStartElement(namespace2, "FieldInformation");
                        }

                    }
                    else
                    {
                        xmlWriter.writeStartElement("FieldInformation");
                    }

                    // write the nil attribute
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
                    xmlWriter.writeEndElement();

                }
            }
            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            java.util.ArrayList elementList = new java.util.ArrayList();
            java.util.ArrayList attribList = new java.util.ArrayList();

            if (localFieldInformationTracker)
            {
                if (localFieldInformation != null)
                {
                    for (int i = 0; i < localFieldInformation.length; i++)
                    {

                        if (localFieldInformation[i] != null)
                        {
                            elementList
                                                    .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                       "FieldInformation"));
                            elementList.add(localFieldInformation[i]);
                        }
                        else
                        {

                            elementList
                                                    .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                       "FieldInformation"));
                            elementList.add(null);

                        }

                    }
                }
                else
                {

                    elementList
                                            .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                               "FieldInformation"));
                    elementList.add(localFieldInformation);

                }

            }

            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
                                                                                        elementList.toArray(),
                                                                                        attribList.toArray());

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static FieldInformationCollection parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                FieldInformationCollection object =
                                                    new FieldInformationCollection();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null)
                    {
                        java.lang.String fullTypeName = reader
                                                .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                   "type");
                        if (fullTypeName != null)
                        {
                            java.lang.String nsPrefix = null;
                            if (fullTypeName.indexOf(":") > -1)
                            {
                                nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                            }
                            nsPrefix = nsPrefix == null ? "" : nsPrefix;

                            java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);

                            if (!"FieldInformationCollection".equals(type))
                            {
                                // find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext()
                                                        .getNamespaceURI(nsPrefix);
                                return (FieldInformationCollection)ExtensionMapper.getTypeObject(
                                                                                                 nsUri,
                                                                                                 type,
                                                                                                 reader);
                            }

                        }

                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    reader.next();

                    java.util.ArrayList list1 = new java.util.ArrayList();

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "FieldInformation")
                                                .equals(reader.getName()))
                    {

                        // Process the array and step past its final element's end.

                        nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                 "nil");
                        if ("true".equals(nillableValue) || "1".equals(nillableValue))
                        {
                            list1.add(null);
                            reader.next();
                        }
                        else
                        {
                            list1.add(FieldInformation.Factory.parse(reader));
                        }
                        // loop until we find a start element that is not part of this array
                        boolean loopDone1 = false;
                        while (!loopDone1)
                        {
                            // We should be at the end element, but make sure
                            while (!reader.isEndElement())
                            {
                                reader.next();
                            }
                            // Step out of this element
                            reader.next();
                            // Step to next element event.
                            while (!reader.isStartElement() && !reader.isEndElement())
                            {
                                reader.next();
                            }
                            if (reader.isEndElement())
                            {
                                // two continuous end elements means we are exiting the xml structure
                                loopDone1 = true;
                            }
                            else
                            {
                                if (new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                  "FieldInformation")
                                                        .equals(reader.getName()))
                                {

                                    nillableValue = reader
                                                            .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                               "nil");
                                    if ("true".equals(nillableValue) || "1".equals(nillableValue))
                                    {
                                        list1.add(null);
                                        reader.next();
                                    }
                                    else
                                    {
                                        list1.add(FieldInformation.Factory.parse(reader));
                                    }
                                }
                                else
                                {
                                    loopDone1 = true;
                                }
                            }
                        }
                        // call the converter utility to convert and set the array

                        object
                                                .setFieldInformation((FieldInformation[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil
                                                                                    .convertToArray(
                                                                                                    FieldInformation.class,
                                                                                                    list1));

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement())
                    {
                        // A start element we are not expecting indicates a trailing invalid property
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class GetItem
                            implements org.apache.axis2.databinding.ADBBean
    {

        public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                                                                                               "http://schemas.microsoft.com/sharepoint/soap/",
                                                                                               "GetItem",
                                                                                               "ns1");

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for Url
         */

        protected java.lang.String localUrl;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localUrlTracker = false;

        /**
         * Auto generated getter method
         * @return java.lang.String
         */
        public java.lang.String getUrl()
        {
            return localUrl;
        }

        /**
         * Auto generated setter method
         * @param param Url
         */
        public void setUrl(final java.lang.String param)
        {

            if (param != null)
            {
                // update the setting tracker
                localUrlTracker = true;
            }
            else
            {
                localUrlTracker = false;

            }

            this.localUrl = param;

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         MY_QNAME)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  GetItem.this.serialize(MY_QNAME,
                                                                                         factory,
                                                                                         xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          MY_QNAME, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            java.lang.String prefix = null;
            java.lang.String namespace = null;

            prefix = parentQName.getPrefix();
            namespace = parentQName.getNamespaceURI();

            if ((namespace != null) && (namespace.trim().length() > 0))
            {
                java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                if (writerPrefix != null)
                {
                    xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                }
                else
                {
                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);
                    }

                    xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }
            }
            else
            {
                xmlWriter.writeStartElement(parentQName.getLocalPart());
            }

            if (serializeType)
            {

                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   namespacePrefix + ":GetItem",
                                   xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   "GetItem",
                                   xmlWriter);
                }

            }
            if (localUrlTracker)
            {
                namespace = "http://schemas.microsoft.com/sharepoint/soap/";
                if (!namespace.equals(""))
                {
                    prefix = xmlWriter.getPrefix(namespace);

                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);

                        xmlWriter.writeStartElement(prefix, "Url", namespace);
                        xmlWriter.writeNamespace(prefix, namespace);
                        xmlWriter.setPrefix(prefix, namespace);

                    }
                    else
                    {
                        xmlWriter.writeStartElement(namespace, "Url");
                    }

                }
                else
                {
                    xmlWriter.writeStartElement("Url");
                }

                if (localUrl == null)
                {
                    // write the nil attribute

                    throw new org.apache.axis2.databinding.ADBException("Url cannot be null!!");

                }
                else
                {

                    xmlWriter.writeCharacters(localUrl);

                }

                xmlWriter.writeEndElement();
            }
            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            java.util.ArrayList elementList = new java.util.ArrayList();
            java.util.ArrayList attribList = new java.util.ArrayList();

            if (localUrlTracker)
            {
                elementList
                                        .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                           "Url"));

                if (localUrl != null)
                {
                    elementList.add(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(localUrl));
                }
                else
                {
                    throw new org.apache.axis2.databinding.ADBException("Url cannot be null!!");
                }
            }

            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
                                                                                        elementList.toArray(),
                                                                                        attribList.toArray());

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static GetItem parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                GetItem object =
                                 new GetItem();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null)
                    {
                        java.lang.String fullTypeName = reader
                                                .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                   "type");
                        if (fullTypeName != null)
                        {
                            java.lang.String nsPrefix = null;
                            if (fullTypeName.indexOf(":") > -1)
                            {
                                nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                            }
                            nsPrefix = nsPrefix == null ? "" : nsPrefix;

                            java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);

                            if (!"GetItem".equals(type))
                            {
                                // find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext()
                                                        .getNamespaceURI(nsPrefix);
                                return (GetItem)ExtensionMapper.getTypeObject(
                                                                              nsUri, type, reader);
                            }

                        }

                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    reader.next();

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "Url").equals(reader
                                                .getName()))
                    {

                        java.lang.String content = reader.getElementText();

                        object.setUrl(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(content));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement())
                    {
                        // A start element we are not expecting indicates a trailing invalid property
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class DestinationUrlCollection
                            implements org.apache.axis2.databinding.ADBBean
    {
        /*
         * This type was generated from the piece of schema that had name = DestinationUrlCollection Namespace
         * URI = http://schemas.microsoft.com/sharepoint/soap/ Namespace Prefix = ns1
         */

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for String This was an Array!
         */

        protected java.lang.String[] localString;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localStringTracker = false;

        /**
         * Auto generated getter method
         * @return java.lang.String[]
         */
        public java.lang.String[] getString()
        {
            return localString;
        }

        /**
         * validate the array for String
         */
        protected void validateString(final java.lang.String[] param)
        {

        }

        /**
         * Auto generated setter method
         * @param param String
         */
        public void setString(final java.lang.String[] param)
        {

            validateString(param);

            if (param != null)
            {
                // update the setting tracker
                localStringTracker = true;
            }
            else
            {
                localStringTracker = true;

            }

            this.localString = param;
        }

        /**
         * Auto generated add method for the array for convenience
         * @param param java.lang.String
         */
        public void addString(final java.lang.String param)
        {
            if (localString == null)
            {
                localString = new java.lang.String[] {};
            }

            // update the setting tracker
            localStringTracker = true;

            java.util.List list =
                                  org.apache.axis2.databinding.utils.ConverterUtil.toList(localString);
            list.add(param);
            this.localString =
                               (java.lang.String[])list.toArray(
                                                       new java.lang.String[list.size()]);

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         parentQName)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  DestinationUrlCollection.this
                                                                                          .serialize(parentQName,
                                                                                                     factory,
                                                                                                     xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          parentQName, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            java.lang.String prefix = null;
            java.lang.String namespace = null;

            prefix = parentQName.getPrefix();
            namespace = parentQName.getNamespaceURI();

            if ((namespace != null) && (namespace.trim().length() > 0))
            {
                java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                if (writerPrefix != null)
                {
                    xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                }
                else
                {
                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);
                    }

                    xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }
            }
            else
            {
                xmlWriter.writeStartElement(parentQName.getLocalPart());
            }

            if (serializeType)
            {

                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   namespacePrefix + ":DestinationUrlCollection",
                                   xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   "DestinationUrlCollection",
                                   xmlWriter);
                }

            }
            if (localStringTracker)
            {
                if (localString != null)
                {
                    namespace = "http://schemas.microsoft.com/sharepoint/soap/";
                    boolean emptyNamespace = namespace == null || namespace.length() == 0;
                    prefix = emptyNamespace ? null : xmlWriter.getPrefix(namespace);
                    for (int i = 0; i < localString.length; i++)
                    {

                        if (localString[i] != null)
                        {

                            if (!emptyNamespace)
                            {
                                if (prefix == null)
                                {
                                    java.lang.String prefix2 = generatePrefix(namespace);

                                    xmlWriter.writeStartElement(prefix2, "string", namespace);
                                    xmlWriter.writeNamespace(prefix2, namespace);
                                    xmlWriter.setPrefix(prefix2, namespace);

                                }
                                else
                                {
                                    xmlWriter.writeStartElement(namespace, "string");
                                }

                            }
                            else
                            {
                                xmlWriter.writeStartElement("string");
                            }

                            xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(localString[i]));

                            xmlWriter.writeEndElement();

                        }
                        else
                        {

                            // write null attribute
                            namespace = "http://schemas.microsoft.com/sharepoint/soap/";
                            if (!namespace.equals(""))
                            {
                                prefix = xmlWriter.getPrefix(namespace);

                                if (prefix == null)
                                {
                                    prefix = generatePrefix(namespace);

                                    xmlWriter.writeStartElement(prefix, "string", namespace);
                                    xmlWriter.writeNamespace(prefix, namespace);
                                    xmlWriter.setPrefix(prefix, namespace);

                                }
                                else
                                {
                                    xmlWriter.writeStartElement(namespace, "string");
                                }

                            }
                            else
                            {
                                xmlWriter.writeStartElement("string");
                            }
                            writeAttribute("xsi",
                                           "http://www.w3.org/2001/XMLSchema-instance",
                                           "nil",
                                           "1",
                                           xmlWriter);
                            xmlWriter.writeEndElement();

                        }

                    }
                }
                else
                {

                    // write the null attribute
                    // write null attribute
                    java.lang.String namespace2 = "http://schemas.microsoft.com/sharepoint/soap/";
                    if (!namespace2.equals(""))
                    {
                        java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                        if (prefix2 == null)
                        {
                            prefix2 = generatePrefix(namespace2);

                            xmlWriter.writeStartElement(prefix2, "string", namespace2);
                            xmlWriter.writeNamespace(prefix2, namespace2);
                            xmlWriter.setPrefix(prefix2, namespace2);

                        }
                        else
                        {
                            xmlWriter.writeStartElement(namespace2, "string");
                        }

                    }
                    else
                    {
                        xmlWriter.writeStartElement("string");
                    }

                    // write the nil attribute
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
                    xmlWriter.writeEndElement();

                }

            }
            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            java.util.ArrayList elementList = new java.util.ArrayList();
            java.util.ArrayList attribList = new java.util.ArrayList();

            if (localStringTracker)
            {
                if (localString != null)
                {
                    for (int i = 0; i < localString.length; i++)
                    {

                        if (localString[i] != null)
                        {
                            elementList
                                                    .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                       "string"));
                            elementList.add(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(localString[i]));
                        }
                        else
                        {

                            elementList
                                                    .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                       "string"));
                            elementList.add(null);

                        }

                    }
                }
                else
                {

                    elementList
                                            .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                               "string"));
                    elementList.add(null);

                }

            }

            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
                                                                                        elementList.toArray(),
                                                                                        attribList.toArray());

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static DestinationUrlCollection parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                DestinationUrlCollection object =
                                                  new DestinationUrlCollection();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null)
                    {
                        java.lang.String fullTypeName = reader
                                                .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                   "type");
                        if (fullTypeName != null)
                        {
                            java.lang.String nsPrefix = null;
                            if (fullTypeName.indexOf(":") > -1)
                            {
                                nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                            }
                            nsPrefix = nsPrefix == null ? "" : nsPrefix;

                            java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);

                            if (!"DestinationUrlCollection".equals(type))
                            {
                                // find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext()
                                                        .getNamespaceURI(nsPrefix);
                                return (DestinationUrlCollection)ExtensionMapper.getTypeObject(
                                                                                               nsUri,
                                                                                               type,
                                                                                               reader);
                            }

                        }

                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    reader.next();

                    java.util.ArrayList list1 = new java.util.ArrayList();

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "string").equals(reader
                                                .getName()))
                    {

                        // Process the array and step past its final element's end.

                        nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                 "nil");
                        if ("true".equals(nillableValue) || "1".equals(nillableValue))
                        {
                            list1.add(null);

                            reader.next();
                        }
                        else
                        {
                            list1.add(reader.getElementText());
                        }
                        // loop until we find a start element that is not part of this array
                        boolean loopDone1 = false;
                        while (!loopDone1)
                        {
                            // Ensure we are at the EndElement
                            while (!reader.isEndElement())
                            {
                                reader.next();
                            }
                            // Step out of this element
                            reader.next();
                            // Step to next element event.
                            while (!reader.isStartElement() && !reader.isEndElement())
                            {
                                reader.next();
                            }
                            if (reader.isEndElement())
                            {
                                // two continuous end elements means we are exiting the xml structure
                                loopDone1 = true;
                            }
                            else
                            {
                                if (new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                  "string").equals(reader.getName()))
                                {

                                    nillableValue = reader
                                                            .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                               "nil");
                                    if ("true".equals(nillableValue) || "1".equals(nillableValue))
                                    {
                                        list1.add(null);

                                        reader.next();
                                    }
                                    else
                                    {
                                        list1.add(reader.getElementText());
                                    }
                                }
                                else
                                {
                                    loopDone1 = true;
                                }
                            }
                        }
                        // call the converter utility to convert and set the array

                        object.setString((java.lang.String[])
                                                        list1.toArray(new java.lang.String[list1.size()]));

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement())
                    {
                        // A start element we are not expecting indicates a trailing invalid property
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class CopyIntoItemsLocal
                            implements org.apache.axis2.databinding.ADBBean
    {

        public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                                                                                               "http://schemas.microsoft.com/sharepoint/soap/",
                                                                                               "CopyIntoItemsLocal",
                                                                                               "ns1");

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for SourceUrl
         */

        protected java.lang.String localSourceUrl;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localSourceUrlTracker = false;

        /**
         * Auto generated getter method
         * @return java.lang.String
         */
        public java.lang.String getSourceUrl()
        {
            return localSourceUrl;
        }

        /**
         * Auto generated setter method
         * @param param SourceUrl
         */
        public void setSourceUrl(final java.lang.String param)
        {

            if (param != null)
            {
                // update the setting tracker
                localSourceUrlTracker = true;
            }
            else
            {
                localSourceUrlTracker = false;

            }

            this.localSourceUrl = param;

        }

        /**
         * field for DestinationUrls
         */

        protected DestinationUrlCollection localDestinationUrls;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localDestinationUrlsTracker = false;

        /**
         * Auto generated getter method
         * @return DestinationUrlCollection
         */
        public DestinationUrlCollection getDestinationUrls()
        {
            return localDestinationUrls;
        }

        /**
         * Auto generated setter method
         * @param param DestinationUrls
         */
        public void setDestinationUrls(final DestinationUrlCollection param)
        {

            if (param != null)
            {
                // update the setting tracker
                localDestinationUrlsTracker = true;
            }
            else
            {
                localDestinationUrlsTracker = false;

            }

            this.localDestinationUrls = param;

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         MY_QNAME)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  CopyIntoItemsLocal.this
                                                                                          .serialize(MY_QNAME,
                                                                                                     factory,
                                                                                                     xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          MY_QNAME, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            java.lang.String prefix = null;
            java.lang.String namespace = null;

            prefix = parentQName.getPrefix();
            namespace = parentQName.getNamespaceURI();

            if ((namespace != null) && (namespace.trim().length() > 0))
            {
                java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                if (writerPrefix != null)
                {
                    xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                }
                else
                {
                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);
                    }

                    xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }
            }
            else
            {
                xmlWriter.writeStartElement(parentQName.getLocalPart());
            }

            if (serializeType)
            {

                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   namespacePrefix + ":CopyIntoItemsLocal",
                                   xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   "CopyIntoItemsLocal",
                                   xmlWriter);
                }

            }
            if (localSourceUrlTracker)
            {
                namespace = "http://schemas.microsoft.com/sharepoint/soap/";
                if (!namespace.equals(""))
                {
                    prefix = xmlWriter.getPrefix(namespace);

                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);

                        xmlWriter.writeStartElement(prefix, "SourceUrl", namespace);
                        xmlWriter.writeNamespace(prefix, namespace);
                        xmlWriter.setPrefix(prefix, namespace);

                    }
                    else
                    {
                        xmlWriter.writeStartElement(namespace, "SourceUrl");
                    }

                }
                else
                {
                    xmlWriter.writeStartElement("SourceUrl");
                }

                if (localSourceUrl == null)
                {
                    // write the nil attribute

                    throw new org.apache.axis2.databinding.ADBException("SourceUrl cannot be null!!");

                }
                else
                {

                    xmlWriter.writeCharacters(localSourceUrl);

                }

                xmlWriter.writeEndElement();
            }
            if (localDestinationUrlsTracker)
            {
                if (localDestinationUrls == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("DestinationUrls cannot be null!!");
                }
                localDestinationUrls
                                        .serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "DestinationUrls"),
                                                   factory,
                                                   xmlWriter);
            }
            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            java.util.ArrayList elementList = new java.util.ArrayList();
            java.util.ArrayList attribList = new java.util.ArrayList();

            if (localSourceUrlTracker)
            {
                elementList
                                        .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                           "SourceUrl"));

                if (localSourceUrl != null)
                {
                    elementList.add(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(localSourceUrl));
                }
                else
                {
                    throw new org.apache.axis2.databinding.ADBException("SourceUrl cannot be null!!");
                }
            }
            if (localDestinationUrlsTracker)
            {
                elementList
                                        .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                           "DestinationUrls"));

                if (localDestinationUrls == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("DestinationUrls cannot be null!!");
                }
                elementList.add(localDestinationUrls);
            }

            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
                                                                                        elementList.toArray(),
                                                                                        attribList.toArray());

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static CopyIntoItemsLocal parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                CopyIntoItemsLocal object =
                                            new CopyIntoItemsLocal();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null)
                    {
                        java.lang.String fullTypeName = reader
                                                .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                   "type");
                        if (fullTypeName != null)
                        {
                            java.lang.String nsPrefix = null;
                            if (fullTypeName.indexOf(":") > -1)
                            {
                                nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                            }
                            nsPrefix = nsPrefix == null ? "" : nsPrefix;

                            java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);

                            if (!"CopyIntoItemsLocal".equals(type))
                            {
                                // find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext()
                                                        .getNamespaceURI(nsPrefix);
                                return (CopyIntoItemsLocal)ExtensionMapper.getTypeObject(
                                                                                         nsUri, type, reader);
                            }

                        }

                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    reader.next();

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "SourceUrl").equals(reader
                                                .getName()))
                    {

                        java.lang.String content = reader.getElementText();

                        object.setSourceUrl(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(content));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "DestinationUrls")
                                                .equals(reader.getName()))
                    {

                        object.setDestinationUrls(DestinationUrlCollection.Factory.parse(reader));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement())
                    {
                        // A start element we are not expecting indicates a trailing invalid property
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class CopyIntoItemsLocalResponse
                            implements org.apache.axis2.databinding.ADBBean
    {

        public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                                                                                               "http://schemas.microsoft.com/sharepoint/soap/",
                                                                                               "CopyIntoItemsLocalResponse",
                                                                                               "ns1");

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for CopyIntoItemsLocalResult
         */

        protected org.apache.axis2.databinding.types.UnsignedInt localCopyIntoItemsLocalResult;

        /**
         * Auto generated getter method
         * @return org.apache.axis2.databinding.types.UnsignedInt
         */
        public org.apache.axis2.databinding.types.UnsignedInt getCopyIntoItemsLocalResult()
        {
            return localCopyIntoItemsLocalResult;
        }

        /**
         * Auto generated setter method
         * @param param CopyIntoItemsLocalResult
         */
        public void setCopyIntoItemsLocalResult(final org.apache.axis2.databinding.types.UnsignedInt param)
        {

            this.localCopyIntoItemsLocalResult = param;

        }

        /**
         * field for Results
         */

        protected CopyResultCollection localResults;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localResultsTracker = false;

        /**
         * Auto generated getter method
         * @return CopyResultCollection
         */
        public CopyResultCollection getResults()
        {
            return localResults;
        }

        /**
         * Auto generated setter method
         * @param param Results
         */
        public void setResults(final CopyResultCollection param)
        {

            if (param != null)
            {
                // update the setting tracker
                localResultsTracker = true;
            }
            else
            {
                localResultsTracker = false;

            }

            this.localResults = param;

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         MY_QNAME)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  CopyIntoItemsLocalResponse.this
                                                                                          .serialize(MY_QNAME,
                                                                                                     factory,
                                                                                                     xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          MY_QNAME, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            java.lang.String prefix = null;
            java.lang.String namespace = null;

            prefix = parentQName.getPrefix();
            namespace = parentQName.getNamespaceURI();

            if ((namespace != null) && (namespace.trim().length() > 0))
            {
                java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                if (writerPrefix != null)
                {
                    xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                }
                else
                {
                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);
                    }

                    xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }
            }
            else
            {
                xmlWriter.writeStartElement(parentQName.getLocalPart());
            }

            if (serializeType)
            {

                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   namespacePrefix + ":CopyIntoItemsLocalResponse",
                                   xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   "CopyIntoItemsLocalResponse",
                                   xmlWriter);
                }

            }

            namespace = "http://schemas.microsoft.com/sharepoint/soap/";
            if (!namespace.equals(""))
            {
                prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null)
                {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, "CopyIntoItemsLocalResult", namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);

                }
                else
                {
                    xmlWriter.writeStartElement(namespace, "CopyIntoItemsLocalResult");
                }

            }
            else
            {
                xmlWriter.writeStartElement("CopyIntoItemsLocalResult");
            }

            if (localCopyIntoItemsLocalResult == null)
            {
                // write the nil attribute

                throw new org.apache.axis2.databinding.ADBException("CopyIntoItemsLocalResult cannot be null!!");

            }
            else
            {

                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(localCopyIntoItemsLocalResult));

            }

            xmlWriter.writeEndElement();
            if (localResultsTracker)
            {
                if (localResults == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("Results cannot be null!!");
                }
                localResults
                                        .serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "Results"),
                                                   factory,
                                                   xmlWriter);
            }
            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            java.util.ArrayList elementList = new java.util.ArrayList();
            java.util.ArrayList attribList = new java.util.ArrayList();

            elementList.add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                      "CopyIntoItemsLocalResult"));

            if (localCopyIntoItemsLocalResult != null)
            {
                elementList.add(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(localCopyIntoItemsLocalResult));
            }
            else
            {
                throw new org.apache.axis2.databinding.ADBException("CopyIntoItemsLocalResult cannot be null!!");
            }
            if (localResultsTracker)
            {
                elementList
                                        .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                           "Results"));

                if (localResults == null)
                {
                    throw new org.apache.axis2.databinding.ADBException("Results cannot be null!!");
                }
                elementList.add(localResults);
            }

            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
                                                                                        elementList.toArray(),
                                                                                        attribList.toArray());

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static CopyIntoItemsLocalResponse parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                CopyIntoItemsLocalResponse object =
                                                    new CopyIntoItemsLocalResponse();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null)
                    {
                        java.lang.String fullTypeName = reader
                                                .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                   "type");
                        if (fullTypeName != null)
                        {
                            java.lang.String nsPrefix = null;
                            if (fullTypeName.indexOf(":") > -1)
                            {
                                nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                            }
                            nsPrefix = nsPrefix == null ? "" : nsPrefix;

                            java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);

                            if (!"CopyIntoItemsLocalResponse".equals(type))
                            {
                                // find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext()
                                                        .getNamespaceURI(nsPrefix);
                                return (CopyIntoItemsLocalResponse)ExtensionMapper.getTypeObject(
                                                                                                 nsUri,
                                                                                                 type,
                                                                                                 reader);
                            }

                        }

                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    reader.next();

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "CopyIntoItemsLocalResult")
                                                .equals(reader.getName()))
                    {

                        java.lang.String content = reader.getElementText();

                        object.setCopyIntoItemsLocalResult(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToUnsignedInt(content));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {
                        // A start element we are not expecting indicates an invalid parameter was passed
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "Results").equals(reader
                                                .getName()))
                    {

                        object.setResults(CopyResultCollection.Factory.parse(reader));

                        reader.next();

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement())
                    {
                        // A start element we are not expecting indicates a trailing invalid property
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class FieldInformation
                            implements org.apache.axis2.databinding.ADBBean
    {
        /*
         * This type was generated from the piece of schema that had name = FieldInformation Namespace URI =
         * http://schemas.microsoft.com/sharepoint/soap/ Namespace Prefix = ns1
         */

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for Type This was an Attribute!
         */

        protected FieldType localType;

        /**
         * Auto generated getter method
         * @return FieldType
         */
        public FieldType getType()
        {
            return localType;
        }

        /**
         * Auto generated setter method
         * @param param Type
         */
        public void setType(final FieldType param)
        {

            this.localType = param;

        }

        /**
         * field for DisplayName This was an Attribute!
         */

        protected java.lang.String localDisplayName;

        /**
         * Auto generated getter method
         * @return java.lang.String
         */
        public java.lang.String getDisplayName()
        {
            return localDisplayName;
        }

        /**
         * Auto generated setter method
         * @param param DisplayName
         */
        public void setDisplayName(final java.lang.String param)
        {

            this.localDisplayName = param;

        }

        /**
         * field for InternalName This was an Attribute!
         */

        protected java.lang.String localInternalName;

        /**
         * Auto generated getter method
         * @return java.lang.String
         */
        public java.lang.String getInternalName()
        {
            return localInternalName;
        }

        /**
         * Auto generated setter method
         * @param param InternalName
         */
        public void setInternalName(final java.lang.String param)
        {

            this.localInternalName = param;

        }

        /**
         * field for Id This was an Attribute!
         */

        protected Guid localId;

        /**
         * Auto generated getter method
         * @return Guid
         */
        public Guid getId()
        {
            return localId;
        }

        /**
         * Auto generated setter method
         * @param param Id
         */
        public void setId(final Guid param)
        {

            this.localId = param;

        }

        /**
         * field for Value This was an Attribute!
         */

        protected java.lang.String localValue;

        /**
         * Auto generated getter method
         * @return java.lang.String
         */
        public java.lang.String getValue()
        {
            return localValue;
        }

        /**
         * Auto generated setter method
         * @param param Value
         */
        public void setValue(final java.lang.String param)
        {

            this.localValue = param;

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         parentQName)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  FieldInformation.this
                                                                                          .serialize(parentQName,
                                                                                                     factory,
                                                                                                     xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          parentQName, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            java.lang.String prefix = null;
            java.lang.String namespace = null;

            prefix = parentQName.getPrefix();
            namespace = parentQName.getNamespaceURI();

            if ((namespace != null) && (namespace.trim().length() > 0))
            {
                java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                if (writerPrefix != null)
                {
                    xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                }
                else
                {
                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);
                    }

                    xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }
            }
            else
            {
                xmlWriter.writeStartElement(parentQName.getLocalPart());
            }

            if (serializeType)
            {

                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   namespacePrefix + ":FieldInformation",
                                   xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   "FieldInformation",
                                   xmlWriter);
                }

            }

            if (localType != null)
            {
                writeAttribute("",
                                           "Type",
                                           localType.toString(), xmlWriter);
            }

            else
            {
                throw new org.apache.axis2.databinding.ADBException("required attribute localType is null");
            }

            if (localDisplayName != null)
            {

                writeAttribute("",
                                                         "DisplayName",
                                                         org.apache.axis2.databinding.utils.ConverterUtil
                                                                                 .convertToString(localDisplayName),
                               xmlWriter);

            }

            if (localInternalName != null)
            {

                writeAttribute("",
                                                         "InternalName",
                                                         org.apache.axis2.databinding.utils.ConverterUtil
                                                                                 .convertToString(localInternalName),
                               xmlWriter);

            }

            if (localId != null)
            {
                writeAttribute("",
                                           "Id",
                                           localId.toString(), xmlWriter);
            }

            else
            {
                throw new org.apache.axis2.databinding.ADBException("required attribute localId is null");
            }

            if (localValue != null)
            {

                writeAttribute("",
                                                         "Value",
                                                         org.apache.axis2.databinding.utils.ConverterUtil
                                                                                 .convertToString(localValue),
                               xmlWriter);

            }

            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            java.util.ArrayList elementList = new java.util.ArrayList();
            java.util.ArrayList attribList = new java.util.ArrayList();

            attribList.add(
                                    new javax.xml.namespace.QName("", "Type"));

            attribList.add(localType.toString());

            attribList.add(
                                    new javax.xml.namespace.QName("", "DisplayName"));

            attribList
                                    .add(org.apache.axis2.databinding.utils.ConverterUtil
                                                            .convertToString(localDisplayName));

            attribList.add(
                                    new javax.xml.namespace.QName("", "InternalName"));

            attribList.add(org.apache.axis2.databinding.utils.ConverterUtil
                                    .convertToString(localInternalName));

            attribList.add(
                                    new javax.xml.namespace.QName("", "Id"));

            attribList.add(localId.toString());

            attribList.add(
                                    new javax.xml.namespace.QName("", "Value"));

            attribList.add(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(localValue));

            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
                                                                                        elementList.toArray(),
                                                                                        attribList.toArray());

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static FieldInformation parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                FieldInformation object =
                                          new FieldInformation();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null)
                    {
                        java.lang.String fullTypeName = reader
                                                .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                   "type");
                        if (fullTypeName != null)
                        {
                            java.lang.String nsPrefix = null;
                            if (fullTypeName.indexOf(":") > -1)
                            {
                                nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                            }
                            nsPrefix = nsPrefix == null ? "" : nsPrefix;

                            java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);

                            if (!"FieldInformation".equals(type))
                            {
                                // find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext()
                                                        .getNamespaceURI(nsPrefix);
                                return (FieldInformation)ExtensionMapper.getTypeObject(
                                                                                       nsUri, type, reader);
                            }

                        }

                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    // handle attribute "Type"
                    java.lang.String tempAttribType =

                    reader.getAttributeValue(null, "Type");

                    if (tempAttribType != null)
                    {
                        java.lang.String content = tempAttribType;

                        object.setType(
                                                        FieldType.Factory.fromString(reader, tempAttribType));

                    }
                    else
                    {

                        throw new org.apache.axis2.databinding.ADBException("Required attribute Type is missing");

                    }
                    handledAttributes.add("Type");

                    // handle attribute "DisplayName"
                    java.lang.String tempAttribDisplayName =

                    reader.getAttributeValue(null, "DisplayName");

                    if (tempAttribDisplayName != null)
                    {
                        java.lang.String content = tempAttribDisplayName;

                        object
                                                .setDisplayName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(tempAttribDisplayName));

                    }
                    else
                    {

                    }
                    handledAttributes.add("DisplayName");

                    // handle attribute "InternalName"
                    java.lang.String tempAttribInternalName =

                    reader.getAttributeValue(null, "InternalName");

                    if (tempAttribInternalName != null)
                    {
                        java.lang.String content = tempAttribInternalName;

                        object
                                                .setInternalName(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(tempAttribInternalName));

                    }
                    else
                    {

                    }
                    handledAttributes.add("InternalName");

                    // handle attribute "Id"
                    java.lang.String tempAttribId =

                    reader.getAttributeValue(null, "Id");

                    if (tempAttribId != null)
                    {
                        java.lang.String content = tempAttribId;

                        object.setId(
                                                        Guid.Factory.fromString(reader, tempAttribId));

                    }
                    else
                    {

                        throw new org.apache.axis2.databinding.ADBException("Required attribute Id is missing");

                    }
                    handledAttributes.add("Id");

                    // handle attribute "Value"
                    java.lang.String tempAttribValue =

                    reader.getAttributeValue(null, "Value");

                    if (tempAttribValue != null)
                    {
                        java.lang.String content = tempAttribValue;

                        object
                                                .setValue(
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(tempAttribValue));

                    }
                    else
                    {

                    }
                    handledAttributes.add("Value");

                    reader.next();

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class FieldType
                            implements org.apache.axis2.databinding.ADBBean
    {

        public static final javax.xml.namespace.QName MY_QNAME = new javax.xml.namespace.QName(
                                                                                               "http://schemas.microsoft.com/sharepoint/soap/",
                                                                                               "FieldType",
                                                                                               "ns1");

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for FieldType
         */

        protected java.lang.String localFieldType;

        private static java.util.HashMap _table_ = new java.util.HashMap();

        // Constructor

        protected FieldType(final java.lang.String value, final boolean isRegisterValue)
        {
            localFieldType = value;
            if (isRegisterValue)
            {

                _table_.put(localFieldType, this);

            }

        }

        public static final java.lang.String _Invalid =
                                                        org.apache.axis2.databinding.utils.ConverterUtil
                                                                                .convertToString("Invalid");

        public static final java.lang.String _Integer =
                                                        org.apache.axis2.databinding.utils.ConverterUtil
                                                                                .convertToString("Integer");

        public static final java.lang.String _Text =
                                                     org.apache.axis2.databinding.utils.ConverterUtil
                                                                             .convertToString("Text");

        public static final java.lang.String _Note =
                                                     org.apache.axis2.databinding.utils.ConverterUtil
                                                                             .convertToString("Note");

        public static final java.lang.String _DateTime =
                                                         org.apache.axis2.databinding.utils.ConverterUtil
                                                                                 .convertToString("DateTime");

        public static final java.lang.String _Counter =
                                                        org.apache.axis2.databinding.utils.ConverterUtil
                                                                                .convertToString("Counter");

        public static final java.lang.String _Choice =
                                                       org.apache.axis2.databinding.utils.ConverterUtil
                                                                               .convertToString("Choice");

        public static final java.lang.String _Lookup =
                                                       org.apache.axis2.databinding.utils.ConverterUtil
                                                                               .convertToString("Lookup");

        public static final java.lang.String _Boolean =
                                                        org.apache.axis2.databinding.utils.ConverterUtil
                                                                                .convertToString("Boolean");

        public static final java.lang.String _Number =
                                                       org.apache.axis2.databinding.utils.ConverterUtil
                                                                               .convertToString("Number");

        public static final java.lang.String _Currency =
                                                         org.apache.axis2.databinding.utils.ConverterUtil
                                                                                 .convertToString("Currency");

        public static final java.lang.String _URL =
                                                    org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString("URL");

        public static final java.lang.String _Computed =
                                                         org.apache.axis2.databinding.utils.ConverterUtil
                                                                                 .convertToString("Computed");

        public static final java.lang.String _Threading =
                                                          org.apache.axis2.databinding.utils.ConverterUtil
                                                                                  .convertToString("Threading");

        public static final java.lang.String _Guid =
                                                     org.apache.axis2.databinding.utils.ConverterUtil
                                                                             .convertToString("Guid");

        public static final java.lang.String _MultiChoice =
                                                            org.apache.axis2.databinding.utils.ConverterUtil
                                                                                    .convertToString("MultiChoice");

        public static final java.lang.String _GridChoice =
                                                           org.apache.axis2.databinding.utils.ConverterUtil
                                                                                   .convertToString("GridChoice");

        public static final java.lang.String _Calculated =
                                                           org.apache.axis2.databinding.utils.ConverterUtil
                                                                                   .convertToString("Calculated");

        public static final java.lang.String _File =
                                                     org.apache.axis2.databinding.utils.ConverterUtil
                                                                             .convertToString("File");

        public static final java.lang.String _Attachments =
                                                            org.apache.axis2.databinding.utils.ConverterUtil
                                                                                    .convertToString("Attachments");

        public static final java.lang.String _User =
                                                     org.apache.axis2.databinding.utils.ConverterUtil
                                                                             .convertToString("User");

        public static final java.lang.String _Recurrence =
                                                           org.apache.axis2.databinding.utils.ConverterUtil
                                                                                   .convertToString("Recurrence");

        public static final java.lang.String _CrossProjectLink =
                                                                 org.apache.axis2.databinding.utils.ConverterUtil
                                                                                         .convertToString("CrossProjectLink");

        public static final java.lang.String _ModStat =
                                                        org.apache.axis2.databinding.utils.ConverterUtil
                                                                                .convertToString("ModStat");

        public static final java.lang.String _AllDayEvent =
                                                            org.apache.axis2.databinding.utils.ConverterUtil
                                                                                    .convertToString("AllDayEvent");

        public static final java.lang.String _Error =
                                                      org.apache.axis2.databinding.utils.ConverterUtil
                                                                              .convertToString("Error");

        public static final FieldType Invalid =
                                                new FieldType(_Invalid, true);

        public static final FieldType Integer =
                                                new FieldType(_Integer, true);

        public static final FieldType Text =
                                             new FieldType(_Text, true);

        public static final FieldType Note =
                                             new FieldType(_Note, true);

        public static final FieldType DateTime =
                                                 new FieldType(_DateTime, true);

        public static final FieldType Counter =
                                                new FieldType(_Counter, true);

        public static final FieldType Choice =
                                               new FieldType(_Choice, true);

        public static final FieldType Lookup =
                                               new FieldType(_Lookup, true);

        public static final FieldType Boolean =
                                                new FieldType(_Boolean, true);

        public static final FieldType Number =
                                               new FieldType(_Number, true);

        public static final FieldType Currency =
                                                 new FieldType(_Currency, true);

        public static final FieldType URL =
                                            new FieldType(_URL, true);

        public static final FieldType Computed =
                                                 new FieldType(_Computed, true);

        public static final FieldType Threading =
                                                  new FieldType(_Threading, true);

        public static final FieldType Guid =
                                             new FieldType(_Guid, true);

        public static final FieldType MultiChoice =
                                                    new FieldType(_MultiChoice, true);

        public static final FieldType GridChoice =
                                                   new FieldType(_GridChoice, true);

        public static final FieldType Calculated =
                                                   new FieldType(_Calculated, true);

        public static final FieldType File =
                                             new FieldType(_File, true);

        public static final FieldType Attachments =
                                                    new FieldType(_Attachments, true);

        public static final FieldType User =
                                             new FieldType(_User, true);

        public static final FieldType Recurrence =
                                                   new FieldType(_Recurrence, true);

        public static final FieldType CrossProjectLink =
                                                         new FieldType(_CrossProjectLink, true);

        public static final FieldType ModStat =
                                                new FieldType(_ModStat, true);

        public static final FieldType AllDayEvent =
                                                    new FieldType(_AllDayEvent, true);

        public static final FieldType Error =
                                              new FieldType(_Error, true);

        public java.lang.String getValue()
        {
            return localFieldType;
        }

        public boolean equals(final java.lang.Object obj)
        {
            return (obj == this);
        }

        public int hashCode()
        {
            return toString().hashCode();
        }

        public java.lang.String toString()
        {

            return localFieldType.toString();

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         MY_QNAME)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  FieldType.this.serialize(MY_QNAME,
                                                                                           factory,
                                                                                           xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          MY_QNAME, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            // We can safely assume an element has only one type associated with it

            java.lang.String namespace = parentQName.getNamespaceURI();
            java.lang.String localName = parentQName.getLocalPart();

            if (!namespace.equals(""))
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespace);

                if (prefix == null)
                {
                    prefix = generatePrefix(namespace);

                    xmlWriter.writeStartElement(prefix, localName, namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);

                }
                else
                {
                    xmlWriter.writeStartElement(namespace, localName);
                }

            }
            else
            {
                xmlWriter.writeStartElement(localName);
            }

            // add the type details if this is used in a simple type
            if (serializeType)
            {
                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                           namespacePrefix + ":FieldType",
                                           xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                           "FieldType",
                                           xmlWriter);
                }
            }

            if (localFieldType == null)
            {

                throw new org.apache.axis2.databinding.ADBException("Value cannot be null !!");

            }
            else
            {

                xmlWriter.writeCharacters(localFieldType);

            }

            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            // We can safely assume an element has only one type associated with it
            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(MY_QNAME,
                                                                                        new java.lang.Object[] {
                                                                                                                org.apache.axis2.databinding.utils.reader.ADBXMLStreamReader.ELEMENT_TEXT,
                                                                                                                org.apache.axis2.databinding.utils.ConverterUtil
                                                                                                                                        .convertToString(localFieldType)
                            },
                                                                                        null);

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            public static FieldType fromValue(final java.lang.String value)
                                                                           throws java.lang.IllegalArgumentException
            {
                FieldType enumeration = (FieldType)

                _table_.get(value);

                if (enumeration == null)
                {
                    throw new java.lang.IllegalArgumentException();
                }
                return enumeration;
            }

            public static FieldType fromString(final java.lang.String value,
                                               final java.lang.String namespaceURI)
                                                                                   throws java.lang.IllegalArgumentException
            {
                try
                {

                    return fromValue(org.apache.axis2.databinding.utils.ConverterUtil.convertToString(value));

                }
                catch (java.lang.Exception e)
                {
                    throw new java.lang.IllegalArgumentException();
                }
            }

            public static FieldType fromString(final javax.xml.stream.XMLStreamReader xmlStreamReader,
                                                                    final java.lang.String content)
            {
                if (content.indexOf(":") > -1)
                {
                    java.lang.String prefix = content.substring(0, content.indexOf(":"));
                    java.lang.String namespaceUri = xmlStreamReader.getNamespaceContext()
                                            .getNamespaceURI(prefix);
                    return FieldType.Factory.fromString(content, namespaceUri);
                }
                else
                {
                    return FieldType.Factory.fromString(content, "");
                }
            }

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static FieldType parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                FieldType object = null;
                // initialize a hash map to keep values
                java.util.Map attributeMap = new java.util.HashMap();
                java.util.List extraAttributeList = new java.util.ArrayList();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    while (!reader.isEndElement())
                    {
                        if (reader.isStartElement() || reader.hasText())
                        {

                            java.lang.String content = reader.getElementText();

                            if (content.indexOf(":") > 0)
                            {
                                // this seems to be a Qname so find the namespace and send
                                prefix = content.substring(0, content.indexOf(":"));
                                namespaceuri = reader.getNamespaceURI(prefix);
                                object = FieldType.Factory.fromString(content, namespaceuri);
                            }
                            else
                            {
                                // this seems to be not a qname send and empty namespace incase of it is
                                // check is done in fromString method
                                object = FieldType.Factory.fromString(content, "");
                            }

                        }
                        else
                        {
                            reader.next();
                        }
                    } // end of while loop

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    public static class CopyResultCollection
                            implements org.apache.axis2.databinding.ADBBean
    {
        /*
         * This type was generated from the piece of schema that had name = CopyResultCollection Namespace URI
         * = http://schemas.microsoft.com/sharepoint/soap/ Namespace Prefix = ns1
         */

        private static java.lang.String generatePrefix(final java.lang.String namespace)
        {
            if (namespace.equals("http://schemas.microsoft.com/sharepoint/soap/"))
            {
                return "ns1";
            }
            return org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
        }

        /**
         * field for CopyResult This was an Array!
         */

        protected CopyResult[] localCopyResult;

        /*
         * This tracker boolean wil be used to detect whether the user called the set method for this
         * attribute. It will be used to determine whether to include this field in the serialized XML
         */
        protected boolean localCopyResultTracker = false;

        /**
         * Auto generated getter method
         * @return CopyResult[]
         */
        public CopyResult[] getCopyResult()
        {
            return localCopyResult;
        }

        /**
         * validate the array for CopyResult
         */
        protected void validateCopyResult(final CopyResult[] param)
        {

        }

        /**
         * Auto generated setter method
         * @param param CopyResult
         */
        public void setCopyResult(final CopyResult[] param)
        {

            validateCopyResult(param);

            if (param != null)
            {
                // update the setting tracker
                localCopyResultTracker = true;
            }
            else
            {
                localCopyResultTracker = true;

            }

            this.localCopyResult = param;
        }

        /**
         * Auto generated add method for the array for convenience
         * @param param CopyResult
         */
        public void addCopyResult(final CopyResult param)
        {
            if (localCopyResult == null)
            {
                localCopyResult = new CopyResult[] {};
            }

            // update the setting tracker
            localCopyResultTracker = true;

            java.util.List list =
                                  org.apache.axis2.databinding.utils.ConverterUtil.toList(localCopyResult);
            list.add(param);
            this.localCopyResult =
                                   (CopyResult[])list.toArray(
                                                           new CopyResult[list.size()]);

        }

        /**
         * isReaderMTOMAware
         * @return true if the reader supports MTOM
         */
        public static boolean isReaderMTOMAware(final javax.xml.stream.XMLStreamReader reader)
        {
            boolean isReaderMTOMAware = false;

            try
            {
                isReaderMTOMAware = java.lang.Boolean.TRUE.equals(reader
                                        .getProperty(org.apache.axiom.om.OMConstants.IS_DATA_HANDLERS_AWARE));
            }
            catch (java.lang.IllegalArgumentException e)
            {
                isReaderMTOMAware = false;
            }
            return isReaderMTOMAware;
        }

        /**
         * @param parentQName
         * @param factory
         * @return org.apache.axiom.om.OMElement
         */
        public org.apache.axiom.om.OMElement getOMElement(
                                                          final javax.xml.namespace.QName parentQName,
                                                          final org.apache.axiom.om.OMFactory factory) throws org.apache.axis2.databinding.ADBException
        {

            org.apache.axiom.om.OMDataSource dataSource =
                                                          new org.apache.axis2.databinding.ADBDataSource(this,
                                                                                                         parentQName)
                                                          {

                                                              public void serialize(final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
                                                              {
                                                                  CopyResultCollection.this
                                                                                          .serialize(parentQName,
                                                                                                     factory,
                                                                                                     xmlWriter);
                                                              }
                                                          };
            return new org.apache.axiom.om.impl.llom.OMSourcedElementImpl(
                                                                          parentQName, factory, dataSource);

        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                                       final org.apache.axiom.om.OMFactory factory,
                                       final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter)
                                                                                                                          throws javax.xml.stream.XMLStreamException,
                                                                                                                          org.apache.axis2.databinding.ADBException
        {
            serialize(parentQName, factory, xmlWriter, false);
        }

        public void serialize(final javax.xml.namespace.QName parentQName,
                               final org.apache.axiom.om.OMFactory factory,
                               final org.apache.axis2.databinding.utils.writer.MTOMAwareXMLStreamWriter xmlWriter,
                               final boolean serializeType)
                                                           throws javax.xml.stream.XMLStreamException,
                                                           org.apache.axis2.databinding.ADBException
        {

            java.lang.String prefix = null;
            java.lang.String namespace = null;

            prefix = parentQName.getPrefix();
            namespace = parentQName.getNamespaceURI();

            if ((namespace != null) && (namespace.trim().length() > 0))
            {
                java.lang.String writerPrefix = xmlWriter.getPrefix(namespace);
                if (writerPrefix != null)
                {
                    xmlWriter.writeStartElement(namespace, parentQName.getLocalPart());
                }
                else
                {
                    if (prefix == null)
                    {
                        prefix = generatePrefix(namespace);
                    }

                    xmlWriter.writeStartElement(prefix, parentQName.getLocalPart(), namespace);
                    xmlWriter.writeNamespace(prefix, namespace);
                    xmlWriter.setPrefix(prefix, namespace);
                }
            }
            else
            {
                xmlWriter.writeStartElement(parentQName.getLocalPart());
            }

            if (serializeType)
            {

                java.lang.String namespacePrefix = registerPrefix(xmlWriter,
                                                                  "http://schemas.microsoft.com/sharepoint/soap/");
                if ((namespacePrefix != null) && (namespacePrefix.trim().length() > 0))
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   namespacePrefix + ":CopyResultCollection",
                                   xmlWriter);
                }
                else
                {
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "type",
                                   "CopyResultCollection",
                                   xmlWriter);
                }

            }
            if (localCopyResultTracker)
            {
                if (localCopyResult != null)
                {
                    for (int i = 0; i < localCopyResult.length; i++)
                    {
                        if (localCopyResult[i] != null)
                        {
                            localCopyResult[i]
                                                    .serialize(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                             "CopyResult"),
                                                               factory,
                                                               xmlWriter);
                        }
                        else
                        {

                            // write null attribute
                            java.lang.String namespace2 = "http://schemas.microsoft.com/sharepoint/soap/";
                            if (!namespace2.equals(""))
                            {
                                java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                                if (prefix2 == null)
                                {
                                    prefix2 = generatePrefix(namespace2);

                                    xmlWriter.writeStartElement(prefix2, "CopyResult", namespace2);
                                    xmlWriter.writeNamespace(prefix2, namespace2);
                                    xmlWriter.setPrefix(prefix2, namespace2);

                                }
                                else
                                {
                                    xmlWriter.writeStartElement(namespace2, "CopyResult");
                                }

                            }
                            else
                            {
                                xmlWriter.writeStartElement("CopyResult");
                            }

                            // write the nil attribute
                            writeAttribute("xsi",
                                           "http://www.w3.org/2001/XMLSchema-instance",
                                           "nil",
                                           "1",
                                           xmlWriter);
                            xmlWriter.writeEndElement();

                        }

                    }
                }
                else
                {

                    // write null attribute
                    java.lang.String namespace2 = "http://schemas.microsoft.com/sharepoint/soap/";
                    if (!namespace2.equals(""))
                    {
                        java.lang.String prefix2 = xmlWriter.getPrefix(namespace2);

                        if (prefix2 == null)
                        {
                            prefix2 = generatePrefix(namespace2);

                            xmlWriter.writeStartElement(prefix2, "CopyResult", namespace2);
                            xmlWriter.writeNamespace(prefix2, namespace2);
                            xmlWriter.setPrefix(prefix2, namespace2);

                        }
                        else
                        {
                            xmlWriter.writeStartElement(namespace2, "CopyResult");
                        }

                    }
                    else
                    {
                        xmlWriter.writeStartElement("CopyResult");
                    }

                    // write the nil attribute
                    writeAttribute("xsi", "http://www.w3.org/2001/XMLSchema-instance", "nil", "1", xmlWriter);
                    xmlWriter.writeEndElement();

                }
            }
            xmlWriter.writeEndElement();

        }

        /**
         * Util method to write an attribute with the ns prefix
         */
        private void writeAttribute(final java.lang.String prefix,
                                    final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (xmlWriter.getPrefix(namespace) == null)
            {
                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);

            }

            xmlWriter.writeAttribute(namespace, attName, attValue);

        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeAttribute(final java.lang.String namespace,
                                    final java.lang.String attName,
                                      final java.lang.String attValue,
                                    final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attValue);
            }
        }

        /**
         * Util method to write an attribute without the ns prefix
         */
        private void writeQNameAttribute(final java.lang.String namespace,
                                         final java.lang.String attName,
                                             final javax.xml.namespace.QName qname,
                                         final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            java.lang.String attributeNamespace = qname.getNamespaceURI();
            java.lang.String attributePrefix = xmlWriter.getPrefix(attributeNamespace);
            if (attributePrefix == null)
            {
                attributePrefix = registerPrefix(xmlWriter, attributeNamespace);
            }
            java.lang.String attributeValue;
            if (attributePrefix.trim().length() > 0)
            {
                attributeValue = attributePrefix + ":" + qname.getLocalPart();
            }
            else
            {
                attributeValue = qname.getLocalPart();
            }

            if (namespace.equals(""))
            {
                xmlWriter.writeAttribute(attName, attributeValue);
            }
            else
            {
                registerPrefix(xmlWriter, namespace);
                xmlWriter.writeAttribute(namespace, attName, attributeValue);
            }
        }

        /**
         * method to handle Qnames
         */

        private void writeQName(final javax.xml.namespace.QName qname,
                                final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String namespaceURI = qname.getNamespaceURI();
            if (namespaceURI != null)
            {
                java.lang.String prefix = xmlWriter.getPrefix(namespaceURI);
                if (prefix == null)
                {
                    prefix = generatePrefix(namespaceURI);
                    xmlWriter.writeNamespace(prefix, namespaceURI);
                    xmlWriter.setPrefix(prefix, namespaceURI);
                }

                if (prefix.trim().length() > 0)
                {
                    xmlWriter.writeCharacters(prefix + ":"
                                              + org.apache.axis2.databinding.utils.ConverterUtil
                                                                      .convertToString(qname));
                }
                else
                {
                    // i.e this is the default namespace
                    xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                            .convertToString(qname));
                }

            }
            else
            {
                xmlWriter.writeCharacters(org.apache.axis2.databinding.utils.ConverterUtil
                                        .convertToString(qname));
            }
        }

        private void writeQNames(final javax.xml.namespace.QName[] qnames,
                                 final javax.xml.stream.XMLStreamWriter xmlWriter) throws javax.xml.stream.XMLStreamException
        {

            if (qnames != null)
            {
                // we have to store this data until last moment since it is not possible to write any
                // namespace data after writing the charactor data
                java.lang.StringBuffer stringToWrite = new java.lang.StringBuffer();
                java.lang.String namespaceURI = null;
                java.lang.String prefix = null;

                for (int i = 0; i < qnames.length; i++)
                {
                    if (i > 0)
                    {
                        stringToWrite.append(" ");
                    }
                    namespaceURI = qnames[i].getNamespaceURI();
                    if (namespaceURI != null)
                    {
                        prefix = xmlWriter.getPrefix(namespaceURI);
                        if ((prefix == null) || (prefix.length() == 0))
                        {
                            prefix = generatePrefix(namespaceURI);
                            xmlWriter.writeNamespace(prefix, namespaceURI);
                            xmlWriter.setPrefix(prefix, namespaceURI);
                        }

                        if (prefix.trim().length() > 0)
                        {
                            stringToWrite.append(prefix)
                                                    .append(":")
                                                    .append(org.apache.axis2.databinding.utils.ConverterUtil
                                                                            .convertToString(qnames[i]));
                        }
                        else
                        {
                            stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                    .convertToString(qnames[i]));
                        }
                    }
                    else
                    {
                        stringToWrite.append(org.apache.axis2.databinding.utils.ConverterUtil
                                                .convertToString(qnames[i]));
                    }
                }
                xmlWriter.writeCharacters(stringToWrite.toString());
            }

        }

        /**
         * Register a namespace prefix
         */
        private java.lang.String registerPrefix(final javax.xml.stream.XMLStreamWriter xmlWriter,
                                                final java.lang.String namespace) throws javax.xml.stream.XMLStreamException
        {
            java.lang.String prefix = xmlWriter.getPrefix(namespace);

            if (prefix == null)
            {
                prefix = generatePrefix(namespace);

                while (xmlWriter.getNamespaceContext().getNamespaceURI(prefix) != null)
                {
                    prefix = org.apache.axis2.databinding.utils.BeanUtil.getUniquePrefix();
                }

                xmlWriter.writeNamespace(prefix, namespace);
                xmlWriter.setPrefix(prefix, namespace);
            }

            return prefix;
        }

        /**
         * databinding method to get an XML representation of this object
         */
        public javax.xml.stream.XMLStreamReader getPullParser(final javax.xml.namespace.QName qName)
                                                                                                    throws org.apache.axis2.databinding.ADBException
        {

            java.util.ArrayList elementList = new java.util.ArrayList();
            java.util.ArrayList attribList = new java.util.ArrayList();

            if (localCopyResultTracker)
            {
                if (localCopyResult != null)
                {
                    for (int i = 0; i < localCopyResult.length; i++)
                    {

                        if (localCopyResult[i] != null)
                        {
                            elementList
                                                    .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                       "CopyResult"));
                            elementList.add(localCopyResult[i]);
                        }
                        else
                        {

                            elementList
                                                    .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                       "CopyResult"));
                            elementList.add(null);

                        }

                    }
                }
                else
                {

                    elementList
                                            .add(new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                               "CopyResult"));
                    elementList.add(localCopyResult);

                }

            }

            return new org.apache.axis2.databinding.utils.reader.ADBXMLStreamReaderImpl(qName,
                                                                                        elementList.toArray(),
                                                                                        attribList.toArray());

        }

        /**
         * Factory class that keeps the parse method
         */
        public static class Factory
        {

            /**
             * static method to create the object Precondition: If this object is an element, the current or
             * next start element starts this object and any intervening reader events are ignorable If this
             * object is not an element, it is a complex type and the reader is at the event just after the
             * outer start element Postcondition: If this object is an element, the reader is positioned at
             * its end element If this object is a complex type, the reader is positioned at the end element
             * of its outer element
             */
            public static CopyResultCollection parse(final javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception
            {
                CopyResultCollection object =
                                              new CopyResultCollection();

                int event;
                java.lang.String nillableValue = null;
                java.lang.String prefix = "";
                java.lang.String namespaceuri = "";
                try
                {

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance", "type") != null)
                    {
                        java.lang.String fullTypeName = reader
                                                .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                   "type");
                        if (fullTypeName != null)
                        {
                            java.lang.String nsPrefix = null;
                            if (fullTypeName.indexOf(":") > -1)
                            {
                                nsPrefix = fullTypeName.substring(0, fullTypeName.indexOf(":"));
                            }
                            nsPrefix = nsPrefix == null ? "" : nsPrefix;

                            java.lang.String type = fullTypeName.substring(fullTypeName.indexOf(":") + 1);

                            if (!"CopyResultCollection".equals(type))
                            {
                                // find namespace for the prefix
                                java.lang.String nsUri = reader.getNamespaceContext()
                                                        .getNamespaceURI(nsPrefix);
                                return (CopyResultCollection)ExtensionMapper.getTypeObject(
                                                                                           nsUri,
                                                                                           type,
                                                                                           reader);
                            }

                        }

                    }

                    // Note all attributes that were handled. Used to differ normal attributes
                    // from anyAttributes.
                    java.util.Vector handledAttributes = new java.util.Vector();

                    reader.next();

                    java.util.ArrayList list1 = new java.util.ArrayList();

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement() && new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                                 "CopyResult").equals(reader
                                                .getName()))
                    {

                        // Process the array and step past its final element's end.

                        nillableValue = reader.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                 "nil");
                        if ("true".equals(nillableValue) || "1".equals(nillableValue))
                        {
                            list1.add(null);
                            reader.next();
                        }
                        else
                        {
                            list1.add(CopyResult.Factory.parse(reader));
                        }
                        // loop until we find a start element that is not part of this array
                        boolean loopDone1 = false;
                        while (!loopDone1)
                        {
                            // We should be at the end element, but make sure
                            while (!reader.isEndElement())
                            {
                                reader.next();
                            }
                            // Step out of this element
                            reader.next();
                            // Step to next element event.
                            while (!reader.isStartElement() && !reader.isEndElement())
                            {
                                reader.next();
                            }
                            if (reader.isEndElement())
                            {
                                // two continuous end elements means we are exiting the xml structure
                                loopDone1 = true;
                            }
                            else
                            {
                                if (new javax.xml.namespace.QName("http://schemas.microsoft.com/sharepoint/soap/",
                                                                  "CopyResult").equals(reader.getName()))
                                {

                                    nillableValue = reader
                                                            .getAttributeValue("http://www.w3.org/2001/XMLSchema-instance",
                                                                               "nil");
                                    if ("true".equals(nillableValue) || "1".equals(nillableValue))
                                    {
                                        list1.add(null);
                                        reader.next();
                                    }
                                    else
                                    {
                                        list1.add(CopyResult.Factory.parse(reader));
                                    }
                                }
                                else
                                {
                                    loopDone1 = true;
                                }
                            }
                        }
                        // call the converter utility to convert and set the array

                        object
                                                .setCopyResult((CopyResult[])
                                                            org.apache.axis2.databinding.utils.ConverterUtil
                                                                                    .convertToArray(
                                                                                                    CopyResult.class,
                                                                                                    list1));

                    } // End of if for expected property start element

                    else
                    {

                    }

                    while (!reader.isStartElement() && !reader.isEndElement())
                    {
                        reader.next();
                    }

                    if (reader.isStartElement())
                    {
                        // A start element we are not expecting indicates a trailing invalid property
                        throw new org.apache.axis2.databinding.ADBException("Unexpected subelement " + reader
                                                                                                    .getLocalName());
                    }

                }
                catch (javax.xml.stream.XMLStreamException e)
                {
                    throw new java.lang.Exception(e);
                }

                return object;
            }

        }// end of factory class

    }

    private org.apache.axiom.om.OMElement toOM(final CopyStub.CopyIntoItemsLocal param,
                                               final boolean optimizeContent)
                                                                             throws org.apache.axis2.AxisFault
    {

        try
        {
            return param.getOMElement(CopyStub.CopyIntoItemsLocal.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        }
        catch (org.apache.axis2.databinding.ADBException e)
        {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

    }

    private org.apache.axiom.om.OMElement toOM(final CopyStub.CopyIntoItemsLocalResponse param,
                                               final boolean optimizeContent)
                                                                             throws org.apache.axis2.AxisFault
    {

        try
        {
            return param.getOMElement(CopyStub.CopyIntoItemsLocalResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        }
        catch (org.apache.axis2.databinding.ADBException e)
        {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

    }

    private org.apache.axiom.om.OMElement toOM(final CopyStub.GetItem param, final boolean optimizeContent)
                                                                                                           throws org.apache.axis2.AxisFault
    {

        try
        {
            return param.getOMElement(CopyStub.GetItem.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        }
        catch (org.apache.axis2.databinding.ADBException e)
        {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

    }

    private org.apache.axiom.om.OMElement toOM(final CopyStub.GetItemResponse param,
                                               final boolean optimizeContent)
                                                                             throws org.apache.axis2.AxisFault
    {

        try
        {
            return param.getOMElement(CopyStub.GetItemResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        }
        catch (org.apache.axis2.databinding.ADBException e)
        {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

    }

    private org.apache.axiom.om.OMElement toOM(final CopyStub.CopyIntoItems param,
                                               final boolean optimizeContent)
                                                                             throws org.apache.axis2.AxisFault
    {

        try
        {
            return param.getOMElement(CopyStub.CopyIntoItems.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        }
        catch (org.apache.axis2.databinding.ADBException e)
        {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

    }

    private org.apache.axiom.om.OMElement toOM(final CopyStub.CopyIntoItemsResponse param,
                                               final boolean optimizeContent)
                                                                             throws org.apache.axis2.AxisFault
    {

        try
        {
            return param.getOMElement(CopyStub.CopyIntoItemsResponse.MY_QNAME,
                                          org.apache.axiom.om.OMAbstractFactory.getOMFactory());
        }
        catch (org.apache.axis2.databinding.ADBException e)
        {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

    }

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(final org.apache.axiom.soap.SOAPFactory factory,
                                                          final CopyStub.CopyIntoItemsLocal param,
                                                          final boolean optimizeContent)
                                                                                        throws org.apache.axis2.AxisFault
    {

        try
        {

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody()
                                    .addChild(param.getOMElement(CopyStub.CopyIntoItemsLocal.MY_QNAME,
                                                                 factory));
            return emptyEnvelope;
        }
        catch (org.apache.axis2.databinding.ADBException e)
        {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

    }

    /* methods to provide back word compatibility */

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(final org.apache.axiom.soap.SOAPFactory factory,
                                                          final CopyStub.GetItem param,
                                                          final boolean optimizeContent)
                                                                                        throws org.apache.axis2.AxisFault
    {

        try
        {

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody().addChild(param.getOMElement(CopyStub.GetItem.MY_QNAME, factory));
            return emptyEnvelope;
        }
        catch (org.apache.axis2.databinding.ADBException e)
        {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

    }

    /* methods to provide back word compatibility */

    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(final org.apache.axiom.soap.SOAPFactory factory,
                                                          final CopyStub.CopyIntoItems param,
                                                          final boolean optimizeContent)
                                                                                        throws org.apache.axis2.AxisFault
    {

        try
        {

            org.apache.axiom.soap.SOAPEnvelope emptyEnvelope = factory.getDefaultEnvelope();
            emptyEnvelope.getBody().addChild(param.getOMElement(CopyStub.CopyIntoItems.MY_QNAME, factory));
            return emptyEnvelope;
        }
        catch (org.apache.axis2.databinding.ADBException e)
        {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }

    }

    /* methods to provide back word compatibility */

    /**
     * get the default envelope
     */
    private org.apache.axiom.soap.SOAPEnvelope toEnvelope(final org.apache.axiom.soap.SOAPFactory factory)
    {
        return factory.getDefaultEnvelope();
    }

    private java.lang.Object fromOM(
                                    final org.apache.axiom.om.OMElement param,
                                    final java.lang.Class type,
                                    final java.util.Map extraNamespaces) throws org.apache.axis2.AxisFault
    {

        try
        {

            if (CopyStub.CopyIntoItemsLocal.class.equals(type))
            {

                return CopyStub.CopyIntoItemsLocal.Factory.parse(param.getXMLStreamReaderWithoutCaching());

            }

            if (CopyStub.CopyIntoItemsLocalResponse.class.equals(type))
            {

                return CopyStub.CopyIntoItemsLocalResponse.Factory.parse(param
                                        .getXMLStreamReaderWithoutCaching());

            }

            if (CopyStub.GetItem.class.equals(type))
            {

                return CopyStub.GetItem.Factory.parse(param.getXMLStreamReaderWithoutCaching());

            }

            if (CopyStub.GetItemResponse.class.equals(type))
            {

                return CopyStub.GetItemResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());

            }

            if (CopyStub.CopyIntoItems.class.equals(type))
            {

                return CopyStub.CopyIntoItems.Factory.parse(param.getXMLStreamReaderWithoutCaching());

            }

            if (CopyStub.CopyIntoItemsResponse.class.equals(type))
            {

                return CopyStub.CopyIntoItemsResponse.Factory.parse(param.getXMLStreamReaderWithoutCaching());

            }

        }
        catch (java.lang.Exception e)
        {
            throw org.apache.axis2.AxisFault.makeFault(e);
        }
        return null;
    }

}
