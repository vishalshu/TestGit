package com.lexisnexis.es.dms.sharepoint.adapter.webservice.data;

import java.text.ParseException;

import javax.xml.stream.XMLStreamException;

import org.apache.axiom.om.OMElement;

@Deprecated
public abstract class DataObject implements DataObjectInterface
{

    public void parse(final String xmlString) throws ParseException, XMLStreamException
    {
        parse(Support.stringToOmElement(xmlString));

    }

    public OMElement getAsOMElement() throws XMLStreamException
    {
        return Support.stringToOmElement(getAsXmlString());
    }

}
