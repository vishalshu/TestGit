/**
 * ListsCallbackHandler.java This file was auto-generated from WSDL by the Apache Axis2 version: 1.5.5 Built
 * on : May 28, 2011 (08:30:56 CEST)
 */

package com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists;


/**
 * ListsCallbackHandler Callback class, Users can extend this class and implement their own receiveResult and
 * receiveError methods.
 */
@Deprecated
public abstract class ListsCallbackHandler
{

    protected Object clientData;

    /**
     * User can pass in any object that needs to be accessed once the NonBlocking Web service call is finished
     * and appropriate method of this CallBack is called.
     * @param clientData Object mechanism by which the user can pass in user data that will be avilable at the
     *            time this callback is called.
     */
    public ListsCallbackHandler(final Object clientData)
    {
        this.clientData = clientData;
    }

    /**
     * Please use this constructor if you don't want to set any clientData
     */
    public ListsCallbackHandler()
    {
        this.clientData = null;
    }

    /**
     * Get the client data
     */

    public Object getClientData()
    {
        return clientData;
    }

    /**
     * auto generated Axis2 call back method for getListItems method override this method for handling normal
     * response from getListItems operation
     */
    public void receiveResultgetListItems(
                                          final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListItemsResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from getListItems
     * operation
     */
    public void receiveErrorgetListItems(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for deleteAttachment method override this method for handling
     * normal response from deleteAttachment operation
     */
    public void receiveResultdeleteAttachment(
                                              final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.DeleteAttachmentResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * deleteAttachment operation
     */
    public void receiveErrordeleteAttachment(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for updateContentTypeXmlDocument method override this method for
     * handling normal response from updateContentTypeXmlDocument operation
     */
    public void receiveResultupdateContentTypeXmlDocument(
                                                          final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.UpdateContentTypeXmlDocumentResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * updateContentTypeXmlDocument operation
     */
    public void receiveErrorupdateContentTypeXmlDocument(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for deleteContentTypeXmlDocument method override this method for
     * handling normal response from deleteContentTypeXmlDocument operation
     */
    public void receiveResultdeleteContentTypeXmlDocument(
                                                          final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.DeleteContentTypeXmlDocumentResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * deleteContentTypeXmlDocument operation
     */
    public void receiveErrordeleteContentTypeXmlDocument(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for addAttachment method override this method for handling normal
     * response from addAttachment operation
     */
    public void receiveResultaddAttachment(
                                           final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.AddAttachmentResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from addAttachment
     * operation
     */
    public void receiveErroraddAttachment(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for getListItemChanges method override this method for handling
     * normal response from getListItemChanges operation
     */
    public void receiveResultgetListItemChanges(
                                                final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListItemChangesResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * getListItemChanges operation
     */
    public void receiveErrorgetListItemChanges(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for getListItemChangesWithKnowledge method override this method
     * for handling normal response from getListItemChangesWithKnowledge operation
     */
    public void receiveResultgetListItemChangesWithKnowledge(
                                                             final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListItemChangesWithKnowledgeResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * getListItemChangesWithKnowledge operation
     */
    public void receiveErrorgetListItemChangesWithKnowledge(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for undoCheckOut method override this method for handling normal
     * response from undoCheckOut operation
     */
    public void receiveResultundoCheckOut(
                                          final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.UndoCheckOutResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from undoCheckOut
     * operation
     */
    public void receiveErrorundoCheckOut(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for getVersionCollection method override this method for handling
     * normal response from getVersionCollection operation
     */
    public void receiveResultgetVersionCollection(
                                                  final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetVersionCollectionResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * getVersionCollection operation
     */
    public void receiveErrorgetVersionCollection(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for updateListItemsWithKnowledge method override this method for
     * handling normal response from updateListItemsWithKnowledge operation
     */
    public void receiveResultupdateListItemsWithKnowledge(
                                                          final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.UpdateListItemsWithKnowledgeResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * updateListItemsWithKnowledge operation
     */
    public void receiveErrorupdateListItemsWithKnowledge(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for addDiscussionBoardItem method override this method for
     * handling normal response from addDiscussionBoardItem operation
     */
    public void receiveResultaddDiscussionBoardItem(
                                                    final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.AddDiscussionBoardItemResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * addDiscussionBoardItem operation
     */
    public void receiveErroraddDiscussionBoardItem(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for checkInFile method override this method for handling normal
     * response from checkInFile operation
     */
    public void receiveResultcheckInFile(
                                         final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.CheckInFileResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from checkInFile
     * operation
     */
    public void receiveErrorcheckInFile(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for addWikiPage method override this method for handling normal
     * response from addWikiPage operation
     */
    public void receiveResultaddWikiPage(
                                         final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.AddWikiPageResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from addWikiPage
     * operation
     */
    public void receiveErroraddWikiPage(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for deleteList method override this method for handling normal
     * response from deleteList operation
     */
    public void receiveResultdeleteList(
                                        final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.DeleteListResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from deleteList
     * operation
     */
    public void receiveErrordeleteList(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for createContentType method override this method for handling
     * normal response from createContentType operation
     */
    public void receiveResultcreateContentType(
                                               final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.CreateContentTypeResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * createContentType operation
     */
    public void receiveErrorcreateContentType(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for getListCollection method override this method for handling
     * normal response from getListCollection operation
     */
    public void receiveResultgetListCollection(
                                               final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListCollectionResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * getListCollection operation
     */
    public void receiveErrorgetListCollection(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for updateContentType method override this method for handling
     * normal response from updateContentType operation
     */
    public void receiveResultupdateContentType(
                                               final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.UpdateContentTypeResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * updateContentType operation
     */
    public void receiveErrorupdateContentType(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for getListContentType method override this method for handling
     * normal response from getListContentType operation
     */
    public void receiveResultgetListContentType(
                                                final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListContentTypeResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * getListContentType operation
     */
    public void receiveErrorgetListContentType(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for checkOutFile method override this method for handling normal
     * response from checkOutFile operation
     */
    public void receiveResultcheckOutFile(
                                          final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.CheckOutFileResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from checkOutFile
     * operation
     */
    public void receiveErrorcheckOutFile(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for addList method override this method for handling normal
     * response from addList operation
     */
    public void receiveResultaddList(
                                     final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.AddListResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from addList
     * operation
     */
    public void receiveErroraddList(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for deleteContentType method override this method for handling
     * normal response from deleteContentType operation
     */
    public void receiveResultdeleteContentType(
                                               final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.DeleteContentTypeResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * deleteContentType operation
     */
    public void receiveErrordeleteContentType(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for getListContentTypesAndProperties method override this method
     * for handling normal response from getListContentTypesAndProperties operation
     */
    public void receiveResultgetListContentTypesAndProperties(
                                                              final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListContentTypesAndPropertiesResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * getListContentTypesAndProperties operation
     */
    public void receiveErrorgetListContentTypesAndProperties(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for addListFromFeature method override this method for handling
     * normal response from addListFromFeature operation
     */
    public void receiveResultaddListFromFeature(
                                                final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.AddListFromFeatureResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * addListFromFeature operation
     */
    public void receiveErroraddListFromFeature(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for getAttachmentCollection method override this method for
     * handling normal response from getAttachmentCollection operation
     */
    public void receiveResultgetAttachmentCollection(
                                                     final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetAttachmentCollectionResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * getAttachmentCollection operation
     */
    public void receiveErrorgetAttachmentCollection(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for updateListItems method override this method for handling
     * normal response from updateListItems operation
     */
    public void receiveResultupdateListItems(
                                             final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.UpdateListItemsResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * updateListItems operation
     */
    public void receiveErrorupdateListItems(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for getListItemChangesSinceToken method override this method for
     * handling normal response from getListItemChangesSinceToken operation
     */
    public void receiveResultgetListItemChangesSinceToken(
                                                          final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListItemChangesSinceTokenResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * getListItemChangesSinceToken operation
     */
    public void receiveErrorgetListItemChangesSinceToken(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for applyContentTypeToList method override this method for
     * handling normal response from applyContentTypeToList operation
     */
    public void receiveResultapplyContentTypeToList(
                                                    final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.ApplyContentTypeToListResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * applyContentTypeToList operation
     */
    public void receiveErrorapplyContentTypeToList(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for getListAndView method override this method for handling
     * normal response from getListAndView operation
     */
    public void receiveResultgetListAndView(
                                            final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListAndViewResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from getListAndView
     * operation
     */
    public void receiveErrorgetListAndView(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for getList method override this method for handling normal
     * response from getList operation
     */
    public void receiveResultgetList(
                                     final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from getList
     * operation
     */
    public void receiveErrorgetList(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for updateList method override this method for handling normal
     * response from updateList operation
     */
    public void receiveResultupdateList(
                                        final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.UpdateListResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from updateList
     * operation
     */
    public void receiveErrorupdateList(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for getListContentTypes method override this method for handling
     * normal response from getListContentTypes operation
     */
    public void receiveResultgetListContentTypes(
                                                 final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.GetListContentTypesResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * getListContentTypes operation
     */
    public void receiveErrorgetListContentTypes(final java.lang.Exception e)
    {
    }

    /**
     * auto generated Axis2 call back method for updateContentTypesXmlDocument method override this method for
     * handling normal response from updateContentTypesXmlDocument operation
     */
    public void receiveResultupdateContentTypesXmlDocument(
                                                           final com.lexisnexis.es.dms.sharepoint.adapter.webservice.lists.ListsStub.UpdateContentTypesXmlDocumentResponse result)
    {
    }

    /**
     * auto generated Axis2 Error handler override this method for handling error response from
     * updateContentTypesXmlDocument operation
     */
    public void receiveErrorupdateContentTypesXmlDocument(final java.lang.Exception e)
    {
    }

}
