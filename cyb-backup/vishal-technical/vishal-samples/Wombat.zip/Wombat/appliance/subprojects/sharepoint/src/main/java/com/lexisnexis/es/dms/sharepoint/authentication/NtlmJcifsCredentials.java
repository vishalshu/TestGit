package com.lexisnexis.es.dms.sharepoint.authentication;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.commons.httpclient.Credentials;
import org.apache.commons.httpclient.NTCredentials;
import org.apache.commons.httpclient.auth.AuthPolicy;
import org.apache.commons.httpclient.auth.AuthScheme;
import org.apache.commons.httpclient.auth.CredentialsNotAvailableException;
import org.apache.commons.httpclient.auth.CredentialsProvider;
import org.apache.commons.httpclient.params.DefaultHttpParams;
import org.apache.commons.httpclient.params.DefaultHttpParamsFactory;
import org.apache.commons.httpclient.params.HttpParams;

/**
 * registers NTLM authentication for apache axis
 */
public class NtlmJcifsCredentials
{
    /**
     * C'tor which takes only password
     * @param password
     */
    public static void register(final String password)
    {
        final String username = System.getProperty("user.name");
        final String computername = System.getenv("COMPUTERNAME");
        final String userDomain = System.getenv("USERDOMAIN");
        register(username, password, computername, userDomain);
    }

    /**
     * C'tor which takes Username, Password, Domain
     * @param username
     * @param password
     * @param userDomain
     */
    public static void register(final String username, final String password, final String userDomain)
    {
        // final String computername = System.getenv("COMPUTERNAME");
        String computername = "";
        try
        {
            computername = InetAddress.getLocalHost().getHostName();
        }
        catch (UnknownHostException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        register(username, password, computername, userDomain);
    }

    /**
     * C'tor which takes Username, password, conputername and domain
     * @param username
     * @param password
     * @param computername
     * @param domain
     */
    public static void register(final String username,
                                final String password,
                                final String computername,
                                final String domain)
    {
        final NTCredentials ntCred = new NTCredentials(username, password, computername, domain);

        final CredentialsProvider ntlmCredProvider = new CredentialsProvider()
        {
            @Override
            public Credentials getCredentials(final AuthScheme scheme,
                                              final String host,
                                              final int port,
                                              final boolean proxy)
                                                                  throws CredentialsNotAvailableException
            {
                return ntCred;
            }
        };
        final DefaultHttpParamsFactory paramFact =
                                                   new DefaultHttpParamsFactory()
        {
            @Override
            protected HttpParams createParams()
            {
                HttpParams htp = super.createParams();
                htp.setParameter(
                                 CredentialsProvider.PROVIDER,
                                 ntlmCredProvider);
                return htp;
            }
        };
        DefaultHttpParams.setHttpParamsFactory(paramFact);

        // we want all our jcifs encoding to be ascii
        jcifs.Config.setProperty("jcifs.encoding", "ASCII");

        // our jcifs implemented NTLM is required for MDW's authentication
        AuthPolicy.registerAuthScheme(AuthPolicy.NTLM, JcifsNtlmScheme.class);
    }
}