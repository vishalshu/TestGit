/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.sharepoint.authentication;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.chemistry.opencmis.client.bindings.spi.AbstractAuthenticationProvider;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author kalej
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */
public class SAMLAuthenticationProvider extends AbstractAuthenticationProvider
{
    /**  */
    private static final long serialVersionUID = 1L;

    private static final String WSSE_NAMESPACE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";

    private static final String WSU_NAMESPACE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd";

    Properties prop = new Properties();

    @Override
    public Map<String, List<String>> getHTTPHeaders(final String url)
    {
        String credentials = "";

        try
        {
            prop.load(Thread.currentThread().getContextClassLoader()
                                    .getResourceAsStream("credentials.properties"));
            credentials = prop.getProperty("cred");
        }
        catch (FileNotFoundException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        Map<String, List<String>> result = null;

        result = new HashMap<String, List<String>>();
        result.put("Authorization", Collections.singletonList("Negotiate " + credentials));
        result.put("Expect", Collections.singletonList("100-continue"));
        return result;
    }
}
