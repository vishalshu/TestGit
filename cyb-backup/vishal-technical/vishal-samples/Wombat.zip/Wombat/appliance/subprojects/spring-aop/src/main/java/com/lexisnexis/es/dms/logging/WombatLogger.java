/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */
package com.lexisnexis.es.dms.logging;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.util.StopWatch;

/**
 * Defining Spring Aspect and Advice to intercept method calls for logging <br/>
 * <hr/>
 * @author KaleJ
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */
@Aspect
public class WombatLogger
{
    /**
     * Defining the pointcut to intercept methods which match the pattern
     */
    @Pointcut("execution(* com.lexisnexis.es.dms.sharepoint.adapter.webservice.actions.SharepointCreateDocument.execute(..))")
    public void accessedPublicMethod()
    {
        // Defined pointcut
    }

    /**
     * Defining the Advice
     * @param joinPoint
     * @throws Throwable
     */
    @Around("accessedPublicMethod()")
    public Object logPublicMethod(final ProceedingJoinPoint joinPoint) throws Throwable
    {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();

        Object result = joinPoint.proceed();

        stopWatch.stop();

        StringBuffer logMessageStringBuffer = new StringBuffer();
        logMessageStringBuffer.append(joinPoint.getTarget().getClass().getName());
        logMessageStringBuffer.append(".");
        logMessageStringBuffer.append(joinPoint.getSignature().getName());
        logMessageStringBuffer.append("(");
        logMessageStringBuffer.append(joinPoint.getArgs());
        logMessageStringBuffer.append(")");
        logMessageStringBuffer.append(" execution time: ");
        logMessageStringBuffer.append(stopWatch.getTotalTimeMillis());
        logMessageStringBuffer.append(" ms");

        // Logger.getLogger(this.getClass()).info(logMessageStringBuffer.toString());

        System.out.println(logMessageStringBuffer);

        return result;
    }

}
