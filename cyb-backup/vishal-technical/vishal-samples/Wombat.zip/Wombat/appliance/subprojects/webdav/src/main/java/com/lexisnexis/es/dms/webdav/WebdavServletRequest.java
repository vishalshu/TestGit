/**
 * 
 */
package com.lexisnexis.es.dms.webdav;

import javax.servlet.http.HttpServletRequest;

import com.lexisnexis.es.dms.core.transaction.DocumentInfoFactory;

/**
 * All webdav requests will implement this interface.
 * @author vishalshu
 */
public interface WebdavServletRequest extends HttpServletRequest
{
    /**
     * @return DocumentInfoFactory which is responsible for creating DocumentInfo concrete objects
     */
    DocumentInfoFactory getDocumentInfoFactory();
}
