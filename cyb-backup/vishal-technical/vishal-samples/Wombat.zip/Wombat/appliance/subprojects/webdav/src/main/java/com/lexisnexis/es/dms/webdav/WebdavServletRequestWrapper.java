/**
 * 
 */
package com.lexisnexis.es.dms.webdav;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.lexisnexis.es.dms.core.service.RepositoryObjectLocationImpl;
import com.lexisnexis.es.dms.core.transaction.DocumentDTO;
import com.lexisnexis.es.dms.core.transaction.DocumentInfo;
import com.lexisnexis.es.dms.webdav.util.URLDocumentData;
import com.lexisnexis.es.dms.webdav.util.URLDocumentDataFactory;
import com.lexisnexis.es.dms.webdav.util.URLFolderData;
import com.lexisnexis.es.dms.webdav.util.URLFolderDataFactory;

/**
 * Wraps all the webdav requests. Provides template method for populating DocumentInfo properties.
 * @author vishalshu
 */
public abstract class WebdavServletRequestWrapper
{

    /**
     * Call-back method to be implemented by adapters to perform any name-space specific logic.
     * @param urlDocumentData encapsulates the info encoded in the url
     */
    protected abstract void processUrlData(final URLFolderData urlDocumentData);

    /**
     * populates properties of DocumentInfo interface.
     * @param request the current request
     * @throws IOException
     */
    protected void populateDocumentInfo(final HttpServletRequest request) throws IOException
    {
        DocumentDTO documentInfo = getDocumentInfo();
        URLDocumentDataFactory urlDocumentDataFactory = new URLDocumentDataFactory();
        URLDocumentData urlDocumentData = urlDocumentDataFactory.createUrlDocumentData(request
                                .getRequestURI());
        documentInfo.setContent(request.getInputStream());
        documentInfo.setDocumentFileName(urlDocumentData.getFilename());
        documentInfo.setLocation(new RepositoryObjectLocationImpl(urlDocumentData.getLogicalPath()));
        processUrlData(urlDocumentData);
        documentInfo.setMimeType(request.getContentType());
        // TODO: set major version?

    }

    /**
     * populates properties of DocumentInfo interface for a folder reference (i.e. when we do not have a
     * document name).
     * @param request the current request
     * @throws IOException
     */
    protected void populateFolderInfo(final HttpServletRequest request) throws IOException
    {
        DocumentDTO documentInfo = getDocumentInfo();
        URLFolderDataFactory urlFolderDataFactory = new URLFolderDataFactory();
        URLFolderData urlFolderData = urlFolderDataFactory.createUrlFolderData(request
                                .getRequestURI());
        documentInfo.setContent(request.getInputStream());
        documentInfo.setLocation(new RepositoryObjectLocationImpl(urlFolderData.getLogicalPath()));
        processUrlData(urlFolderData);

    }

    /**
     * Retrieves the {@link DocumentInfo} object based on the 'namespace' in the URL
     * @return Document Info
     */
    protected abstract DocumentDTO getDocumentInfo();
}
