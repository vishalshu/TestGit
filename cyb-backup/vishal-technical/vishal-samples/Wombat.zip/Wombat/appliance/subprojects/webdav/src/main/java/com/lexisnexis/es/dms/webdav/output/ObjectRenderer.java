/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.output;

import java.util.List;

import com.lexisnexis.es.dms.core.transaction.RepositoryObject;

/**
 * Renders repository objects in a form suitable for use by a client <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public interface ObjectRenderer
{
    /**
     * @param resultObjects the objects to render
     * @return a string representing the objects
     */
    public String renderObjects(List<RepositoryObject> resultObjects);

    /**
     * @param folderName the name of the containing folder
     * @param childObjects the children of the parent
     * @return a string representing the objects
     */
    public String renderObjects(String folderName, List<RepositoryObject> childObjects);
}
