/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.output;

import java.util.List;

import com.lexisnexis.es.dms.core.transaction.DocumentRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.FolderRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RepositoryObject;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class XMLObjectRenderer implements ObjectRenderer
{

    /**
     * {@inheritDoc}
     */
    @Override
    public String renderObjects(final String parentName,
                                final List<RepositoryObject> childObjects)
    {
        StringBuilder sb = new StringBuilder();
        sb.append(getStartElement("folder"));
        appendAttributeText(sb, "name", parentName);
        sb.append("> ");
        sb.append(renderObjects(childObjects));
        sb.append("</folder>");
        return sb.toString();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String renderObjects(final List<RepositoryObject> resultObjects)
    {
        StringBuilder sb = new StringBuilder();
        if (resultObjects != null)
        {
            for (RepositoryObject contentObject : resultObjects)
            {
                if (contentObject instanceof DocumentRepositoryObject)
                {
                    renderObject(sb, (DocumentRepositoryObject)contentObject);
                }
                else if (contentObject instanceof FolderRepositoryObject)
                {
                    renderObject(sb, (FolderRepositoryObject)contentObject);
                }
                else
                {
                    throw new IllegalArgumentException("Unrecognised object:" + contentObject.getClass()
                                                                               .getName());
                }
            }
        }
        return sb.toString();
    }

    /**
     * render the repository object as a string in the supplied stringbuilder
     * @param sb the builder where the rendering will be stored
     * @param resultObject the object to render
     */
    private void renderObject(final StringBuilder sb, final DocumentRepositoryObject resultObject)
    {
        sb.append(getStartElement("file"));
        appendAttributeText(sb, "name", resultObject.getDocumentFileName());
        appendAttributeText(sb, "id", resultObject.getId());
        // TODO more attributes (metadata?)
        sb.append(getEndElement());
    }

    /**
     * render the repository object as a string in the supplied stringbuilder
     * @param sb the builder where the rendering will be stored
     * @param resultObject the object to render
     */
    private void renderObject(final StringBuilder sb, final FolderRepositoryObject resultObject)
    {
        sb.append(getStartElement("folder"));
        appendAttributeText(sb, "name", resultObject.getName());
        sb.append(getEndElement());

    }

    /**
     * returns the initial part of an element e.g "<my_element "
     * @param tagName the name of the element
     * @return the start of the element
     */
    private String getStartElement(final String tagName)
    {
        return "<" + tagName;
    }

    /**
     * returns the final part of an element e.g "> "
     * @return the end of the element
     */
    private String getEndElement()
    {
        return "/> ";
    }

    /**
     * adds the text for an attribute to the supplied StringBuilder
     * @param builder
     * @param attName
     * @param attValue
     */
    private void appendAttributeText(final StringBuilder builder, final String attName, final String attValue)
    {
        builder.append(" ");
        builder.append(attName);
        builder.append("=");
        builder.append("'");
        builder.append(attValue);
        builder.append("'");
    }
}
