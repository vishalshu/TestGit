/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.util;

/**
 * Class that holds document information. This document information is populated from url<br/>
 * <br/>
 * <hr/>
 * @author maheshy
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class URLDocumentData extends URLFolderData
{
    /** file name from the url */
    private String filename;

    /**
     * @return the filename
     */
    public String getFilename()
    {
        return filename;
    }

    /**
     * @param filename the filename to set
     */
    public void setFilename(final String filename)
    {
        this.filename = filename;
    }

    /**
     * @return true since this is a document
     */
    @Override
    public boolean hasFileName()
    {
        return true;
    }
}
