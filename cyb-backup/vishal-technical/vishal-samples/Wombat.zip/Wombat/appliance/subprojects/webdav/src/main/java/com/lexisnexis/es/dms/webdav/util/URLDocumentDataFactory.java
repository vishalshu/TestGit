/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.util;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * The class which is gateway to get document data information from the url. <br/>
 * <br/>
 * <hr/>
 * @author maheshy
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class URLDocumentDataFactory
{
    /** URL document data which contains all document related information */
    private final URLDocumentData urlDocumentData = new URLDocumentData();;

    /**
     * This method is responsible for creating document data from the url passed.
     * @param url
     * @return document data from url.
     */
    public URLDocumentData createUrlDocumentData(final String url)
    {
        URL aURL = null;
        try
        {
            aURL = new URL(url);
            parseUrlMetadata(aURL.getPath().substring(1));
        }
        catch (MalformedURLException e)
        {
            // not a full url
            parseUrlMetadata(url);
        }

        return urlDocumentData;

    }

    /**
     * This method will parse the path passed to fetch file name and location of document
     * @param path
     */
    private void parseUrlMetadata(final String path)
    {
        String[] urlTokens = path.split("/");
        urlDocumentData.setUrlTokens(urlTokens);
        StringBuilder documentLocation = new StringBuilder();
        int tokenCount = 0;
        for (String token : urlTokens)
        {
            // This check for file name.
            if (tokenCount == (urlTokens.length - 1))
            {
                urlDocumentData.setFilename(token);
                break;
            }
            if (tokenCount != 0)
            {
                documentLocation.append(token);
                // This check is done to avoid forward slash at the end of document location.
                if (tokenCount != (urlTokens.length - 2))
                {
                    documentLocation.append("/");
                }

            }
            tokenCount++;
        }
        urlDocumentData.setPath(documentLocation.toString());

    }
}
