/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Extracted superclass from URLDocumentData so we can have specific handling of Folders. <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */
public class URLFolderData
{

    /** path of url */
    private String path;

    /** This map will contains optional parameters like work flow code and others mentioned in url */
    private Map<String, String> parameterMap;

    /** tokens extracted from url */
    private String[] urlTokens;

    /** tokens extracted from url AFTER the annotated tokens. i.e the right hand end of the url */
    private List<String> additionalTokens;

    /** tokens extracted from url BEFORE the annotated tokens. i.e the left hand end of the url */
    private List<String> precedingTokens;

    /** tokens extracted from url */
    private Map<String, String> annotatedTokens;

    /**
     * 
     */
    public URLFolderData()
    {
        super();
    }

    /**
     * @return the path
     */
    public String getPath()
    {
        return path;
    }

    /**
     * returns the LOGICAL path. The logical path may not be in the same order as the supplied path, as it
     * will always obey the department/client/file/workflow hierarchy. The logical does not path includes any
     * file name, if it exists. The elements of the path will have been decoded (so it will have ' ' instead
     * of '%20'). the logical path does NOT include any part of the path prior to the annotated values (so
     * long as there are some annotated values) .<br>
     * e.g. if the original incoming URL was <br>
     * 
     * <pre>
     *     http://wombat:8080/lndms/client/dept_Human%20Resources/c_00000001/f_00000002/Personal/test.doc <br>
     * </pre>
     * 
     * then the logical path will be<br>
     * 
     * <pre>
     *     dept_Human Resources/c_00000001/f_00000002/Personal <br>
     * </pre>
     * @return the logical path
     */
    public String getLogicalPath()
    {
        StringBuilder logicalPath = new StringBuilder();
        addPathPart(logicalPath, getDepartmentPathPart());
        addPathPart(logicalPath, getEntityCodePathPart());
        addPathPart(logicalPath, getClientCodePathPart());
        addPathPart(logicalPath, getMatterCodePathPart());
        addPathPart(logicalPath, getWorkflowCodePathPart());
        int numTokensToGet = additionalTokens.size();
        if (hasFileName())
        {
            numTokensToGet--;
        }
        for (int i = 0; i < numTokensToGet; i++)
        {
            String token = additionalTokens.get(i);
            addPathPart(logicalPath, token);
        }
        if (logicalPath.length() == 0)
        {
            // no annotation, just go with whatever they sent
            numTokensToGet = precedingTokens.size();
            if (hasFileName())
            {
                numTokensToGet--;
            }
            for (int i = 0; i < numTokensToGet; i++)
            {
                String token = precedingTokens.get(i);
                addPathPart(logicalPath, token);
            }
        }
        return logicalPath.toString();
    }

    /**
     * Adds a bit to the string representiong the path of the doc
     * @param logicalPath the current path
     * @param pathPart the bit to add
     */
    private void addPathPart(final StringBuilder logicalPath, final String pathPart)
    {
        if (logicalPath != null && pathPart != null && pathPart.trim().length() > 0)
        {
            if (logicalPath.length() > 0)
            {
                logicalPath.append("/");
            }
            logicalPath.append(pathPart);
        }
    }

    /**
     * @param path the path to set
     */
    public void setPath(final String path)
    {
        this.path = path;
    }

    /**
     * @return the query
     */
    public Map<String, String> getQuery()
    {
        return parameterMap;
    }

    /**
     * @param query the query to set
     */
    public void setQuery(final Map<String, String> query)
    {
        // this.query = query;
    }

    /**
     * @param urlTokens the urlTokens to set
     */
    public void setUrlTokens(final String[] urlTokens)
    {
        this.urlTokens = urlTokens;
        parseAnnotations(this.urlTokens);
    }

    /**
     * @return the urlTokens
     */
    public String[] getUrlTokens()
    {
        return urlTokens;
    }

    /**
     * Scan through the array of tokens and parse out any annotated tokens into a separate map. Any existing
     * map will be discarded and a new map created from the supplied array.
     * @param tokens the tokens from the URL
     */
    private void parseAnnotations(final String[] tokens)
    {
        annotatedTokens = new HashMap<String, String>();
        additionalTokens = new ArrayList<String>();
        precedingTokens = new ArrayList<String>();
        if (tokens != null)
        {
            for (String token : tokens)
            {
                boolean annotationSaved = saveAnnotation(token, annotatedTokens);
                if (!annotationSaved)
                {
                    if (annotatedTokens.size() > 0)
                    {
                        // we have found an unannotated token after some annotated tokens,
                        // probably a sub folder
                        additionalTokens.add(decode(token));
                    }
                    else
                    {
                        // we haven't found any annotated tokens yet
                        precedingTokens.add(decode(token));
                    }
                }
            }
        }
    }

    /**
     * reassembles an annotation and associated value
     * @param annotationAndValue the annotation and value from the url
     * @return the decoded and reassembled annotation and value
     */
    private String reassemblePathPart(final List<String> annotationAndValue)
    {
        String retval = null;
        if (annotationAndValue != null && annotationAndValue.size() == 2)
        {
            retval = annotationAndValue.get(0) + getSeparator() + annotationAndValue.get(1);
        }
        return retval;
    }

    /**
     * Checks the map of annotated url values for the client code
     * @return the client code (may be null)
     */
    public String getClientCode()
    {
        String clientCode = getAnnotatedValue(getClientCodeAnnotations());
        if (clientCode == null && (annotatedTokens == null || annotatedTokens.size() == 0))
        {
            // TODO - for testing only, remove soon - without annotations this will go wrong!
            if (urlTokens != null)
            {
                // look for the "client" routing, assume token after that is client code
                for (int i = 0; i < urlTokens.length; i++)
                {
                    if ("client".equals(urlTokens[i]))
                    {
                        if (i + 1 < urlTokens.length)
                        {
                            clientCode = urlTokens[i + 1];
                        }
                        break;
                    }
                }
            }
        }
        return clientCode;
    }

    /**
     * Checks the map of annotated url values for the client code
     * @return the client code path part(may be null)
     */
    public String getClientCodePathPart()
    {
        return reassemblePathPart(getAnnotationAndValue(getClientCodeAnnotations()));
    }

    /**
     * Checks the map of annotated url values for the matter code
     * @return the matter code (may be null)
     */
    public String getMatterCode()
    {
        String matterCode = getAnnotatedValue(getMatterCodeAnnotations());
        if (matterCode == null && (annotatedTokens == null || annotatedTokens.size() == 0))
        {
            // TODO - for testing only, remove soon - without annotations this will go wrong!
            if (urlTokens != null)
            {
                // look for the "client" routing, assume 2nd token after that is matter code
                for (int i = 0; i < urlTokens.length; i++)
                {
                    if ("client".equals(urlTokens[i]))
                    {
                        if (i + 2 < urlTokens.length)
                        {
                            matterCode = urlTokens[i + 2];
                        }
                        break;
                    }
                }
            }
        }
        return matterCode;
    }

    /**
     * Checks the map of annotated url values for the matter code
     * @return the matter code Path Part(may be null)
     */
    public String getMatterCodePathPart()
    {
        return reassemblePathPart(getAnnotationAndValue(getMatterCodeAnnotations()));
    }

    /**
     * Checks the map of annotated url values for the entity code
     * @return the entity code (may be null)
     */
    public String getEntityCode()
    {
        return getAnnotatedValue(getEntityCodeAnnotations());
    }

    /**
     * Checks the map of annotated url values for the entity code
     * @return the entity code Path Part(may be null)
     */
    public String getEntityCodePathPart()
    {
        return reassemblePathPart(getAnnotationAndValue(getEntityCodeAnnotations()));
    }

    /**
     * Checks the map of annotated url values for the workflow code
     * @return the workflow code (may be null)
     */
    public String getWorkflowCode()
    {
        return getAnnotatedValue(getWorkflowCodeAnnotations());
    }

    /**
     * Checks the map of annotated url values for the workflow code
     * @return the workflow code Path Part (may be null)
     */
    public String getWorkflowCodePathPart()
    {
        return reassemblePathPart(getAnnotationAndValue(getWorkflowCodeAnnotations()));
    }

    /**
     * Checks the map of annotated url values for the department
     * @return the department (may be null)
     */
    public String getDepartment()
    {
        return getAnnotatedValue(getDepartmentAnnotations());
    }

    /**
     * Checks the map of annotated url values for the department
     * @return the department Path Part(may be null)
     */
    public String getDepartmentPathPart()
    {
        return reassemblePathPart(getAnnotationAndValue(getDepartmentAnnotations()));
    }

    /**
     * Takes the supplied list of annotations and treats them as potential keys for the annotated tokens map.
     * The first non-null value it finds is returned. This only makes sense if a particular type of data is
     * being looked for and that all the annotations in the supplied list are synonyms. <br>
     * e.g. the supplied list might be 'f','file','m','matter' which are all different ways of annotating the
     * same thing - a file code.
     * @param annotations the list of synonym annotations for the particular data you require
     * @return the first 'hit' from the list of potential keys
     */
    protected String getAnnotatedValue(final List<String> annotations)
    {
        List<String> annotationAndValue = getAnnotationAndValue(annotations);
        String value = null;
        if (annotationAndValue != null)
        {
            value = annotationAndValue.get(1);
        }
        return value;
    }

    /**
     * Takes the supplied list of annotations and treats them as potential keys for the annotated tokens map.
     * The first non-null value it finds is returned, together with its annotation. This only makes sense if a
     * particular type of data is being looked for and that all the annotations in the supplied list are
     * synonyms. <br>
     * e.g. the supplied list might be 'f','file','m','matter' which are all different ways of annotating the
     * same thing - a file code.
     * @param annotations the list of synonym annotations for the particular data you require
     * @return the first 'hit' from the list of potential keys as List. the first item is the annotation, the
     *         second item is the value
     */
    protected List<String> getAnnotationAndValue(final List<String> annotations)
    {
        List<String> values = null;
        if (annotatedTokens != null && annotations != null)
        {
            for (String annotation : annotations)
            {
                String value = annotatedTokens.get(annotation);
                if (value != null)
                {
                    values = new ArrayList<String>();
                    values.add(annotation);
                    values.add(value);
                }
            }
        }
        return values;
    }

    /**
     * Takes the supplied url token and checks it for recognised annotations. If there is a recognised
     * annotation and separator then the the annotation and token value will be stored in the supplied map.
     * @param token the token to check
     * @param annotationMap the map to store the annotations and values in
     * @return true if annotation was found and saved
     */
    private boolean saveAnnotation(final String token, final Map<String, String> annotationMap)
    {
        boolean saved = false;
        if (token != null)
        {
            String annotation = getAnnotation(token);
            if (annotation != null && annotation.trim().length() > 0)
            {
                int valueIndex = annotation.length() + getSeparator().length();
                String value = token.substring(valueIndex);
                annotationMap.put(annotation.trim(), decode(value));
                saved = true;
            }
        }
        return saved;
    }

    /**
     * Examines the supplied token to see whether it has a recognised annotation followed by the separator.
     * @param token the String which may contain an annotated value
     * @return the annotation embedded within the token
     */
    private String getAnnotation(final String token)
    {
        // if the token starts with a recognised annotation followed by the specified separator, then we treat
        // it as an annotation
        List<String> validAnnotations = getCurrentAnnotations();
        String currentSeparator = getSeparator();
        int sepIndex = token.indexOf(currentSeparator);
        if (sepIndex > 0)
        {
            String potentialAnnotation = token.substring(0, sepIndex);
            if (validAnnotations.contains(potentialAnnotation))
            {
                return potentialAnnotation;
            }
        }
        return null;
    }

    /**
     * @return the separator used between annotations and data in a token
     */
    private String getSeparator()
    {
        // TODO currently hard-coded
        return "_";
    }

    /**
     * @return the list of all recognised annotations
     */
    private List<String> getCurrentAnnotations()
    {
        List<String> annotations = new ArrayList<String>();
        annotations.addAll(getClientCodeAnnotations()); // client code
        annotations.addAll(getMatterCodeAnnotations()); // file code
        annotations.addAll(getEntityCodeAnnotations()); // entity code
        annotations.addAll(getDepartmentAnnotations()); // department
        annotations.addAll(getWorkflowCodeAnnotations()); // workflow code
        annotations.addAll(getOtherAnnotations()); // other
        return annotations;
    }

    /**
     * @return the list of client code annotations
     */
    private List<String> getClientCodeAnnotations()
    {
        // TODO currently hard-coded
        List<String> annotations = new ArrayList<String>();
        annotations.add("c");
        annotations.add("client");
        return annotations;
    }

    /**
     * @return the list of matter code annotations
     */
    private List<String> getMatterCodeAnnotations()
    {
        // TODO currently hard-coded
        List<String> annotations = new ArrayList<String>();
        annotations.add("m");
        annotations.add("matter");
        annotations.add("f");
        annotations.add("file");
        return annotations;
    }

    /**
     * @return the list of entity code annotations
     */
    private List<String> getEntityCodeAnnotations()
    {
        // TODO currently hard-coded
        List<String> annotations = new ArrayList<String>();
        annotations.add("e");
        annotations.add("ent");
        annotations.add("entity");
        return annotations;
    }

    /**
     * @return the list of department annotations
     */
    private List<String> getDepartmentAnnotations()
    {
        // TODO currently hard-coded
        List<String> annotations = new ArrayList<String>();
        annotations.add("d");
        annotations.add("dept");
        annotations.add("department");
        return annotations;
    }

    /**
     * @return the list of workflow code annotations
     */
    private List<String> getWorkflowCodeAnnotations()
    {
        // TODO currently hard-coded
        List<String> annotations = new ArrayList<String>();
        annotations.add("w");
        annotations.add("wkflw");
        annotations.add("wkfl");
        annotations.add("wflw");
        annotations.add("wfl");
        annotations.add("workflow");
        return annotations;
    }

    /**
     * @return the list of miscellaneous annotations
     */
    private List<String> getOtherAnnotations()
    {
        // TODO currently hard-coded
        List<String> annotations = new ArrayList<String>();
        return annotations;
    }

    /**
     * url decode of a part of a URL.
     * @param value
     * @return the docded String
     */
    private String decode(final String value)
    {
        String retval = null;
        try
        {
            retval = URLDecoder.decode(value, "UTF-8");
        }
        catch (UnsupportedEncodingException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return retval;
    }

    /**
     * will be false for a folder, overridden in subclass
     * @return false, as this represents a path to a folder
     */
    public boolean hasFileName()
    {
        return false;
    }

}