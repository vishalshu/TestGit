/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.util;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class URLFolderDataFactory
{
    /** URL document data which contains all document related information */
    private final URLFolderData urlFolderData = new URLFolderData();;

    /**
     * This method is responsible for creating document data from the url passed.
     * @param url
     * @return document data from url.
     */
    public URLFolderData createUrlFolderData(final String url)
    {
        URL aURL = null;
        try
        {
            aURL = new URL(url);
            parseUrlMetadata(aURL.getPath().substring(1));
        }
        catch (MalformedURLException e)
        {
            // not a full url
            parseUrlMetadata(url);
        }

        return urlFolderData;

    }

    /**
     * This method will parse the path passed to fetch file name and location of folder
     * @param path
     */
    private void parseUrlMetadata(final String path)
    {
        String[] urlTokens = path.split("/");
        urlFolderData.setUrlTokens(urlTokens);
        StringBuilder folderLocation = new StringBuilder();
        int tokenCount = 0;
        for (String token : urlTokens)
        {
            if (tokenCount != 0)
            {
                folderLocation.append(token);
                // This check is done to avoid forward slash at the end of folder location.
                if (tokenCount != (urlTokens.length - 1))
                {
                    folderLocation.append("/");
                }

            }
            tokenCount++;
        }
        urlFolderData.setPath(folderLocation.toString());

    }

}
