/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.output;

import java.io.InputStream;

import com.lexisnexis.es.dms.core.transaction.DocumentRepositoryObject;
import com.lexisnexis.es.dms.core.transaction.RepositoryObjectLocation;

/**
 * Simple test object implementing DocumentRepositoryObject interface for unit testing <br/>
 * <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class TestDocumentRepositoryObject implements DocumentRepositoryObject
{

    /** an arbitrary id for testing */
    private String id = null;

    /** an arbitrary name for testing */
    private String name = null;

    /**
     * @param id
     * @param name
     */
    public TestDocumentRepositoryObject(final String id, final String name)
    {
        super();
        this.id = id;
        this.name = name;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getId()
    {
        return id;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName()
    {
        return name;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getDocumentFileName()
    {
        return getName();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getMimeType()
    {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isVersioned()
    {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isMajorVersion()
    {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public InputStream getContent()
    {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RepositoryObjectLocation getLocation()
    {
        return null;
    }

}
