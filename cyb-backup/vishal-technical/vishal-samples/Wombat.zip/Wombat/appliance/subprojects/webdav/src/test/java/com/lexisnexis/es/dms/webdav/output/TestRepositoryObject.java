/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.output;

import com.lexisnexis.es.dms.core.transaction.RepositoryObject;

/**
 * Simple test object implementing RepositoryObject interface for unit testing <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class TestRepositoryObject implements RepositoryObject
{

    /** supplied id */
    private String id = null;

    /** supplied name */
    private String name = null;

    /**
     * Constructor to generate a test object with arbitrary data
     * @param id an id
     * @param name aname
     */
    public TestRepositoryObject(final String id, final String name)
    {
        super();
        this.id = id;
        this.name = name;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getId()
    {
        return id;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getName()
    {
        return name;
    }

}
