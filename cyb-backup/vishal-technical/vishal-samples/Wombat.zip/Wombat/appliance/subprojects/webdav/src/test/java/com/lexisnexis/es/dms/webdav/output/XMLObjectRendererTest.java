/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.output;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;

import com.lexisnexis.es.dms.core.transaction.RepositoryObject;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class XMLObjectRendererTest
{
    /**
     * Test method for file folder
     */
    @Test
    public void testNoData()
    {
        XMLObjectRenderer renderer = new XMLObjectRenderer();
        Assert.assertEquals(renderer.renderObjects(null), "");
    }

    /**
     * Test method for empty file folder
     */
    @Test
    public void testEmptyFolder()
    {
        XMLObjectRenderer renderer = new XMLObjectRenderer();
        Assert.assertEquals(renderer.renderObjects("thingy", null), "<folder name='thingy'> </folder>");
    }

    /**
     * Test method for illegal file type
     */
    @Test(expected = IllegalArgumentException.class)
    public void testDodgyObject()
    {
        XMLObjectRenderer renderer = new XMLObjectRenderer();
        List<RepositoryObject> resultObjects = new ArrayList<RepositoryObject>();
        resultObjects.add(new TestRepositoryObject("1", "a"));
        renderer.renderObjects("thingy", resultObjects);
    }

    /**
     * Test method for valid data
     */
    @Test
    public void testValidFolder()
    {
        XMLObjectRenderer renderer = new XMLObjectRenderer();
        List<RepositoryObject> resultObjects = new ArrayList<RepositoryObject>();
        resultObjects.add(new TestDocumentRepositoryObject("1", "a"));
        resultObjects.add(new TestDocumentRepositoryObject("2", "b"));
        resultObjects.add(new TestDocumentRepositoryObject("3", "c"));
        String expectedResult = "<folder name='thingy'> <file name='a' id='1'/> <file name='b' id='2'/> <file name='c' id='3'/> </folder>";
        String actualResult = renderer.renderObjects("thingy", resultObjects);
        Assert.assertEquals(expectedResult, actualResult);
    }

}
