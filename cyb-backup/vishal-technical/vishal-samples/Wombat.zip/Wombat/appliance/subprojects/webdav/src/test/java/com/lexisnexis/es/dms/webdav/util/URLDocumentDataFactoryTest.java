/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.util;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author maheshy
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class URLDocumentDataFactoryTest
{

    /** urlDocumentFactory reference */
    URLDocumentDataFactory urlDocumentDataFactory_ = null;

    /**
     * Initial set up for all tests.
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception
    {
        urlDocumentDataFactory_ = new URLDocumentDataFactory();
    }

    /**
     * tear down for all tests
     * @throws Exception
     */
    @After
    public void tearDown() throws Exception
    {
        urlDocumentDataFactory_ = null;
    }

    /**
     * Test method for
     * {@link com.lexisnexis.es.dms.webdav.util.URLDocumentDataFactory#createUrlDocumentData(java.lang.String)}
     * .
     */
    @Test
    public void testCreateUrlForClientWrapper_Positive()
    {
        String url = "http://wombat:8080/lndms/client/00001/00002/Personal/test.doc";
        URLDocumentData urlDocumentData = urlDocumentDataFactory_.createUrlDocumentData(url);

        Assert.assertEquals(urlDocumentData.getFilename(), "test.doc");
        Assert.assertEquals(urlDocumentData.getPath(), "client/00001/00002/Personal");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[0], "lndms");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[1], "client");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[2], "00001");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[3], "00002");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[4], "Personal");
        // TODO: Need to implement testcase for query part.
    }

    /**
     * test case for paring partial url
     */
    public void testCreateUrlDocumentData_partialUrl()
    {
        String url = "lndms/client/00001/00002/Personal/test.doc";
        urlDocumentDataFactory_.createUrlDocumentData(url);
        URLDocumentData urlDocumentData = urlDocumentDataFactory_.createUrlDocumentData(url);
        Assert.assertEquals(urlDocumentData.getFilename(), "test.doc");
        Assert.assertEquals(urlDocumentData.getPath(), "client/00001/00002/Personal");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[0], "lndms");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[1], "client");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[2], "00001");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[3], "00002");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[4], "Personal");
        // TODO: Need to implement testcase for query part.
    }

    /**
     * 
     */
    @Test
    public void testCreateUrlForDefaultWrapper_Positive()
    {
        String url = "http://wombat:8080/lndms/HumanResource/Official/Employee.xls";
        URLDocumentData urlDocumentData = urlDocumentDataFactory_.createUrlDocumentData(url);

        Assert.assertEquals(urlDocumentData.getFilename(), "Employee.xls");
        Assert.assertEquals(urlDocumentData.getPath(), "HumanResource/Official");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[0], "lndms");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[1], "HumanResource");
        Assert.assertEquals(urlDocumentData.getUrlTokens()[2], "Official");
        // TODO: Need to implement testcase for query part.
    }

}
