/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.util;

import junit.framework.Assert;

import org.junit.Test;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class URLDocumentDataTest
{
    /**
     * Test method for file doc
     * {@link com.lexisnexis.es.dms.webdav.util.URLDocumentDataFactory#createUrlDocumentData(java.lang.String)}
     * .
     */
    @Test
    public void testClientMatterDoc()
    {
        String url = "http://wombat:8080/lndms/client/c_00000001/f_00000002/Personal/test.doc";
        URLDocumentData urlDocumentData = new URLDocumentDataFactory().createUrlDocumentData(url);
        Assert.assertEquals(urlDocumentData.getClientCode(), "00000001");
        Assert.assertEquals(urlDocumentData.getMatterCode(), "00000002");
        Assert.assertNull(urlDocumentData.getWorkflowCode());
        Assert.assertNull(urlDocumentData.getDepartment());
        Assert.assertNull(urlDocumentData.getEntityCode());
        Assert.assertEquals(urlDocumentData.getFilename(), "test.doc");
    }

    /**
     * Test method for client doc .
     */
    @Test
    public void testClientDoc()
    {
        String url = "http://wombat:8080/lndms/client/c_00000001/test.doc";
        URLDocumentData urlDocumentData = new URLDocumentDataFactory().createUrlDocumentData(url);
        Assert.assertEquals(urlDocumentData.getClientCode(), "00000001");
        Assert.assertNull(urlDocumentData.getMatterCode());
        Assert.assertNull(urlDocumentData.getWorkflowCode());
        Assert.assertNull(urlDocumentData.getDepartment());
        Assert.assertNull(urlDocumentData.getEntityCode());
        Assert.assertEquals(urlDocumentData.getFilename(), "test.doc");
    }

    /**
     * Test method for client workflow doc .
     */
    @Test
    public void testClientWorkflowDoc()
    {
        String url = "http://wombat:8080/lndms/client/client_00000001/w_1234/test.doc";
        URLDocumentData urlDocumentData = new URLDocumentDataFactory().createUrlDocumentData(url);
        Assert.assertEquals(urlDocumentData.getClientCode(), "00000001");
        Assert.assertNull(urlDocumentData.getMatterCode());
        Assert.assertEquals(urlDocumentData.getWorkflowCode(), "1234");
        Assert.assertNull(urlDocumentData.getDepartment());
        Assert.assertNull(urlDocumentData.getEntityCode());
        Assert.assertEquals(urlDocumentData.getFilename(), "test.doc");
    }

    /**
     * Test method for file workflow doc .
     */
    @Test
    public void testFileWorkflowDoc()
    {
        String url = "http://wombat:8080/lndms/client/client_00000001/matter_00000002/w_1234/test.doc";
        URLDocumentData urlDocumentData = new URLDocumentDataFactory().createUrlDocumentData(url);
        Assert.assertEquals(urlDocumentData.getClientCode(), "00000001");
        Assert.assertEquals(urlDocumentData.getMatterCode(), "00000002");
        Assert.assertEquals(urlDocumentData.getWorkflowCode(), "1234");
        Assert.assertNull(urlDocumentData.getDepartment());
        Assert.assertNull(urlDocumentData.getEntityCode());
        Assert.assertEquals(urlDocumentData.getFilename(), "test.doc");
    }

    /**
     * Test method for rearrange tokens doc. Shouldnt affect parsing .
     */
    @Test
    public void testReverseUrl()
    {
        String url = "http://wombat:8080/lndms/client/wkfl_1234/matter_00000002/client_00000001/test.doc";
        URLDocumentData urlDocumentData = new URLDocumentDataFactory().createUrlDocumentData(url);
        Assert.assertEquals(urlDocumentData.getClientCode(), "00000001");
        Assert.assertEquals(urlDocumentData.getMatterCode(), "00000002");
        Assert.assertEquals(urlDocumentData.getWorkflowCode(), "1234");
        Assert.assertNull(urlDocumentData.getDepartment());
        Assert.assertNull(urlDocumentData.getEntityCode());
        Assert.assertEquals(urlDocumentData.getFilename(), "test.doc");
    }

    /**
     * Test method for department name .
     */
    @Test
    public void testDepartment()
    {
        String url = "http://wombat:8080/lndms/client/dept_Human%20Resources/c_00000001/f_00000002/Personal/test.doc";
        URLDocumentData urlDocumentData = new URLDocumentDataFactory().createUrlDocumentData(url);
        Assert.assertEquals(urlDocumentData.getClientCode(), "00000001");
        Assert.assertEquals(urlDocumentData.getMatterCode(), "00000002");
        Assert.assertNull(urlDocumentData.getWorkflowCode());
        Assert.assertEquals(urlDocumentData.getDepartment(), "Human Resources");
        Assert.assertNull(urlDocumentData.getEntityCode());
        Assert.assertEquals(urlDocumentData.getFilename(), "test.doc");
    }

    /**
     * Test method for paths.
     */
    @Test
    public void testPaths()
    {
        String url = "http://wombat:8080/lndms/client/dept_Human%20Resources/c_00000001/f_00000002/Personal/test.doc";
        URLDocumentData urlDocumentData = new URLDocumentDataFactory().createUrlDocumentData(url);
        Assert.assertEquals(urlDocumentData.getClientCode(), "00000001");
        Assert.assertEquals(urlDocumentData.getMatterCode(), "00000002");
        Assert.assertNull(urlDocumentData.getWorkflowCode());
        Assert.assertEquals(urlDocumentData.getDepartment(), "Human Resources");
        Assert.assertNull(urlDocumentData.getEntityCode());
        Assert.assertEquals(urlDocumentData.getFilename(), "test.doc");
        Assert.assertEquals(urlDocumentData.getPath(),
                            "client/dept_Human%20Resources/c_00000001/f_00000002/Personal");
        Assert.assertEquals(urlDocumentData.getLogicalPath(),
                            "dept_Human Resources/c_00000001/f_00000002/Personal");
    }

    /**
     * Test method for non client routing.
     */
    @Test
    public void testNonClient()
    {
        String url = "http://wombat:8080/lndms/dept_Human%20Resources/Personal/test.doc";
        URLDocumentData urlDocumentData = new URLDocumentDataFactory().createUrlDocumentData(url);
        Assert.assertNull(urlDocumentData.getClientCode());
        Assert.assertNull(urlDocumentData.getMatterCode());
        Assert.assertNull(urlDocumentData.getWorkflowCode());
        Assert.assertEquals(urlDocumentData.getDepartment(), "Human Resources");
        Assert.assertNull(urlDocumentData.getEntityCode());
        Assert.assertEquals(urlDocumentData.getFilename(), "test.doc");
        Assert.assertEquals(urlDocumentData.getPath(),
                            "dept_Human%20Resources/Personal");
        Assert.assertEquals(urlDocumentData.getLogicalPath(),
                            "dept_Human Resources/Personal");
    }

    /**
     * Test method for non annotated url.
     */
    @Test
    public void testNonAnnotated()
    {
        String url = "http://wombat:8080/lndms/client/00000001/00000002/test.doc";
        URLDocumentData urlDocumentData = new URLDocumentDataFactory().createUrlDocumentData(url);
        Assert.assertEquals(urlDocumentData.getFilename(), "test.doc");
        Assert.assertEquals(urlDocumentData.getPath(),
                            "client/00000001/00000002");
        Assert.assertEquals(urlDocumentData.getLogicalPath(),
                            "lndms/client/00000001/00000002");
    }
}
