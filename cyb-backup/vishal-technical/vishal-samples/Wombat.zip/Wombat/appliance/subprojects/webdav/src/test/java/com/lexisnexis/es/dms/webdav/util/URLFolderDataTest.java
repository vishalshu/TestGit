/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.webdav.util;

import junit.framework.Assert;

import org.junit.Test;

/**
 * Test for URLFolderData, folders now handled separately from documents <br/>
 * <br/>
 * <hr/>
 * @author omahonyj
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class URLFolderDataTest
{
    /**
     * Test method for file folder
     */
    @Test
    public void testClientMatterFolder()
    {
        String url = "http://wombat:8080/lndms/client/c_00000001/f_00000002/Personal/";
        URLFolderData urlFolderData = new URLFolderDataFactory().createUrlFolderData(url);
        Assert.assertEquals(urlFolderData.getClientCode(), "00000001");
        Assert.assertEquals(urlFolderData.getMatterCode(), "00000002");
        Assert.assertNull(urlFolderData.getWorkflowCode());
        Assert.assertNull(urlFolderData.getDepartment());
        Assert.assertNull(urlFolderData.getEntityCode());
    }

    /**
     * Test method for client folder .
     */
    @Test
    public void testClientFolder()
    {
        String url = "http://wombat:8080/lndms/client/c_00000001";
        URLFolderData urlFolderData = new URLFolderDataFactory().createUrlFolderData(url);
        Assert.assertEquals(urlFolderData.getClientCode(), "00000001");
        Assert.assertNull(urlFolderData.getMatterCode());
        Assert.assertNull(urlFolderData.getWorkflowCode());
        Assert.assertNull(urlFolderData.getDepartment());
        Assert.assertNull(urlFolderData.getEntityCode());
    }

    /**
     * Test method for client workflow folder .
     */
    @Test
    public void testClientWorkflowFolder()
    {
        String url = "http://wombat:8080/lndms/client/client_00000001/w_1234";
        URLFolderData urlFolderData = new URLFolderDataFactory().createUrlFolderData(url);
        Assert.assertEquals(urlFolderData.getClientCode(), "00000001");
        Assert.assertNull(urlFolderData.getMatterCode());
        Assert.assertEquals(urlFolderData.getWorkflowCode(), "1234");
        Assert.assertNull(urlFolderData.getDepartment());
        Assert.assertNull(urlFolderData.getEntityCode());
    }

    /**
     * Test method for file workflow folder .
     */
    @Test
    public void testFileWorkflowFolder()
    {
        String url = "http://wombat:8080/lndms/client/client_00000001/matter_00000002/w_1234";
        URLFolderData urlFolderData = new URLFolderDataFactory().createUrlFolderData(url);
        Assert.assertEquals(urlFolderData.getClientCode(), "00000001");
        Assert.assertEquals(urlFolderData.getMatterCode(), "00000002");
        Assert.assertEquals(urlFolderData.getWorkflowCode(), "1234");
        Assert.assertNull(urlFolderData.getDepartment());
        Assert.assertNull(urlFolderData.getEntityCode());
    }

    /**
     * Test method for rearrange tokens. Shouldnt affect parsing .
     */
    @Test
    public void testReverseUrl()
    {
        String url = "http://wombat:8080/lndms/client/wkfl_1234/matter_00000002/client_00000001";
        URLFolderData urlFolderData = new URLFolderDataFactory().createUrlFolderData(url);
        Assert.assertEquals(urlFolderData.getClientCode(), "00000001");
        Assert.assertEquals(urlFolderData.getMatterCode(), "00000002");
        Assert.assertEquals(urlFolderData.getWorkflowCode(), "1234");
        Assert.assertNull(urlFolderData.getDepartment());
        Assert.assertNull(urlFolderData.getEntityCode());
    }

    /**
     * Test method for department name .
     */
    @Test
    public void testDepartment()
    {
        String url = "http://wombat:8080/lndms/client/dept_Human%20Resources/c_00000001/f_00000002/Personal";
        URLFolderData urlFolderData = new URLFolderDataFactory().createUrlFolderData(url);
        Assert.assertEquals(urlFolderData.getClientCode(), "00000001");
        Assert.assertEquals(urlFolderData.getMatterCode(), "00000002");
        Assert.assertNull(urlFolderData.getWorkflowCode());
        Assert.assertEquals(urlFolderData.getDepartment(), "Human Resources");
        Assert.assertNull(urlFolderData.getEntityCode());
    }

    /**
     * Test method for paths.
     */
    @Test
    public void testPaths()
    {
        String url = "http://wombat:8080/lndms/client/dept_Human%20Resources/c_00000001/f_00000002/Personal";
        URLFolderData urlFolderData = new URLFolderDataFactory().createUrlFolderData(url);
        Assert.assertEquals(urlFolderData.getClientCode(), "00000001");
        Assert.assertEquals(urlFolderData.getMatterCode(), "00000002");
        Assert.assertNull(urlFolderData.getWorkflowCode());
        Assert.assertEquals(urlFolderData.getDepartment(), "Human Resources");
        Assert.assertNull(urlFolderData.getEntityCode());
        Assert.assertEquals(urlFolderData.getPath(),
                            "client/dept_Human%20Resources/c_00000001/f_00000002/Personal");
        Assert.assertEquals(urlFolderData.getLogicalPath(),
                            "dept_Human Resources/c_00000001/f_00000002/Personal");
    }

    /**
     * Test method for non client routing.
     */
    @Test
    public void testNonClient()
    {
        String url = "http://wombat:8080/lndms/dept_Human%20Resources/Personal";
        URLFolderData urlFolderData = new URLFolderDataFactory().createUrlFolderData(url);
        Assert.assertNull(urlFolderData.getClientCode());
        Assert.assertNull(urlFolderData.getMatterCode());
        Assert.assertNull(urlFolderData.getWorkflowCode());
        Assert.assertEquals(urlFolderData.getDepartment(), "Human Resources");
        Assert.assertNull(urlFolderData.getEntityCode());
        Assert.assertEquals(urlFolderData.getPath(),
                            "dept_Human%20Resources/Personal");
        Assert.assertEquals(urlFolderData.getLogicalPath(),
                            "dept_Human Resources/Personal");
    }

    /**
     * Test method for non annotated url.
     */
    @Test
    public void testNonAnnotated()
    {
        String url = "http://wombat:8080/lndms/client/00000001/00000002";
        URLFolderData urlFolderData = new URLFolderDataFactory().createUrlFolderData(url);
        // cant reliably determine codes in non annotated url
        // Assert.assertNull(urlFolderData.getClientCode());
        // Assert.assertNull(urlFolderData.getMatterCode());
        // Assert.assertNull(urlFolderData.getWorkflowCode());
        // Assert.assertNull(urlFolderData.getDepartment());
        // Assert.assertNull(urlFolderData.getEntityCode());
        Assert.assertEquals(urlFolderData.getPath(),
                            "client/00000001/00000002");
        Assert.assertEquals(urlFolderData.getLogicalPath(),
                            "lndms/client/00000001/00000002");
    }

    /**
     * Test method for paths where a slash has been left on the end of the url.
     */
    @Test
    public void testPathsWithTrailingSlash()
    {
        String url = "http://wombat:8080/lndms/client/dept_Human%20Resources/c_00000001/f_00000002/Personal/";
        URLFolderData urlFolderData = new URLFolderDataFactory().createUrlFolderData(url);
        Assert.assertEquals(urlFolderData.getClientCode(), "00000001");
        Assert.assertEquals(urlFolderData.getMatterCode(), "00000002");
        Assert.assertNull(urlFolderData.getWorkflowCode());
        Assert.assertEquals(urlFolderData.getDepartment(), "Human Resources");
        Assert.assertNull(urlFolderData.getEntityCode());
        Assert.assertEquals(urlFolderData.getPath(),
                            "client/dept_Human%20Resources/c_00000001/f_00000002/Personal");
        Assert.assertEquals(urlFolderData.getLogicalPath(),
                            "dept_Human Resources/c_00000001/f_00000002/Personal");
    }

}
