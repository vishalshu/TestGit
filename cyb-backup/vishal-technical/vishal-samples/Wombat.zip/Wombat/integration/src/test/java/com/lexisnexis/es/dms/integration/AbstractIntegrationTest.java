/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.integration;

import org.junit.Before;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lexisnexis.es.dms.core.service.TestConfigs;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class AbstractIntegrationTest
{
    /**
     * applicationContext to be used to perform unit test
     */
    protected ApplicationContext appContext;

    /** path where all the documents required for tests reside */
    public String testResourcesPath = TestConfigs.TEST_RESOURCES_PATH;

    /**
     * setup before performing test
     */
    @Before
    public void setup()
    {
        appContext = new ClassPathXmlApplicationContext("springconfig/test-integration-beans.xml");

    }
}
