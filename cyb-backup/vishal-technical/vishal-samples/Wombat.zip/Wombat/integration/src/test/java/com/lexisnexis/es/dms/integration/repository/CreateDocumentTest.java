/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.integration.repository;

import com.lexisnexis.es.dms.repository.AbstractRepositoryTest;
import com.lexisnexis.es.dms.repository.RepositoryException;

/**
 * Interface defining required test methods related to create document for all the test classes for specific
 * repositoru implementations.<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public interface CreateDocumentTest
{

    /**
     * test document creation for .doc format files
     * @throws RepositoryException
     */
    public void testCreateDocDocumentAction() throws RepositoryException;

    /**
     * test document creation for .xls format files
     * @throws RepositoryException
     */
    public void testCreateXlsDocumentAction() throws RepositoryException;

    /**
     * test document creation for .msg format files
     * @throws RepositoryException
     */
    public void testCreateMsgDocumentAction() throws RepositoryException;

    /**
     * test document creation for .docx format files
     * @throws RepositoryException
     */
    public void testCreateDocxDocumentAction() throws RepositoryException;

    /**
     * test document creation for .xlsx format files
     * @throws RepositoryException
     */
    public void testCreateXlsxDocumentAction() throws RepositoryException;

    /**
     * test bulk document creation scenario 1 for office 2007 files NOTE: Files for the scenario can be found
     * at {@link AbstractRepositoryTest#testResourcesPath}
     * @throws RepositoryException
     */
    public void testBulkWFScenario1ForOffice2007() throws RepositoryException;

    /**
     * test bulk document creation scenario 2 for office 2007 files NOTE: Files for the scenario can be found
     * at {@link AbstractRepositoryTest#testResourcesPath}
     * @throws RepositoryException
     */
    public void testBulkWFScenario2ForOffice2007() throws RepositoryException;

    /**
     * test bulk document creation scenario 3 for office 2007 files NOTE: Files for the scenario can be found
     * at {@link AbstractRepositoryTest#testResourcesPath}
     * @throws RepositoryException
     */
    public void testBulkWFScenario3ForOffice2007() throws RepositoryException;

    /**
     * test bulk document creation scenario 4 for office 2007 files NOTE: Files for the scenario can be found
     * at {@link AbstractRepositoryTest#testResourcesPath}
     * @throws RepositoryException
     */
    public void testBulkWFScenario4ForOffice2007() throws RepositoryException;

    /**
     * test bulk document creation scenario 1 for office 2003 files NOTE: Files for the scenario can be found
     * at {@link AbstractRepositoryTest#testResourcesPath}
     * @throws RepositoryException
     */
    public void testBulkWFScenario1ForOffice2003() throws RepositoryException;

    /**
     * test bulk document creation scenario 2 for office 2003 files NOTE: Files for the scenario can be found
     * at {@link AbstractRepositoryTest#testResourcesPath}
     * @throws RepositoryException
     */
    public void testBulkWFScenario2ForOffice2003() throws RepositoryException;

    /**
     * test bulk document creation scenario 3 for office 2003 files NOTE: Files for the scenario can be found
     * at {@link AbstractRepositoryTest#testResourcesPath}
     * @throws RepositoryException
     */
    public void testBulkWFScenario3ForOffice2003() throws RepositoryException;

    /**
     * test bulk document creation scenario 4 for office 2003 files NOTE: Files for the scenario can be found
     * at {@link AbstractRepositoryTest#testResourcesPath}
     * @throws RepositoryException
     */
    public void testBulkWFScenario4ForOffice2003() throws RepositoryException;
}
