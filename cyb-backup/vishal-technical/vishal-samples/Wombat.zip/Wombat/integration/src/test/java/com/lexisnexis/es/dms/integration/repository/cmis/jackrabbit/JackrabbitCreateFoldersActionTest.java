/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.integration.repository.cmis.jackrabbit;

import org.junit.Test;

import com.lexisnexis.es.dms.adapter.cmis.actions.CmisCreateFolderAction;
import com.lexisnexis.es.dms.integration.util.RepositoryIntegrationTestsUtil;
import com.lexisnexis.es.dms.repository.AbstractRepositoryTest;
import com.lexisnexis.es.dms.repository.RepositoryException;

/**
 * CreateFoldersAction test for cmis connection of jackrabbit repository<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class JackrabbitCreateFoldersActionTest extends AbstractRepositoryTest
{

    /**
     * test valid request for folder creation for the repository.<br>
     * @throws RepositoryException
     */
    @Test
    public void testValidCreateFoldersAction() throws RepositoryException
    {
        final CmisCreateFolderAction createFolderAction = appContext
                                .getBean("jackrabbitCreateFolderAction",
                                                                              CmisCreateFolderAction.class);
        RepositoryIntegrationTestsUtil.testValidCreateFoldersAction(appContext, createFolderAction);
    }

}
