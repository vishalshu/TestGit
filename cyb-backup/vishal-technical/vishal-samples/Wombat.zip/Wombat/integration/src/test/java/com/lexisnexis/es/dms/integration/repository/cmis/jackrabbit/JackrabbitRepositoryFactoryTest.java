/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.integration.repository.cmis.jackrabbit;

import org.junit.Test;

import com.lexisnexis.es.dms.adapter.cmis.CmisRepositoryFactory;
import com.lexisnexis.es.dms.repository.AbstractRepositoryTest;
import com.lexisnexis.es.dms.repository.RepositoryException;
import com.lexisnexis.es.dms.repository.util.RepositoryConfigTestsUtil;

/**
 * JUnit test class for jackrabbit RepositoryFactory <br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class JackrabbitRepositoryFactoryTest extends AbstractRepositoryTest
{

    /**
     * tests for repository instance lookup.
     * @throws RepositoryException
     */

    @Test
    public void testRepositoryLookup() throws RepositoryException
    {
        CmisRepositoryFactory cmisRepoFactory = appContext.getBean("jackrabbitCmisRepositoryFactory",
                                                                   CmisRepositoryFactory.class);
        RepositoryConfigTestsUtil.testRepositoryLookup(cmisRepoFactory);
    }

}
