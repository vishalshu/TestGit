/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.integration.repository.cmis.sharepoint;

import org.junit.Test;

import com.lexisnexis.es.dms.integration.repository.CreateDocumentTest;
import com.lexisnexis.es.dms.integration.util.RepositoryIntegrationTestsUtil;
import com.lexisnexis.es.dms.repository.AbstractRepositoryTest;
import com.lexisnexis.es.dms.repository.RepositoryException;
import com.lexisnexis.es.dms.repository.actions.CreateBulkDocumentsAction;
import com.lexisnexis.es.dms.repository.actions.CreateDocumentAction;

/**
 * CreateDocumentAction test for cmis connection of sharepoint repository<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class SharepointCreateDocumentActionTest extends AbstractRepositoryTest implements
                        CreateDocumentTest
{

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testCreateXlsxDocumentAction() throws RepositoryException
    {

        // lookup action object
        CreateDocumentAction createDocAction = appContext.getBean("sharepointCreateDocumentAction",
                                                                       CreateDocumentAction.class);

        RepositoryIntegrationTestsUtil.testCreateDocumentAction(appContext,
                                                           createDocAction,
                                                           testResourcesPath, "Sample.xlsx");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testCreateDocDocumentAction() throws RepositoryException
    {
        // lookup action object
        CreateDocumentAction createDocAction = appContext.getBean("sharepointCreateDocumentAction",
                                                                       CreateDocumentAction.class);

        RepositoryIntegrationTestsUtil.testCreateDocumentAction(appContext,
                                                           createDocAction,
                                                           testResourcesPath, "Sample.doc");

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testCreateXlsDocumentAction() throws RepositoryException
    {
        // lookup action object
        CreateDocumentAction createDocAction = appContext.getBean("sharepointCreateDocumentAction",
                                                                       CreateDocumentAction.class);

        RepositoryIntegrationTestsUtil.testCreateDocumentAction(appContext,
                                                           createDocAction,
                                                           testResourcesPath, "Sample.xls");

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testCreateMsgDocumentAction() throws RepositoryException
    {
        // lookup action object
        CreateDocumentAction createDocAction = appContext.getBean("sharepointCreateDocumentAction",
                                                                       CreateDocumentAction.class);

        RepositoryIntegrationTestsUtil.testCreateDocumentAction(appContext,
                                                           createDocAction,
                                                           testResourcesPath, "Sample.msg");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testCreateDocxDocumentAction() throws RepositoryException
    {
        // lookup action object
        CreateDocumentAction createDocAction = appContext.getBean("sharepointCreateDocumentAction",
                                                                       CreateDocumentAction.class);

        RepositoryIntegrationTestsUtil.testCreateDocumentAction(appContext,
                                                           createDocAction,
                                                           testResourcesPath, "Sample.docx");

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testBulkWFScenario1ForOffice2007() throws RepositoryException
    {
        // lookup action object
        CreateBulkDocumentsAction createDocAction = appContext.getBean("sharepointCreateBulkDocumentAction",
                                                                       CreateBulkDocumentsAction.class);

        RepositoryIntegrationTestsUtil.testCreateBulkDocumentsAction(appContext,
                                                                createDocAction,
                                                                testResourcesPath + "/wf_sc_1_2007");

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testBulkWFScenario2ForOffice2007() throws RepositoryException
    {
        // lookup action object
        CreateBulkDocumentsAction createDocAction = appContext.getBean("sharepointCreateBulkDocumentAction",
                                                                       CreateBulkDocumentsAction.class);

        RepositoryIntegrationTestsUtil.testCreateBulkDocumentsAction(appContext,
                                                                createDocAction,
                                                                testResourcesPath + "/wf_sc_2_2007");

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testBulkWFScenario3ForOffice2007() throws RepositoryException
    {
        // lookup action object
        CreateBulkDocumentsAction createDocAction = appContext.getBean("sharepointCreateBulkDocumentAction",
                                                                       CreateBulkDocumentsAction.class);

        RepositoryIntegrationTestsUtil.testCreateBulkDocumentsAction(appContext,
                                                                createDocAction,
                                                                testResourcesPath + "/wf_sc_3_2007");

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testBulkWFScenario4ForOffice2007() throws RepositoryException
    {
        // lookup action object
        CreateBulkDocumentsAction createDocAction = appContext.getBean("sharepointCreateBulkDocumentAction",
                                                                       CreateBulkDocumentsAction.class);

        RepositoryIntegrationTestsUtil.testCreateBulkDocumentsAction(appContext,
                                                                createDocAction,
                                                                testResourcesPath + "/wf_sc_4_2007");

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testBulkWFScenario1ForOffice2003() throws RepositoryException
    {
        // lookup action object
        CreateBulkDocumentsAction createDocAction = appContext.getBean("sharepointCreateBulkDocumentAction",
                                                                       CreateBulkDocumentsAction.class);

        RepositoryIntegrationTestsUtil.testCreateBulkDocumentsAction(appContext,
                                                                createDocAction,
                                                                testResourcesPath + "/wf_sc_1_2003");

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testBulkWFScenario2ForOffice2003() throws RepositoryException
    {
        // lookup action object
        CreateBulkDocumentsAction createDocAction = appContext.getBean("sharepointCreateBulkDocumentAction",
                                                                       CreateBulkDocumentsAction.class);

        RepositoryIntegrationTestsUtil.testCreateBulkDocumentsAction(appContext,
                                                                createDocAction,
                                                                testResourcesPath + "/wf_sc_2_2003");

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testBulkWFScenario3ForOffice2003() throws RepositoryException
    {
        // lookup action object
        CreateBulkDocumentsAction createDocAction = appContext.getBean("sharepointCreateBulkDocumentAction",
                                                                       CreateBulkDocumentsAction.class);

        RepositoryIntegrationTestsUtil.testCreateBulkDocumentsAction(appContext,
                                                                createDocAction,
                                                                testResourcesPath + "/wf_sc_3_2003");

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Test
    public void testBulkWFScenario4ForOffice2003() throws RepositoryException
    {
        // lookup action object
        CreateBulkDocumentsAction createDocAction = appContext.getBean("sharepointCreateBulkDocumentAction",
                                                                       CreateBulkDocumentsAction.class);

        RepositoryIntegrationTestsUtil.testCreateBulkDocumentsAction(appContext,
                                                                createDocAction,
                                                                testResourcesPath + "/wf_sc_4_2003");

    }

}
