package com.lexisnexis.es.dms.integration.services;

import java.io.FileNotFoundException;

import org.junit.Assert;
import org.junit.Test;

import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.integration.AbstractIntegrationTest;
import com.lexisnexis.es.dms.service.LNServiceException;
import com.lexisnexis.es.dms.service.RequestProcessor;
import com.lexisnexis.es.dms.service.SpringServiceLookup;
import com.lexisnexis.es.utilities.exceptions.LNConfigurationException;

/**
 * A test class for the RequestProcessor. <br/>
 * <hr/>
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author omahonyj
 */

public class RequestProcessorTest extends AbstractIntegrationTest
{
    /**
     * Tests that some events have been added to the context
     * @throws LNConfigurationException a configuration issue
     * @throws FileNotFoundException if file not found
     * @throws LNServiceException if there is an issue with getting services
     */
    @Test
    public void eventsAdded() throws FileNotFoundException, LNConfigurationException, LNServiceException
    {
        RequestProcessor rp = new RequestProcessor();

        RequestContext requestContext = appContext.getBean("createDocumentRequestContext",
                                                               RequestContext.class);
        SpringServiceLookup serviceLookup = appContext.getBean("springServiceLookup",
                                                               SpringServiceLookup.class);
        rp.setServiceLookup(serviceLookup);

        rp.process(requestContext);

        Assert.assertNotNull(requestContext.getEvents());
    }

}
