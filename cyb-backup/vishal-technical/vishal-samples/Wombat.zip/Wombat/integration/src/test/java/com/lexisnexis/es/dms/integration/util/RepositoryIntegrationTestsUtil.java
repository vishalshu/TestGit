package com.lexisnexis.es.dms.integration.util;

/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

import java.io.FileNotFoundException;

import junit.framework.Assert;

import org.springframework.context.ApplicationContext;

import com.lexisnexis.es.dms.core.service.RepositoryObjectFactory;
import com.lexisnexis.es.dms.core.service.TestConfigs;
import com.lexisnexis.es.dms.core.transaction.BulkDocumentsInfo;
import com.lexisnexis.es.dms.core.transaction.RequestContext;
import com.lexisnexis.es.dms.core.transaction.RequestResult;
import com.lexisnexis.es.dms.repository.RepositoryException;
import com.lexisnexis.es.dms.repository.actions.CreateBulkDocumentsAction;
import com.lexisnexis.es.dms.repository.actions.CreateDocumentAction;
import com.lexisnexis.es.dms.repository.actions.CreateFolderAction;
import com.lexisnexis.es.dms.repository.actions.RetrieveDocumentsAction;
import com.lexisnexis.es.dms.repository.util.RepositoryActionTestsUtil;

/**
 * Methods in this class can be called from repository specific repository action test methods<br/>
 * <br/>
 * <hr/>
 * @author shuklav
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class RepositoryIntegrationTestsUtil
{
    /**
     * test valid request for document creation for repository.<br/>
     * <br/>
     * @param appContext spring application context object
     * @param createDocAction cmis implementation for CreateDocumentAction
     * @throws RepositoryException
     */
    public static void testCreateDocumentAction(final ApplicationContext appContext,
                                                final CreateDocumentAction createDocAction) throws RepositoryException
    {

        testCreateDocumentAction(appContext, createDocAction, TestConfigs.TEST_RESOURCES_PATH, "Sample.txt");

    }

    /**
     * test valid request for document creation for repository.<br/>
     * <br/>
     * @param appContext spring application context object
     * @param createDocAction cmis implementation for CreateDocumentAction
     * @param filePath
     * @param fileName TODO
     * @throws RepositoryException
     */
    public static void testCreateDocumentAction(final ApplicationContext appContext,
                                                final CreateDocumentAction createDocAction,
                                                final String filePath, final String fileName) throws RepositoryException
    {
        RepositoryActionTestsUtil.testCreateDocumentAction(appContext, createDocAction, filePath, fileName);

    }

    /**
     * test valid request for document creation for repository.<br/>
     * <br/>
     * @param appContext spring application context object
     * @param createDocAction cmis implementation for CreateDocumentAction
     * @param folderPath
     * @throws RepositoryException
     */
    public static void testCreateBulkDocumentsAction(final ApplicationContext appContext,
                                                     final CreateBulkDocumentsAction createDocAction,
                                                     final String folderPath) throws RepositoryException

    {
        // lookup test request context
        final RequestContext requestContext = appContext.getBean("createBulkDocumentsRequestContext",
                                                                 RequestContext.class);

        BulkDocumentsInfo info = null;
        try
        {
            info = new RepositoryObjectFactory()
                                    .getDocumentsFromFolder(folderPath,
                                                            "lndms/client/00000001/00000002");
        }
        catch (FileNotFoundException e)
        {
            Assert.fail("File path could not be found.");
            e.printStackTrace();
            return;
        }

        requestContext.setRepositoryObjectInfo(info);

        int actSize = info.getDocuments().size();
        // execute method under test
        final RequestResult result = createDocAction.execute(requestContext);

        // assertion criteria
        Assert.assertNotNull(result);
        Assert.assertTrue(result.getResults().size() == actSize);

        for (int i = 0; i < actSize; i++)
        {
            Assert.assertNotNull(result.getResults().get(i).getId());
        }

    }

    /**
     * test valid request for folder creation for the repository. <br/>
     * @param appContext spring application context object
     * @param createFolderAction
     * @throws RepositoryException
     */
    public static void testValidCreateFoldersAction(final ApplicationContext appContext,
                                                    final CreateFolderAction createFolderAction) throws RepositoryException
    {
        // lookup test request context
        final RequestContext requestContext = appContext.getBean("createFolderActionRequestContext",
                                                                 RequestContext.class);

        // execute method under test
        final RequestResult result = createFolderAction.execute(requestContext);

        // assertion criteria
        Assert.assertNotNull(result);
        Assert.assertTrue(result.getResults().size() > 0);
        Assert.assertNotNull(result.getResults().get(0).getId());

    }

    /**
     * util method for test valid request for retrieving documents based on ID from the repository. <br/>
     * @param retrieveDocByIdAction
     * @param requestContext TODO
     * @throws RepositoryException
     */
    public static void testRetrieveDocumentsByIdAction(final RetrieveDocumentsAction retrieveDocByIdAction,
                                                       final RequestContext requestContext) throws RepositoryException
    {

        // execute method under test
        final RequestResult result = retrieveDocByIdAction.execute(requestContext);

        // assertion criteria
        Assert.assertNotNull(result);
        Assert.assertTrue(result.getResults().size() > 0);
        Assert.assertNotNull(result.getResults().get(0).getId());

    }

    /**
     * util method for test retrieve documents by null id<br/>
     * @param appContext
     * @param retrieveDocByIdAction
     */

    public static void testRetrieveDocumentsByNullId(final ApplicationContext appContext,
                                                     final RetrieveDocumentsAction retrieveDocByIdAction)
    {
        // lookup test request context
        final RequestContext requestContext = appContext.getBean("retrieveDocumentsByNullIdRequestContext",
                                                                 RequestContext.class);

        // execute method under test
        final RequestResult result = retrieveDocByIdAction.execute(requestContext);

        // assertion criteria
        Assert.assertNotNull(result);
        Assert.assertTrue(result.getResults().size() == 0);
    }

}
