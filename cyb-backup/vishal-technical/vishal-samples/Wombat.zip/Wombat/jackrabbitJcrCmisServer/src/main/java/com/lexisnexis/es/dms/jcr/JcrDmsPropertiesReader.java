package com.lexisnexis.es.dms.jcr;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.lexisnexis.es.utilities.exceptions.SystemException;

/**
 * A class that will load the properties required to setup a JCR repository.<br>
 * The values will come from a properties file on the server. <br/>
 * <hr/>
 * Copyright 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author cruttens
 */
public class JcrDmsPropertiesReader
{

    /** The properties file to be used as specified by a Java runtime param. See JBOSS Startup file */
    public static final String PROPERITES_FILE = "PropertiesFile";

    /** Properties object to hold the properties. */
    protected static Properties jcrProperties;

    /** Logger for this class. */
    private static final Logger logger_ = Logger
                            .getLogger(JcrDmsPropertiesReader.class);

    /** Full path of the server root. Lazy created. */
    private static String serverRoot;

    /**
     * Load up the properties when the class is loaded.
     */
    static
    {
        readPropFile();
    }

    /**
     * Read the values from the properties file supplied into the Properties object.
     */
    private static void readPropFile()
    {
        try
        {
            final String propFileLocation = System.getProperty(PROPERITES_FILE);
            FileInputStream fis = new FileInputStream(propFileLocation);
            jcrProperties = new Properties();
            jcrProperties.load(fis);
        }
        catch (FileNotFoundException fne)
        {
            logger_.error("Unable to load the JCR properties file");
        }
        catch (IOException ioe)
        {
            logger_.error("Unable to load the JCR properties file");
        }
    }

    /**
     * Get a value from the properties. Default supplied.
     * @param strName Name of value to return
     * @param strDefault Default value to return if name not found.
     * @return Value corresponding to name. Null if nothing is found.
     */
    public static String getParameter(final String strName,
                                      final String strDefault)
    {
        return (jcrProperties.getProperty(strName, strDefault));
    }

    /**
     * Get a value from the properties. No default supplied.
     * @param strName
     * @return Value corresponding to name. Null if nothing is found.
     */
    public static String getParameter(final String strName)
    {
        return jcrProperties.getProperty(strName);
    }

    /**
     * Get the location of the JCR repository
     * @return A repository location as supplied in the properties appended to the server home directory.
     */
    public static String getRepositoryLocation()
    {
        return getServerRelativePathProperty("repositoryLocation");
    }

    /**
     * Get the location of the repository config file.
     * @return A location as specified in the properties file appended to the server home directory.
     */
    public static String getRespositoryConfigFileLocation()
    {
        return getServerRelativePathProperty("repositoryConfigLocation");
    }

    /**
     * Gets a full pathname combined from the server root and a server root relative pathname found in
     * property <tt>propName</tt>. If there is no property <tt>propName</tt> it will be logged as an error.
     * @param propName Name of the property to derive a full pathname for.
     * @return The full pathname.
     * @throws SystemException There is no property <tt>propName</tt>.
     * @ln.depend.jboss System property for jboss.server.root
     */
    public static String getServerRelativePathProperty(final String propName)
    {
        if (serverRoot == null)
        {
            serverRoot = System.getProperty("jboss.server.home.dir");
        }

        String value = getParameter(propName);
        if (value != null)
        {
            return serverRoot + "/" + value;
        }
        else
        {
            logger_.error("getServerRelativePathProperty(String) - Missing property : propName="
                          + propName);
            throw new SystemException("missing required property", propName);
        }
    }
}
