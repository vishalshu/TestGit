package com.lexisnexis.es.dms.jcr;

import java.io.File;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.PropertyType;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.SimpleCredentials;
import javax.jcr.Value;
import javax.jcr.security.Privilege;

import org.apache.chemistry.opencmis.commons.impl.server.AbstractServiceFactory;
import org.apache.chemistry.opencmis.commons.server.CallContext;
import org.apache.chemistry.opencmis.commons.server.CmisService;
import org.apache.chemistry.opencmis.jcr.JcrNodeFactory;
import org.apache.chemistry.opencmis.jcr.JcrRepository;
import org.apache.chemistry.opencmis.jcr.JcrService;
import org.apache.chemistry.opencmis.jcr.JcrTypeManager;
import org.apache.chemistry.opencmis.server.support.CmisServiceWrapper;
import org.apache.jackrabbit.JcrConstants;
import org.apache.jackrabbit.core.RepositoryImpl;
import org.apache.jackrabbit.core.config.RepositoryConfig;
import org.apache.log4j.Logger;

import com.lexisnexis.es.dms.security.LnJcrAccessControlManager;

/**
 * This is a factory class to provide a JCR Jackrabbit repository to the Open CMIS JCR server. <br/>
 * @see repository.properties in the WEB-INF classes folder to see how this clas is registered.
 *      <hr/>
 *      Copyright 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 *      <hr/>
 * @author CruttenS
 */
public class JcrServiceFactory extends AbstractServiceFactory
{

    /** JCR CMIS Specific Value. Need to comment what this does */
    public static final BigInteger DEFAULT_MAX_ITEMS_TYPES = BigInteger.valueOf(50);

    /** JCR CMIS Specific Value. Need to comment what this does */
    public static final BigInteger DEFAULT_DEPTH_TYPES = BigInteger.valueOf(-1);

    /** JCR CMIS Specific Value. Need to comment what this does */
    public static final BigInteger DEFAULT_MAX_ITEMS_OBJECTS = BigInteger.valueOf(200);

    /** JCR CMIS Specific Value. Need to comment what this does */
    public static final BigInteger DEFAULT_DEPTH_OBJECTS = BigInteger.valueOf(10);

    /** Open Chemistry JcrRepository representation */
    private JcrRepository jcrRepository;

    /** Open Chemistry JcrTypeManager */
    private JcrTypeManager typeManager;

    /** Jackrabbit Repository Implementation */
    private RepositoryImpl repository_;

    /**
     * Credentials used to access the JCR repository. This allows us to create a root folder upon repository
     * startup.
     */
    private static SimpleCredentials masterLogonCreds;

    /** The workspace name supplied to Jackrabbit on startup. */
    private static final String WORKSPACENAME = "lndms";

    /** Root folder name to be created on Jackrabbit startup */
    private static final String ROOTFOLDER = "lndms";

    /** Credentials requires an empty array if no password. */
    private static final char[] EMPTY = new char[0];

    /** Logger for this class. */
    private static final Logger logger_ = Logger.getLogger(JcrServiceFactory.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public void init(final Map<String, String> parameters)
    {
        typeManager = new JcrTypeManager();
        jcrRepository = new JcrRepository(getJackrabbitRepository(),
                                          null,
                                          typeManager,
                                          new JcrNodeFactory());
    }

    /**
     * {@inheritDoc} <br>
     * <br>
     * Shutdown the JCR repository as well.
     */
    @Override
    public void destroy()
    {
        jcrRepository = null;
        typeManager = null;
        if (repository_ != null)
        {
            repository_.shutdown();
            repository_ = null;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public CmisService getService(final CallContext context)
    {
        CmisServiceWrapper<JcrService> serviceWrapper = new CmisServiceWrapper<JcrService>(createJcrService(jcrRepository,
                                                                                                            context),
                                                                                           DEFAULT_MAX_ITEMS_TYPES,
                                                                                           DEFAULT_DEPTH_TYPES,
                                                                                           DEFAULT_MAX_ITEMS_OBJECTS,
                                                                                           DEFAULT_DEPTH_OBJECTS);

        serviceWrapper.getWrappedService().setCallContext(context);
        return serviceWrapper;
    }

    /**
     * Create a <code>JcrService</code> from a <code>JcrRepository</code>JcrRepository> and
     * <code>CallContext</code>.
     * @param jcrRepository
     * @param context
     * @return
     */
    protected JcrService createJcrService(final JcrRepository jcrRepository, final CallContext context)
    {
        return new JcrService(jcrRepository);
    }

    /**
     * Get the jackrabbit repository. If one does not all ready exist then create one.
     * @return JCR Repository
     */
    private Repository getJackrabbitRepository()
    {
        if (repository_ == null)
        {
            acquireRepository();
        }

        return repository_;
    }

    /**
     * Acquire the Jackrabbit repository implementation.
     * @return JCR Repository
     */
    private Repository acquireRepository()
    {
        final String configFile = JcrDmsPropertiesReader.getRespositoryConfigFileLocation();
        final String repHomeDir = JcrDmsPropertiesReader.getRepositoryLocation();
        assert repHomeDir != null;
        Session session = null;
        try
        {
            final InputStream configStream = new File(configFile).toURI().toURL().openStream();
            RepositoryConfig config = RepositoryConfig.create(configStream, repHomeDir);
            repository_ = RepositoryImpl.create(config);
            logger_.debug("LNDMS Repository created");
            session = repository_.login(getLogonCredentials(), WORKSPACENAME);
            createUnlockableFolderNode(ROOTFOLDER, session);
            createWorkspaceLevelPrivileges(session,
                                           session.getRootNode().getPath() + WORKSPACENAME,
                                           session.getUserID());
            createAdminGroup(session);
            createWorkspaceLevelPrivileges(session,
                                           session.getRootNode().getPath() + WORKSPACENAME,
                                           "lnadmin");

            // Ensure the namespace
            // registerNamespace(session.getWorkspace());

            // Ensure the root folder exists
            // createUnlockableFolderNode("root", session);
            // ... and the 'silly path' empty folder

            // createUnlockableFolderNode("/EMPTY", session);
            // createUnlockableFolderNode(EmptyPathRedirect.NO_PATH, session);
            // ... then what to do about the node type definitions
            // final boolean nodeTypes = establishAction(session);
            // ... and then do the node type definitions accordingly
            // if (nodeTypes)
            // {
            // configureNodeTypes();
            // }

            // Save session here so that system node changes not saved until node types updated
            // session.save();
            // Logout the session
            // session.logout();

            // // Add the listeners we need to adjust things on the fly
            // addObservers();

            // Lastly the upload location
            // ensureFileUploadDir();
            // return repository_;
            return repository_;
        }
        catch (Exception ex)
        {
            logger_.error(ex.getMessage());
            // logger_.error("createRepository() - error creating repository : configFile="
            // + configFile + ", repHomeDir=" + repHomeDir, ex);
            // throw new DMSException(ex, RESOURCE_BUNDLE_NAME, "err.failed_creating_repository");
        }
        finally
        {
            session.logout();
        }

        if (logger_.isInfoEnabled())
        {
            logger_.info("createRepository() - DMS repository created");
        }
        return null;
    }

    /**
     * Creates a top level folder node, making it 'lockable', but without any synchronization on the root
     * node. This is because the root node is not of a lockable type, and so we have to create a top level
     * node that we _can_ lock, at a time when it is guaranteed there is no concurrent access.
     * <p>
     * If the required node already exists and is a nt:folder then NOP.
     * </p>
     * @param name Name of the folder to create.
     * @param session Session to create in.
     * @throws RepositoryException Fatal error creating the node.
     */
    private void createUnlockableFolderNode(String name, final Session session)
                                                                               throws RepositoryException
    {
        if (name.charAt(0) == '/')
        {
            name = name.substring(1);
        }
        if (name.endsWith("/"))
        {
            name = name.substring(1, name.length() - 1);
            // Contract.verify(name.indexOf('/') == -1); // Ensure this is a single path element
        }

        final Node root = session.getRootNode();
        if (!root.hasNode(name) ||
            !root.getNode(name).isNodeType("nt:folder"))
        {

            if (logger_.isInfoEnabled())
            {
                logger_.info("createUnlockableNode(String, Session) - creating infrastructure node  - name=" + name);
            }

            final Node node = root.addNode(name, JcrConstants.NT_FOLDER);
            node.addMixin("mix:referenceable");
            node.addMixin("mix:lockable");
            root.save();
        }
        else
        {
            // Ensure our root is referenceable
            final Node ourRoot = root.getNode(name);
            final String props = nodeProperties(ourRoot);
            if (!ourRoot.isNodeType("mix:referenceable"))
            {
                ourRoot.addMixin("mix:referenceable");
                ourRoot.save();
            }
        }
    }

    /**
     * Produces a semi-pretty dump of node properties for <tt>node</tt>. No child nodes are processed.
     * @param node Node to process.
     * @return Dump of the properties, name=value each on a separate line.
     */
    public static final String nodeProperties(final Node node)
    {
        final StringBuilder str = new StringBuilder(1024);

        try
        {
            // Look through all properties
            for (final PropertyIterator pitr = node.getProperties(); pitr.hasNext();)
            {
                final Property property = pitr.nextProperty();

                // Line separator and property name
                if (str.length() > 0)
                {
                    str.append('\n');
                }
                str.append(property.getName()).append('=');

                // Encapsulate single value properties to look line multi value properties
                Value[] values = null;
                if (property.getDefinition().isMultiple())
                {
                    values = property.getValues();
                }
                else
                {
                    values = new Value[] {property.getValue()};
                }

                // The property value, separator if needed
                String sep = ""; // Value separator
                for (final Value value : values)
                {
                    str.append(sep);
                    switch (value.getType())
                    {
                        case PropertyType.BINARY:
                            str.append("=<BINARY VALUE>");
                            break;
                        default:
                            str.append(value.getString());
                            break;
                    }
                    sep = ", "; // If there's any more use this separator
                } // FOR each value
            } // FOR each property
        }
        catch (final RepositoryException ex)
        {
            str.append("\nERROR: " + ex.getMessage());
        }

        return str.toString();
    }

    /**
     * Registers the namespace <code>namespace_</code> if it's not already there.
     * @param ws Workspace to access the namespace registry from.
     * @throws RepositoryException Fatal error accessing the docbase.
     * @throws NamespaceException Cannot register the namespace.
     * @throws UnsupportedRepositoryOperationException Cannot register the namespace.
     * @throws AccessDeniedException Cannot register the namespace.
     */
    // private static void registerNamespace(final Workspace ws)
    // throws RepositoryException,
    // NamespaceException,
    // UnsupportedRepositoryOperationException,
    // AccessDeniedException
    // {
    // final NamespaceRegistry nsReg = ws.getNamespaceRegistry();
    // if (!StringUtil.contains(nsReg.getPrefixes(), "axxia", false))
    // {
    // ws.getNamespaceRegistry().registerNamespace("axxia", namespace_);
    // }
    // }

    /**
     * Get the logon credentials for the master logon.
     * @return SimpleCredentials
     */
    private SimpleCredentials getLogonCredentials()
    {
        if (masterLogonCreds == null)
        {
            // TODO Currently this calls a stubbed out LnJcrLoginModule. Need to implement this with real
            // user data.
            masterLogonCreds = new SimpleCredentials("testwombat", EMPTY);
        }
        return masterLogonCreds;
    }

    /**
     * @param session
     * @param path
     */
    private void createWorkspaceLevelPrivileges(final Session session,
                                                final String path,
                                                final String principalId)
    {

        String[] grantedPrivilegeNames = {Privilege.JCR_ALL};
        LnJcrAccessControlManager.replaceCreateAccessControlEntry(session,
                                                                  principalId,
                                                                  path,
                                                                  grantedPrivilegeNames,
                                                                  null,
                                                                  null);
    }

    /**
     * Create an admin group for the LN dms
     * @param session
     */
    private void createAdminGroup(final Session session)
    {
        LnJcrAccessControlManager.createGroup(session, "lnadmin");
        // TODO Maybe add the priviliges to it here as well? Not sure yet.
    }
}
