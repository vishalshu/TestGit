/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.security;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.AccessDeniedException;
import javax.jcr.Item;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.UnsupportedRepositoryOperationException;
import javax.jcr.security.AccessControlEntry;
import javax.jcr.security.AccessControlList;
import javax.jcr.security.AccessControlManager;
import javax.jcr.security.AccessControlPolicy;
import javax.jcr.security.AccessControlPolicyIterator;
import javax.jcr.security.Privilege;

import org.apache.jackrabbit.api.JackrabbitSession;
import org.apache.jackrabbit.api.security.JackrabbitAccessControlEntry;
import org.apache.jackrabbit.api.security.JackrabbitAccessControlList;
import org.apache.jackrabbit.api.security.JackrabbitAccessControlManager;
import org.apache.jackrabbit.api.security.principal.PrincipalManager;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.User;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Access manager to add privileges, groups, users to Jackrabbit repository.<br/>
 * <br/>
 * <hr/>
 * @author cruttens
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class LnJcrAccessControlManager
{

    /** Logger to use */
    private static final Logger log = LoggerFactory.getLogger(LnJcrAccessControlManager.class);

    /**
     * Replace or create depending on what already exists a set of access control entry privileges
     * @param session
     * @param path
     * @param grantedPrivilegeNames
     * @param deniedPrivilegeNames
     * @param removedPrivilegeNames
     */
    public static void replaceCreateAccessControlEntry(final Session session,
                                                       final String principalId,
                                                       final String path,
                                                       final String[] grantedPrivilegeNames,
                                                       final String[] deniedPrivilegeNames,
                                                       final String[] removedPrivilegeNames)
    {
        final JackrabbitSession js = (JackrabbitSession)session;
        final PrincipalManager pMgr;
        Set<String> specifiedPrivilegeNames = new HashSet<String>();

        try
        {

            pMgr = js.getPrincipalManager();
            // Maybe we can pass in a group name here and setup permissions for a group??? Thought!
            // It says a principal is a group!
            Principal principal = pMgr.getPrincipal(principalId);
            JackrabbitAccessControlManager acMgr = (JackrabbitAccessControlManager)session
                                    .getAccessControlManager();

            Set<String> newGrantedPrivilegeNames = disaggregateToPrivilegeNames(acMgr,
                                                                                grantedPrivilegeNames,
                                                                                specifiedPrivilegeNames);
            Set<String> newDeniedPrivilegeNames = disaggregateToPrivilegeNames(acMgr,
                                                                               deniedPrivilegeNames,
                                                                               specifiedPrivilegeNames);
            disaggregateToPrivilegeNames(acMgr, removedPrivilegeNames, specifiedPrivilegeNames);

            JackrabbitAccessControlList acl = null;

            AccessControlPolicy[] policies = acMgr.getPolicies(path);// root node
            for (AccessControlPolicy policy : policies)
            {
                if (policy instanceof AccessControlList)
                {
                    acl = (JackrabbitAccessControlList)policy;
                    break;
                }
            }
            if (acl == null)
            {
                AccessControlPolicyIterator applicablePolicies = acMgr.getApplicablePolicies(path);
                while (applicablePolicies.hasNext())
                {
                    AccessControlPolicy policy = applicablePolicies.nextAccessControlPolicy();
                    if (policy instanceof AccessControlList)
                    {
                        acl = (JackrabbitAccessControlList)policy;
                        break;
                    }
                }
            }
            if (acl == null)
            {
                throw new RepositoryException("Could not obtain ACL for resource " + path);
            }
            AccessControlEntry[] accessControlEntries = acl
                                    .getAccessControlEntries();
            for (AccessControlEntry ace : accessControlEntries)
            {
                if (principal.equals(ace.getPrincipal()))
                {
                    if (log.isDebugEnabled())
                    {
                        log.debug("Found Existing ACE for principal {} on resource {}",
                                  new Object[] {principal.getName(), path});
                    }

                    boolean isAllow = ((JackrabbitAccessControlEntry)ace).isAllow();
                    Privilege[] privileges = ace.getPrivileges();
                    for (Privilege privilege : privileges)
                    {
                        Set<String> maintainedPrivileges = disaggregateToPrivilegeNames(privilege);
                        if (!maintainedPrivileges.removeAll(specifiedPrivilegeNames))
                        {
                            // No conflicts, so preserve the original.
                            maintainedPrivileges.clear();
                            maintainedPrivileges.add(privilege.getName());
                        }
                        if (!maintainedPrivileges.isEmpty())
                        {
                            if (isAllow)
                            {
                                newGrantedPrivilegeNames.addAll(maintainedPrivileges);
                            }
                            else
                            {
                                newDeniedPrivilegeNames.addAll(maintainedPrivileges);
                            }
                        }
                    }
                    acl.removeAccessControlEntry(ace);
                }

            }

            List<Privilege> grantedPrivilegeList = new ArrayList<Privilege>();
            for (String name : newGrantedPrivilegeNames)
            {
                Privilege privilege = acMgr.privilegeFromName(name);
                grantedPrivilegeList.add(privilege);
            }
            if (grantedPrivilegeList.size() > 0)
            {
                acl.addAccessControlEntry(principal, grantedPrivilegeList
                                        .toArray(new Privilege[grantedPrivilegeList.size()]));
            }

            // add a fresh ACE with the denied privileges
            List<Privilege> deniedPrivilegeList = new ArrayList<Privilege>();
            for (String name : newDeniedPrivilegeNames)
            {
                Privilege privilege = acMgr.privilegeFromName(name);
                deniedPrivilegeList.add(privilege);
            }
            if (deniedPrivilegeList.size() > 0)
            {
                acl.addEntry(principal,
                             deniedPrivilegeList.toArray(new Privilege[deniedPrivilegeList.size()]),
                             false);
            }

            acMgr.setPolicy(path, acl);
            session.save();

        }
        catch (AccessDeniedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (UnsupportedRepositoryOperationException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (RepositoryException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /**
     * Create a user for the Jackrabbit repository
     * @param jcrSession
     * @param username
     * @param password
     * @throws RepositoryException
     */
    public static void createUser(final Session session, final String username, final String password) throws RepositoryException
    {
        // check for an administrator
        boolean administrator = false;
        UserManager userManager = getUserManager(session);

        User currentUser = (User)retrieveUser(userManager, session.getUserID());
        administrator = currentUser.isAdmin();

        // if (!administrator) {
        // //check if the user is a member of the 'User administrator' group
        // Authorizable userAdmin = userManager.getAuthorizable(this.userAdminGroupName);
        // if (userAdmin instanceof Group) {
        // boolean isMember = ((Group)userAdmin).isMember(currentUser);
        // if (isMember) {
        // administrator = true;
        // }
        // }
        //
        // }

        if (!administrator)
        {
            throw new RepositoryException(
                                          "Unable to register a new user.");
        }

        try
        {
            Authorizable authorizable = retrieveUser(userManager, username);
            if (authorizable != null)
            {
                // user already exists!
                throw new RepositoryException(
                                              "A principal already exists with the requested name: "
                                                                      + username);
            }
            else
            {
                // TODO make password safe and digest it.
                userManager.createUser(username, password);
            }

            if (session.hasPendingChanges())
            {
                session.save();
            }
        }
        finally
        {
            // jrSession.logout();
        }
    }

    /**
     * Create a security group within jackrabbit.
     * @param jcrSession JCR Session to use.
     * @param groupName Group name to create.
     */
    public static void createGroup(final Session jcrSession, final String groupName)
    {
        try
        {
            UserManager userManager = getUserManager(jcrSession);
            Authorizable authorizable = retrieveGroup(userManager, groupName);

            if (authorizable != null)
            {
                // principal already exists!
                throw new RepositoryException(
                                              "A group already exists with the requested name: "
                                                                      + groupName);
            }
            else
            {
                userManager.createGroup(new Principal()
                {
                    @Override
                    public String getName()
                    {
                        return groupName;
                    }
                });
            }

        }
        catch (AccessDeniedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (UnsupportedRepositoryOperationException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (RepositoryException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    /**
     * Add a user to a group.
     * @param session
     * @param groupName
     * @param userId
     * @throws RepositoryException
     * @throws UnsupportedRepositoryOperationException
     * @throws AccessDeniedException
     */
    public static void addUserToGroup(final Session session, final String groupName, final String userId) throws AccessDeniedException,
                                                                                                         UnsupportedRepositoryOperationException,
                                                                                                         RepositoryException
    {
        Group group = null;
        Authorizable member = null;
        UserManager um = getUserManager(session);
        group = retrieveGroup(um, groupName);
        member = retrieveUser(um, userId);
        if (member != null)
        {
            try
            {
                group.addMember(member);
            }
            catch (RepositoryException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }

    /**
     * Retrieve a member from the Jackrabbit user manager
     * @param UserManager
     * @param memberName
     * @return Authorizable member. Null if none is present.
     */
    private static Authorizable retrieveUser(final UserManager um, final String memberName)
    {
        Authorizable member = null;
        try
        {
            member = um.getAuthorizable(memberName);
        }
        catch (AccessDeniedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (UnsupportedRepositoryOperationException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (RepositoryException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return member;
    }

    /**
     * Retrieve a group for a given name. Return NULL if none is found.
     * @param session
     * @param groupName
     * @return Group. Null if none is found.
     */
    private static Group retrieveGroup(final UserManager um, final String groupName)
    {
        Group group = null;
        try
        {
            Authorizable authorizable = um.getAuthorizable(groupName);
            if (authorizable instanceof Group)
            {
                group = (Group)authorizable;
            }
            else
            {
                // TODO throw some sort of exception. Custom LN ONE ?
            }

        }
        catch (AccessDeniedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (UnsupportedRepositoryOperationException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (RepositoryException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return group;
    }

    /**
     * Returns an <code>AccessControlList</code> to edit for the node at the given <code>resourcePath</code>.
     * @param accessControlManager The manager providing access control lists
     * @param resourcePath The node path for which to return an access control list
     * @param mayCreate <code>true</code> if an access control list should be created if the node does not
     *            have one yet.
     * @return The <code>AccessControlList</code> to modify to control access to the node.
     * @throws RepositoryException If the access control manager does not provide a
     *             <code>AccessControlPolicy</code> which is an <code>AccessControlList</code>.
     */
    public static AccessControlList getAccessControlList(final AccessControlManager accessControlManager,
                                                         final String resourcePath, final boolean mayCreate)
                                                                                                            throws RepositoryException
    {

        // check for an existing access control list to edit
        AccessControlPolicy[] policies = accessControlManager.getPolicies(resourcePath);
        for (AccessControlPolicy policy : policies)
        {
            if (policy instanceof AccessControlList)
            {
                return (AccessControlList)policy;
            }
        }

        // no existing access control list, try to create if allowed
        if (mayCreate)
        {
            AccessControlPolicyIterator applicablePolicies = accessControlManager
                                    .getApplicablePolicies(resourcePath);
            while (applicablePolicies.hasNext())
            {
                AccessControlPolicy policy = applicablePolicies.nextAccessControlPolicy();
                if (policy instanceof AccessControlList)
                {
                    return (AccessControlList)policy;
                }
            }
        }

        // neither an existing nor a create AccessControlList is available, fail
        throw new RepositoryException(
                                      "Unable to find or create an access control policy to update for "
                                                              + resourcePath);

    }

    /**
     * Transform an aggregated privilege into a set of disaggregated privilege names. If the privilege is not
     * an aggregate, the set will contain the original name.
     */
    private static Set<String> disaggregateToPrivilegeNames(final Privilege privilege)
    {
        Set<String> disaggregatedPrivilegeNames = new HashSet<String>();
        if (privilege.isAggregate())
        {
            Privilege[] privileges = privilege.getAggregatePrivileges();
            for (Privilege disaggregate : privileges)
            {
                disaggregatedPrivilegeNames.add(disaggregate.getName());
            }
        }
        else
        {
            disaggregatedPrivilegeNames.add(privilege.getName());
        }
        return disaggregatedPrivilegeNames;
    }

    /**
     * Helper routine to transform an input array of privilege names into a set in a null-safe way while also
     * adding its disaggregated privileges to an input set.
     */
    private static Set<String> disaggregateToPrivilegeNames(final AccessControlManager accessControlManager,
                                                            final String[] privilegeNames,
                                                            final Set<String> disaggregatedPrivilegeNames)
                                                                                                          throws RepositoryException
    {
        Set<String> originalPrivilegeNames = new HashSet<String>();
        if (privilegeNames != null)
        {
            for (String privilegeName : privilegeNames)
            {
                originalPrivilegeNames.add(privilegeName);
                Privilege privilege = accessControlManager.privilegeFromName(privilegeName);
                disaggregatedPrivilegeNames.addAll(disaggregateToPrivilegeNames(privilege));
            }
        }
        return originalPrivilegeNames;
    }

    /**
     * @param session
     * @param accessControlManager
     * @param absPath
     * @return
     * @throws RepositoryException
     */
    private static AccessControlEntry[] getAccessControlEntries(final Session session,
                                                                final String absPath) throws RepositoryException
    {
        AccessControlManager accessControlManager = session.getAccessControlManager();
        AccessControlPolicy[] policies = accessControlManager.getEffectivePolicies(absPath);
        for (AccessControlPolicy accessControlPolicy : policies)
        {
            if (accessControlPolicy instanceof AccessControlList)
            {
                AccessControlEntry[] accessControlEntries = ((AccessControlList)accessControlPolicy)
                                        .getAccessControlEntries();
                return accessControlEntries;
            }
        }
        return new AccessControlEntry[0];
    }

    /**
     * Get a list of the Access Controls that exist for a given path.
     * @param jcrSession
     * @param resourcePath
     * @return A Map containing the a list of all the permissions that exist for each principle.
     * @throws RepositoryException
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Map<String, Object>> internalGetAcl(final Session jcrSession,
                                                                  String resourcePath)
                                                                                                            throws RepositoryException

    {

        if (jcrSession == null)
        {
            throw new RepositoryException("JCR Session not found");
        }

        Item item = jcrSession.getItem(resourcePath);
        if (item != null)
        {
            resourcePath = item.getPath();
        }
        else
        {
            // throw new ResourceNotFoundException("Resource is not a JCR Node");
        }

        AccessControlEntry[] declaredAccessControlEntries = getAccessControlEntries(jcrSession, resourcePath);
        Map<String, Map<String, Object>> aclMap = new LinkedHashMap<String, Map<String, Object>>();
        int sequence = 0;
        for (AccessControlEntry ace : declaredAccessControlEntries)
        {
            Principal principal = ace.getPrincipal();
            Map<String, Object> map = aclMap.get(principal.getName());
            if (map == null)
            {
                map = new LinkedHashMap<String, Object>();
                aclMap.put(principal.getName(), map);
                map.put("order", sequence++);
            }

            boolean allow = ((JackrabbitAccessControlEntry)ace).isAllow();
            if (allow)
            {
                Set<String> grantedSet = (Set<String>)map.get("granted");
                if (grantedSet == null)
                {
                    grantedSet = new LinkedHashSet<String>();
                    map.put("granted", grantedSet);
                }
                Privilege[] privileges = ace.getPrivileges();
                for (Privilege privilege : privileges)
                {
                    grantedSet.add(privilege.getName());
                }
            }
            else
            {
                Set<String> deniedSet = (Set<String>)map.get("denied");
                if (deniedSet == null)
                {
                    deniedSet = new LinkedHashSet<String>();
                    map.put("denied", deniedSet);
                }
                Privilege[] privileges = ace.getPrivileges();
                for (Privilege privilege : privileges)
                {
                    deniedSet.add(privilege.getName());
                }
            }
        }

        return aclMap;
    }

    /**
     * @param session
     * @return
     * @throws AccessDeniedException
     * @throws UnsupportedRepositoryOperationException
     * @throws RepositoryException
     */
    private static UserManager getUserManager(final Session session) throws AccessDeniedException,
                                                                    UnsupportedRepositoryOperationException,
                                                                    RepositoryException
    {
        final JackrabbitSession jrSession = (JackrabbitSession)session;
        return jrSession.getUserManager();
    }
}
