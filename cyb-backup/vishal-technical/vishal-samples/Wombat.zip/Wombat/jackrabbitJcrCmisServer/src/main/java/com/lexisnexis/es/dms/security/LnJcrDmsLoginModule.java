package com.lexisnexis.es.dms.security;

import java.io.IOException;
import java.security.Principal;
import java.security.acl.Group;
import java.util.Enumeration;
import java.util.Map;

import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;

import org.apache.jackrabbit.core.security.principal.AdminPrincipal;

import com.lexisnexis.es.utilities.Pair;
import com.lexisnexis.es.utilities.exceptions.SystemException;

/**
 * <br/>
 * <hr/>
 * Copyright © 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 * <hr/>
 * @author cruttens
 */
public class LnJcrDmsLoginModule implements LoginModule
{

    /** Callback handler to use during login. */
    private CallbackHandler callbackHandler_;

    /** Shared state between login modules for a given context. */
    private Map<String, ?> sharedState_;

    /** Principal being authenticated. <code>null</code> unless 'login' has succeeded. */
    private Principal principal_;

    /** Subject to authenticate. */
    private Subject subject_;

    private Group group_;

    @Override
    public void initialize(final Subject subject,
                           final CallbackHandler callbackHandler,
                           final Map<String, ?> sharedState,
                           final Map<String, ?> options)
    {
        callbackHandler_ = callbackHandler;
        sharedState_ = sharedState;
        subject_ = subject;

    }

    @Override
    public boolean login() throws LoginException
    {
        // String name = (String)sharedState_.get("javax.security.auth.login.name");
        Pair<String, char[]> userInfo = establishUsercodePassword();
        if (userInfo.getFirst().equals("testwombat"))
        {
            principal_ = new AdminPrincipal(userInfo.getFirst());
        }
        else
        {
            principal_ = new UserPrincipal(userInfo.getFirst());
            group_ = new Group()
            {

                @Override
                public String getName()
                {
                    // TODO Auto-generated method stub
                    return "lnadmin";
                }

                @Override
                public boolean addMember(final Principal user)
                {
                    // TODO Auto-generated method stub
                    return false;
                }

                @Override
                public boolean removeMember(final Principal user)
                {
                    // TODO Auto-generated method stub
                    return false;
                }

                @Override
                public boolean isMember(final Principal member)
                {
                    // TODO Auto-generated method stub
                    return false;
                }

                @Override
                public Enumeration<? extends Principal> members()
                {
                    // TODO Auto-generated method stub
                    return null;
                }

            };
        }

        return true;
    }

    @Override
    public boolean commit() throws LoginException
    {
        if (principal_ != null)
        {
            subject_.getPrincipals().add(principal_);
            if (group_ != null)
            {
                subject_.getPrincipals().add(group_);
            }
            return true;
        }
        else
        {
            clean();
            return false;
        }
    }

    @Override
    public boolean abort() throws LoginException
    {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean logout() throws LoginException
    {

        return true;
    }

    /**
     * Cleans all internal state from the login module.
     * @return <code>true</code> if there was a pending successful authentication (a principal had been
     *         created), <code>false</code> otherwise.
     */
    private boolean clean()
    {
        final boolean result = principal_ != null;

        callbackHandler_ = null;
        subject_ = null;
        principal_ = null;
        sharedState_ = null;

        return result;
    }

    private Pair<String, char[]> establishUsercodePassword()
    {

        String name = (String)sharedState_.get("javax.security.auth.login.name");
        if (name != null)
        {
            return new Pair<String, char[]>(name,
                                            (char[])sharedState_.get("javax.security.auth.login.password"));
        }

        // Nothing exists already - need to callback
        // final ResourceBundle msgs = ResourceBundle.getBundle(RESOURCE_BUNDLE_NAME);

        // Create the callbacks, and call the handler
        final NameCallback nameCb = new NameCallback("Username");
        final PasswordCallback pwCb = new PasswordCallback("Username", false);
        try
        {
            callbackHandler_.handle(new Callback[] {nameCb, pwCb});
        }
        catch (IOException ex)
        {
            // logger_.error("establishUserName(): ", ex);
            throw new SystemException(ex, "JAAS callback error");
        }
        catch (UnsupportedCallbackException ex)
        {
            // logger_.error("establishUserName(): ", ex);
            throw new SystemException(ex, "JAAS callback error");
        }

        // check for null password marker
        char[] password = pwCb.getPassword();

        if (password != null && "null".equals(new String(password)))
        {
            password = new char[0];
        }

        // Got no error, return whatever the callbacks give us
        return new Pair<String, char[]>(nameCb.getName(), password);
    }

}
