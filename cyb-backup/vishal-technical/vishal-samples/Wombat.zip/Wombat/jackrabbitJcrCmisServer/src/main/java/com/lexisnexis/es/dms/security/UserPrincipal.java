/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.security;

import java.security.Principal;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author cruttens
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class UserPrincipal implements Principal
{

    /**
     * @serial
     */
    private final String name;

    /**
     * Create a SamplePrincipal with a Sample username.
     * <p>
     * @param name the Sample username for this user.
     * @exception NullPointerException if the <code>name</code> is <code>null</code>.
     */
    public UserPrincipal(final String name)
    {
        if (name == null)
        {
            throw new NullPointerException("illegal null input");
        }

        this.name = name;
    }

    /**
     * Return the Sample username for this <code>SamplePrincipal</code>.
     * <p>
     * @return the Sample username for this <code>SamplePrincipal</code>
     */
    @Override
    public String getName()
    {
        return name;
    }

    /**
     * Return a string representation of this <code>SamplePrincipal</code>.
     * <p>
     * @return a string representation of this <code>SamplePrincipal</code>.
     */
    @Override
    public String toString()
    {
        return ("SamplePrincipal:  " + name);
    }

    /**
     * Compares the specified Object with this <code>SamplePrincipal</code> for equality. Returns true if the
     * given object is also a <code>SamplePrincipal</code> and the two SamplePrincipals have the same
     * username.
     * <p>
     * @param o Object to be compared for equality with this <code>SamplePrincipal</code>.
     * @return true if the specified Object is equal equal to this <code>SamplePrincipal</code>.
     */
    @Override
    public boolean equals(final Object o)
    {
        if (o == null)
        {
            return false;
        }

        if (this == o)
        {
            return true;
        }

        if (!(o instanceof UserPrincipal))
        {
            return false;
        }
        UserPrincipal that = (UserPrincipal)o;

        if (this.getName().equals(that.getName()))
        {
            return true;
        }
        return false;
    }

    /**
     * Return a hash code for this <code>SamplePrincipal</code>.
     * <p>
     * @return a hash code for this <code>SamplePrincipal</code>.
     */
    @Override
    public int hashCode()
    {
        return name.hashCode();
    }

}
