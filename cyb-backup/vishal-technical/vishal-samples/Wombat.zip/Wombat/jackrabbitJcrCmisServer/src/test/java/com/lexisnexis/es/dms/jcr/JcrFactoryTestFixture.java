/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.jcr;

import static org.junit.Assert.assertFalse;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.jcr.AccessDeniedException;
import javax.jcr.InvalidItemStateException;
import javax.jcr.ItemExistsException;
import javax.jcr.LoginException;
import javax.jcr.Node;
import javax.jcr.ReferentialIntegrityException;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.SimpleCredentials;
import javax.jcr.UnsupportedRepositoryOperationException;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.nodetype.NoSuchNodeTypeException;
import javax.jcr.security.AccessControlList;
import javax.jcr.security.AccessControlManager;
import javax.jcr.version.VersionException;
import javax.security.auth.login.Configuration;

import org.apache.commons.io.FileUtils;
import org.apache.jackrabbit.core.RepositoryImpl;
import org.apache.jackrabbit.core.config.ConfigurationException;
import org.apache.jackrabbit.core.config.RepositoryConfig;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.lexisnexis.es.dms.security.LnJaasConfigurationTest;
import com.lexisnexis.es.dms.security.LnJcrAccessControlManager;
import com.lexisnexis.es.utilities.StringUtil;

/**
 * Class for creating an in memory Jackrabbit repository.<br>
 * This class also provides JCR helper methods for any test class that extends and needs standard JCR
 * repository functions<br>
 * At the end of the tests the repository that is created should be removed thanks to tearDown method. <br/>
 * <br/>
 * <hr/>
 * @author CruttenS
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class JcrFactoryTestFixture
{

    /** Directory where the docbase was created. <code>null</code> if there's no docbase. */
    private static String repHomeDir_;

    /** The current repository. <code>null</code> == no repos created. */
    private static RepositoryImpl repos_;

    /** ADMIN Id to use to login to the repository */
    protected final static String ADMINID = "admin";

    /**
     * Get the JCR Repository.
     * @return The repository instance.
     */
    public Repository getRepository()
    {
        return repos_;
    }

    @BeforeClass
    /**
     * Setup the JAAS and create the JCR repository.
     * This will run before any of the tests.
     */
    public static void setUp()
    {

        setupTestJaas();
        createJcrRepository();

    }

    /**
     * Create a Jackrabbit JCR repository
     * @return The Repository instance
     */
    protected static Repository createJcrRepository()
    {
        try
        {
            repHomeDir_ = computeDmsDir();
            final InputStream configStream = computeConfigInput();

            final RepositoryConfig config = RepositoryConfig.create(configStream, repHomeDir_);
            repos_ = RepositoryImpl.create(config);

            // Make a base node that is lockable (the root node isn't!)
            final Session session = repos_.login(new SimpleCredentials(ADMINID, new char[0]));
            final Node base = session.getRootNode().addNode("data");
            base.addMixin("mix:lockable");
            base.addMixin("mix:referenceable");
            session.save();
            session.logout();

            return repos_;
        }
        catch (ConfigurationException ex)
        {
            throw new RuntimeException(ex);
        }
        catch (RepositoryException ex)
        {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Installs a test JAAS configuration with the Jackrabbit "any old id" login module as the only login
     * module.
     */
    protected static void setupTestJaas()
    {
        // Install org.apache.jackrabbit.core.security.SimpleLoginModule as the JAAS login module
        // so that any non-null credentials will be accepted.
        Configuration.setConfiguration(new LnJaasConfigurationTest("com.lexisnexis.es.dms.test",
                                                                   "org.apache.jackrabbit.core.security.simple.SimpleLoginModule"));// "com.lexisnexis.es.dms.security.LnJcrDmsLoginModule"
    }

    /**
     * Setup the a group in the repository
     * @param session JCR Session.
     * @param groupName The name of the group to create.
     * @throws AccessDeniedException
     * @throws ItemExistsException
     * @throws ReferentialIntegrityException
     * @throws ConstraintViolationException
     * @throws InvalidItemStateException
     * @throws VersionException
     * @throws LockException
     * @throws NoSuchNodeTypeException
     * @throws RepositoryException
     */
    protected void setupUserGroup(final Session session, final String groupName) throws AccessDeniedException,
                                                                                ItemExistsException,
                                                                                ReferentialIntegrityException,
                                                                                ConstraintViolationException,
                                                                                InvalidItemStateException,
                                                                                VersionException,
                                                                                LockException,
                                                                                NoSuchNodeTypeException,
                                                                                RepositoryException
    {
        LnJcrAccessControlManager.createGroup(session, groupName);
    }

    /**
     * Create a user in the JCR repository.
     * @param session JCR Session.
     * @param username Username to create.
     * @param password Password for the user.
     * @throws RepositoryException
     */
    protected void createUser(final Session session, final String username, final String password) throws RepositoryException
    {
        LnJcrAccessControlManager.createUser(session, username, password);
    }

    /**
     * Computes a directory under the system TMP to put the DMS.
     * @return The directory to use for the DMS.
     */
    private static String computeDmsDir()
    {
        final String tmp = System.getProperty("java.io.tmpdir");
        System.out.println(tmp);
        assertFalse(StringUtil.isEmpty(tmp));
        return tmp + "/lndms/" + System.currentTimeMillis();
    }

    /**
     * Removes any docbase directory structure.
     */
    protected static void cleanDmsDirectory()
    {
        try
        {
            if (repos_ != null)
            {
                repos_.shutdown();
                repos_ = null;
            }
            if (repHomeDir_ != null)
            {
                cleanDmsDirectory(repHomeDir_);
            }
        }
        catch (IOException ex)
        {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Cleans the docbase directory. </p>
     */
    @AfterClass
    public static void tearDown()
    {
        cleanDmsDirectory();
    }

    /**
     * Cleans the directory <tt>repHomeDir</tt> of all content, ready for creating a new docbase in there.
     * @param repHomeDir directory to empty out.
     * @throws IOException Unable to delete the directory.
     */
    private static void cleanDmsDirectory(final String repHomeDir)
                                                                  throws IOException
    {
        final File loc = new File(repHomeDir);
        FileUtils.deleteDirectory(loc);
    }

    /**
     * Returns an input stream for the repository configuration.
     * @return An input stream.
     */
    private static InputStream computeConfigInput()
    {
        return new ByteArrayInputStream(REPOS_CONF.getBytes());
    }

    /**
     * Creates an input stream from <tt>data</tt>.
     * @param data Data to return as an input stream.
     * @return Input stream initialized to return <tt>data</tt>.
     */
    protected InputStream getInputStream(final String data)
    {
        return new ByteArrayInputStream(data.getBytes());
    }

    /**
     * Create a Jackrabbit user group
     * @param pricipalId
     * @param groupName
     * @throws LoginException
     * @throws RepositoryException
     */
    protected void createUserGroup(final String pricipalId, final String groupName) throws LoginException,
                                                                                   RepositoryException
    {
        Session session = login(pricipalId);
        LnJcrAccessControlManager.createGroup(session, groupName);
    }

    /**
     * Replace or create the access control entry privileges.
     * @param principalId
     * @param path
     * @param grantedPrivilegeNames
     * @param deniedPrivilegeNames
     * @param removedPrivilegeNames
     * @throws LoginException
     * @throws RepositoryException
     */
    protected void replaceCreateAccessControlEntry(final Session session,
                                                   final String principalId,
                                                   final String path,
                                                   final String[] grantedPrivilegeNames,
                                                   final String[] deniedPrivilegeNames,
                                                   final String[] removedPrivilegeNames) throws LoginException,
                                                                                        RepositoryException
    {
        LnJcrAccessControlManager.replaceCreateAccessControlEntry(session,
                                                                  principalId,
                                                                  path,
                                                                  grantedPrivilegeNames,
                                                                  deniedPrivilegeNames,
                                                                  removedPrivilegeNames);
    }

    /**
     * Add a user to a group.
     * @param session JCR Session.
     * @param groupName The group to add the user too.
     * @param userId The ID of the user to add.
     * @throws AccessDeniedException
     * @throws UnsupportedRepositoryOperationException
     * @throws RepositoryException
     */
    protected void addUserToGroup(final Session session, final String groupName, final String userId) throws AccessDeniedException,
                                                                                                     UnsupportedRepositoryOperationException,
                                                                                                     RepositoryException
    {
        LnJcrAccessControlManager.addUserToGroup(session, groupName, userId);
    }

    /**
     * Get the Access Control List for the session and the path provided.
     * @param session
     * @param path
     * @return ACL. Null if there are none.
     * @throws UnsupportedRepositoryOperationException
     * @throws RepositoryException
     */
    protected AccessControlList getAccessControlList(final Session session, final String path) throws UnsupportedRepositoryOperationException,
                                                                                              RepositoryException
    {
        AccessControlList acl = null;

        AccessControlManager acMgr = session.getAccessControlManager();
        acl = LnJcrAccessControlManager.getAccessControlList(acMgr, path, false);

        return acl;
    }

    /**
     * Creates a session to the current repository.
     * @param name Logon name to use.
     * @return The session.
     * @throws RepositoryException Fatal DMS error.
     * @throws LoginException Failed to login.
     */
    protected Session login(final String name)
                                              throws LoginException, RepositoryException
    {
        final SimpleCredentials credentials = new SimpleCredentials(name, new char[0]);
        return getRepository().login(credentials);
    }

    /** Configuration for a new test repository. */
    private static final String REPOS_CONF =
                                             "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\r\n" +
                                                                     "<Repository>\r\n"
                                                                     +
                                                                     "    <FileSystem class=\"org.apache.jackrabbit.core.fs.local.LocalFileSystem\">\r\n"
                                                                     +
                                                                     "        <param name=\"path\" value=\"${rep.home}/repository\"/>\r\n"
                                                                     +
                                                                     "    </FileSystem>\r\n"
                                                                     +
                                                                     "    <Security appName=\"com.lexisnexis.es.dms.test\">\r\n"
                                                                     +
                                                                     "        <SecurityManager class=\"org.apache.jackrabbit.core.DefaultSecurityManager\" workspaceName=\"lndms\" />\r\n"
                                                                     +
                                                                     "        <AccessManager\r\n"
                                                                     +
                                                                     "            class=\"org.apache.jackrabbit.core.security.DefaultAccessManager\"/>\r\n"
                                                                     // +
                                                                     // "         <LoginModule class=\"org.apache.jackrabbit.core.security.simple.SimpleLoginModule\">\r\n"
                                                                     // +
                                                                     // "                <param name=\"anonymousId\" value=\"anonymous\"/>\r\n"
                                                                     // +
                                                                     // "                <param name=\"adminId\" value=\"admin\"/>\r\n"
                                                                     // +
                                                                     // "        </LoginModule>\r\n"
                                                                     +
                                                                     "    </Security>\r\n"
                                                                     +
                                                                     "    <Workspaces rootPath=\"${rep.home}/workspaces\" defaultWorkspace=\"lndms\"/>\r\n"
                                                                     +
                                                                     "    <Workspace name=\"${wsp.name}\">\r\n"
                                                                     +
                                                                     "          <WorkspaceSecurity>\r\n"
                                                                     +
                                                                     "              <AccessControlProvider class=\"org.apache.jackrabbit.core.security.authorization.combined.CombinedProvider\" />\r\n"
                                                                     +
                                                                     "          </WorkspaceSecurity>\r\n"
                                                                     +
                                                                     "        <FileSystem class=\"org.apache.jackrabbit.core.fs.local.LocalFileSystem\">\r\n"
                                                                     +
                                                                     "            <param name=\"path\" value=\"${wsp.home}\"/>\r\n"
                                                                     +
                                                                     "        </FileSystem>\r\n"
                                                                     +
                                                                     "        <PersistenceManager\r\n"
                                                                     +
                                                                     "            class=\"org.apache.jackrabbit.core.persistence.mem.InMemPersistenceManager\">\r\n"
                                                                     +
                                                                     "            <param name=\"persistent\" value=\"false\"/>\r\n"
                                                                     +
                                                                     "        </PersistenceManager>\r\n"
                                                                     +
                                                                     "        <SearchIndex class=\"org.apache.jackrabbit.core.query.lucene.SearchIndex\">\r\n"
                                                                     +
                                                                     "            <param name=\"path\" value=\"${wsp.home}/index\"/>\r\n"
                                                                     +
                                                                     "            <param name=\"analyzer\"\r\n"
                                                                     +
                                                                     "                value=\"org.apache.lucene.analysis.standard.StandardAnalyzer\"/>\r\n"
                                                                     +
                                                                     "            <param name=\"useCompoundFile\" value=\"false\"/>\r\n"
                                                                     +
                                                                     "            <param name=\"minMergeDocs\" value=\"99\"/>\r\n"
                                                                     +
                                                                     "            <param name=\"maxMergeDocs\" value=\"100000\"/>\r\n"
                                                                     +
                                                                     "            <param name=\"volatileIdleTime\" value=\"3\"/>\r\n"
                                                                     +
                                                                     "            <param name=\"mergeFactor\" value=\"100\"/>\r\n"
                                                                     +
                                                                     "            <param name=\"bufferSize\" value=\"100\"/>\r\n"
                                                                     +
                                                                     "            <param name=\"forceConsistencyCheck\" value=\"false\"/>\r\n"
                                                                     +
                                                                     "            <param name=\"autoRepair\" value=\"true\"/>\r\n"
                                                                     +
                                                                     "            <param name=\"respectDocumentOrder\" value=\"false\"/>\r\n"
                                                                     +
                                                                     // "            <param name=\"textFilterClasses\" value=\"\r\n"
                                                                     // +
                                                                     // "                org.apache.jackrabbit.extractor.PlainTextExtractor,\r\n"
                                                                     // +
                                                                     // "                org.apache.jackrabbit.extractor.MsExcelTextExtractor,\r\n"
                                                                     // +
                                                                     // "                org.apache.jackrabbit.extractor.MsPowerPointTextExtractor,\r\n"
                                                                     // +
                                                                     // "                org.apache.jackrabbit.extractor.MsWordTextExtractor,\r\n"
                                                                     // +
                                                                     // "                org.apache.jackrabbit.extractor.PdfTextExtractor,\r\n"
                                                                     // +
                                                                     // "                org.apache.jackrabbit.extractor.HTMLTextExtractor,\r\n"
                                                                     // +
                                                                     // "                org.apache.jackrabbit.extractor.XMLTextExtractor,\r\n"
                                                                     // +
                                                                     // "                org.apache.jackrabbit.extractor.RTFTextExtractor,\r\n"
                                                                     // +
                                                                     // "                org.apache.jackrabbit.extractor.OpenOfficeTextExtractor\"/>\r\n"
                                                                     // +
                                                                     "            <FileSystem\r\n"
                                                                     +
                                                                     "                class=\"org.apache.jackrabbit.core.fs.local.LocalFileSystem\">\r\n"
                                                                     +
                                                                     "                <param name=\"path\" value=\"${wsp.home}/index\"/>\r\n"
                                                                     +
                                                                     "            </FileSystem>\r\n"
                                                                     +
                                                                     "        </SearchIndex>\r\n"
                                                                     +
                                                                     "    </Workspace>\r\n"
                                                                     +
                                                                     "    <Versioning rootPath=\"${rep.home}/versions\">\r\n"
                                                                     +
                                                                     "        <FileSystem class=\"org.apache.jackrabbit.core.fs.local.LocalFileSystem\">\r\n"
                                                                     +
                                                                     "            <param name=\"path\" value=\"${rep.home}/versions\"/>\r\n"
                                                                     +
                                                                     "        </FileSystem>\r\n"
                                                                     +
                                                                     "        <PersistenceManager\r\n"
                                                                     +
                                                                     "            class=\"org.apache.jackrabbit.core.persistence.xml.XMLPersistenceManager\"/>\r\n"
                                                                     +
                                                                     "    </Versioning>\r\n"
                                                                     +
                                                                     "</Repository>\r\n"
                                                                     +
                                                                     "";

}
