/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.jcr;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.Set;

import javax.jcr.AccessDeniedException;
import javax.jcr.LoginException;
import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.security.AccessControlList;
import javax.jcr.security.Privilege;

import org.apache.jackrabbit.JcrConstants;
import org.junit.Test;

import com.lexisnexis.es.dms.security.LnJcrAccessControlManager;

/**
 * Class for testing user authorisation on the document structure in the Jackrabbit security realm.<br>
 * This class will test read / write privileges on folders and documents. This class will test that users who
 * do not have access to a group <br>
 * <br>
 * <hr/>
 * @author CruttenS
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class JcrSecurityAuthorizationTest extends JcrFactoryTestFixture
{
    /** Root folder for the LN DMS in this test situation. */
    private static String ROOTFOLDER = "lndms";

    /**
     * Create some data in the repository. Saves the session after. Documents are in nodes d&lt;n&gt; where 0
     * &lt;= n &lt; docs.
     * @param session Session to use.
     * @param folderName Folder level one name
     * @param folderNameTwo Folder level two name
     * @param docs Number of document nodes to create.
     * @throws RepositoryException Fatal error creating the data.
     */
    @SuppressWarnings("deprecation")
    private void setupData(final Session session,
                                    final String folderName,
                                    final String folderNameTwo,
                                    final int docs)
                                                   throws RepositoryException
    {
        Node node = session.getRootNode();
        if (!node.hasNode(ROOTFOLDER))
        {
            node = node.addNode(ROOTFOLDER, JcrConstants.NT_FOLDER);
            node.addMixin("mix:lockable");
            node.addMixin("mix:referenceable");
        }
        else
        {
            node = node.getNode(ROOTFOLDER);
        }
        if (!node.hasNode(folderName))
        {
            node = node.addNode(folderName, JcrConstants.NT_FOLDER);
            node.addMixin("mix:lockable");
            node.addMixin("mix:referenceable");
        }
        else
        {
            node = node.getNode(folderName);
        }
        if (!node.hasNode(folderNameTwo))
        {
            node = node.addNode(folderNameTwo, JcrConstants.NT_FOLDER);
            node.addMixin("mix:lockable");
            node.addMixin("mix:referenceable");
        }
        else
        {
            node = node.getNode(folderNameTwo);
        }

        System.out.println("path=" + node.getPath());

        for (int i = 0; i < docs; ++i)
        {
            final Node doc = node.addNode("d" + i, JcrConstants.NT_FILE);
            final Node resource = doc.addNode(JcrConstants.JCR_CONTENT, JcrConstants.NT_RESOURCE);
            resource.setProperty(JcrConstants.JCR_MIMETYPE, "plain/text");
            final Calendar cal = Calendar.getInstance();
            cal.setTime(new Date());
            resource.setProperty(JcrConstants.JCR_LASTMODIFIED, cal);
            resource.setProperty(JcrConstants.JCR_DATA, getInputStream("data content " + i));
        }

        session.save();
    }

    /**
     * Test that admin user can create a set of permissions on a given root folder
     * @throws Exception
     */
    @Test
    public void testCreateAccessControlEntry() throws Exception
    {
        String[] grantedPrivilegeNames = {Privilege.JCR_ALL};
        Session session = login(ADMINID);
        setupData(session, "FolderOne", "FolderTwo", 2);
        final Node root = session.getRootNode();
        String path = "";
        try
        {
            path = root.getNode(ROOTFOLDER + "/FolderOne").getPath();
            replaceCreateAccessControlEntry(session, ADMINID, path, grantedPrivilegeNames, null, null);
            AccessControlList acl = getAccessControlList(session, path);
            assertNotNull(acl);
            session.logout();
        }
        catch (PathNotFoundException ex)
        {
            fail();
            ex.printStackTrace();
        }
        catch (LoginException e)
        {
            fail();
            e.printStackTrace();
        }
        catch (RepositoryException e)
        {
            fail();
            e.printStackTrace();
        }

    }

    /**
     * Create a group. Done as a test.<br>
     * Data already setup in test #testCreateAccessControlEntry
     */
    @Test
    public void testCreateAGroup()
    {
        String path = "";

        try
        {
            Session session = login(ADMINID);
            setupUserGroup(session, "readOnly");
            String[] grantedPrivilegeNames = {Privilege.JCR_READ};
            String[] deniedPrivilegeNames = {Privilege.JCR_WRITE};
            final Node root = session.getRootNode();
            path = root.getNode(ROOTFOLDER + "/FolderOne").getPath();
            replaceCreateAccessControlEntry(session,
                                            "readOnly",
                                            path,
                                            grantedPrivilegeNames,
                                            deniedPrivilegeNames,
                                            null);
            session.logout();
        }
        catch (LoginException e)
        {
            fail();
            e.printStackTrace();
        }
        catch (RepositoryException e)
        {
            fail();
            e.printStackTrace();
        }
    }

    /**
     * Test to create a new user within the repository.<br>
     * Data already setup in test #testCreateAccessControlEntry
     */
    @Test
    public void testCreateUser()
    {
        try
        {
            Session session = login(ADMINID);
            createUser(session, "testRead", "password");
            session.logout();
        }
        catch (LoginException e)
        {
            fail();
            e.printStackTrace();
        }
        catch (RepositoryException e)
        {
            fail();
            e.printStackTrace();
        }
    }

    /**
     * Add a member to a group. <br>
     * Data already setup in test #testCreateAccessControlEntry and #testCreateAGroup
     */
    @Test
    public void testAddMemberToGroup()
    {
        try
        {
            Session session = login(ADMINID);
            addUserToGroup(session, "readOnly", "testRead");
            session.logout();
        }
        catch (LoginException e)
        {
            fail();
            e.printStackTrace();
        }
        catch (RepositoryException e)
        {
            fail();
            e.printStackTrace();
        }
    }

    /**
     * Test that a user who does not have write permission is not able to add a document<br>
     * Data already setup in test #testCreateAccessControlEntry and #testCreateAGroup and
     * #testAddMemberToGroup
     * @throws RepositoryException
     */
    @SuppressWarnings("deprecation")
    @Test(expected = AccessDeniedException.class)
    public void testNotAbleToAddDocumentToReadOnlyFolder() throws RepositoryException
    {
        Session session = null;
        try
        {
            session = login("testRead");
            final Node root = session.getRootNode();
            Node folderOne = root.getNode(ROOTFOLDER + "/FolderOne");
            final Node doc = folderOne.addNode("d" + "denied", JcrConstants.NT_FILE);
            final Node resource = doc.addNode(JcrConstants.JCR_CONTENT, JcrConstants.NT_RESOURCE);
            resource.setProperty(JcrConstants.JCR_MIMETYPE, "plain/text");
            final Calendar cal = Calendar.getInstance();
            cal.setTime(new Date());
            resource.setProperty(JcrConstants.JCR_LASTMODIFIED, cal);
            resource.setProperty(JcrConstants.JCR_DATA, getInputStream("data content " + "test"));
            session.save();
            session.logout();

        }
        catch (LoginException e)
        {
            e.printStackTrace();
            fail();
        }
    }

    /**
     * Test that the permissions granted on a given path can be removed.<br>
     * Data already setup in test #testCreateAccessControlEntry
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void testRemoveAccessControlEntry() throws Exception
    {
        String[] grantedPrivilegeNames = {Privilege.JCR_ALL};
        String[] removedPrivilegeNames = {Privilege.JCR_ALL, Privilege.JCR_READ};

        Session session = login(ADMINID);
        final Node root = session.getRootNode();
        String path = "";

        try
        {
            path = root.getNode(ROOTFOLDER + "/FolderOne").getPath();
            replaceCreateAccessControlEntry(session, ADMINID, path, grantedPrivilegeNames, null, null);
            AccessControlList acl = getAccessControlList(session, path);
            assertNotNull(acl);
            LnJcrAccessControlManager.internalGetAcl(session, path).containsKey(ADMINID);
            Map<String, Object> permissionsForId = LnJcrAccessControlManager.internalGetAcl(session, path)
                                    .get(ADMINID);
            Set<String> grantedPermission = (Set<String>)permissionsForId.get("granted");
            assertTrue(grantedPermission.contains("jcr:all"));

            replaceCreateAccessControlEntry(session, ADMINID, path, null, null, removedPrivilegeNames);
            LnJcrAccessControlManager.internalGetAcl(session, path).containsKey(ADMINID);
            assertFalse(LnJcrAccessControlManager.internalGetAcl(session, path).containsKey(ADMINID));
        }
        catch (PathNotFoundException ex)
        {
            fail();
            ex.printStackTrace();
        }
        catch (LoginException e)
        {
            fail();
            e.printStackTrace();
        }
        catch (RepositoryException e)
        {
            fail();
            e.printStackTrace();
        }

        session.logout();
    }

}
