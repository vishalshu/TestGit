/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.security;

import java.util.HashMap;
import java.util.Map;

import javax.security.auth.login.AppConfigurationEntry;
import javax.security.auth.login.Configuration;

/**
 * JAAS Configuration class that allows for manual configuration of a login module. <br/>
 * <br/>
 * <hr/>
 * @author CruttenS
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public class LnJaasConfigurationTest extends Configuration
{

    /** Array of one config entry for the LN login module. */
    private AppConfigurationEntry[] configEntry_;

    /** Name of the application to install the LN login module under. */
    private final String appName_;

    /** Options to pass to the LN login module. May be <code>null</code>. */
    private final Map<String, Object> options_;

    /** Login module FQCN. */
    private final String lmClassName_;

    /**
     * Constructor taking an application name.
     * @param appName Application name to install the login module under
     */
    public LnJaasConfigurationTest(final String appName, final String lmClassName)
    {
        appName_ = appName;
        options_ = new HashMap<String, Object>();
        options_.put("adminId", "admin");
        lmClassName_ = lmClassName;
        setupConfigurationEntry();

        // Make this the current JAAS configuration
        setConfiguration(this);
    }

    /**
     * Constructor taking an application name and options.
     * @param appName Application name to install the login module under
     * @param options Options to pass to the LN login module.
     */
    public LnJaasConfigurationTest(final String appName,
                                   final Map<String, Object> options,
                                   final String lmClassName)
    {
        appName_ = appName;
        options_ = options;
        lmClassName_ = lmClassName;
        setupConfigurationEntry();

        // Make this the current JAAS configuration
        setConfiguration(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public AppConfigurationEntry[] getAppConfigurationEntry(final String name)
    {
        if (name.equals(appName_))
        {
            return configEntry_;
        }
        else
        {
            return null;
        }
    }

    /**
     * Creates the config entry for the LN login module.
     */
    private void setupConfigurationEntry()
    {
        AppConfigurationEntry ce = new AppConfigurationEntry(lmClassName_,
                                                             AppConfigurationEntry.LoginModuleControlFlag.REQUISITE,
                                                             options_);
        configEntry_ = new AppConfigurationEntry[] {ce};
    }

    /**
     * {@inheritDoc}.
     */
    @Override
    public void refresh()
    {
        // Do nothing
    }

}
