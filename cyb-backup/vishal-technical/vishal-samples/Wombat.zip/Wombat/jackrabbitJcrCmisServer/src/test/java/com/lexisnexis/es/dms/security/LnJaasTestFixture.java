/*
 * Copyright (c) 2011 LexisNexis, a division of Reed Elsevier Inc. All rights reserved.
 */

package com.lexisnexis.es.dms.security;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

/**
 * <br/>
 * <br/>
 * <hr/>
 * @author CruttenS
 * @version $Revision$
 * @since 1.0
 * 
 *        <pre>
 * $Id$
 * </pre>
 */

public abstract class LnJaasTestFixture
{

    /**
     * Create a simple callback handler with a single username and password, that will provide said values if
     * the right types of callback are found. The only supported callback types are <tt>NameCallback</tt> and
     * <tt>PasswordCallback</tt>.
     * @param name Username / code to use.
     * @param pw Password to use. May be <code>null</code>.
     * @return A new Callback handler.
     */
    protected CallbackHandler createCbHandler(final String name, final String pw)
    {
        return new CallbackHandler()
        {
            /** {@inheritDoc} */
            @Override
            public void handle(final Callback[] callbacks)
                                                          throws IOException, UnsupportedCallbackException
            {
                for (Callback cb : callbacks)
                {
                    if (cb instanceof NameCallback)
                    {
                        NameCallback ncb = (NameCallback)cb;
                        ncb.setName(name);
                    }
                    else if (cb instanceof PasswordCallback)
                    {
                        PasswordCallback pcb = (PasswordCallback)cb;
                        pcb.setPassword(pw != null ? pw.toCharArray() : null);
                    }
                }
            }
        };
    }
}
