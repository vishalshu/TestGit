package my.sample.osgi.logger.console;

import java.util.Hashtable;

import my.sample.osgi.logger.LoggerApi;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.util.tracker.ServiceTracker;

public class Activator implements BundleActivator {

	private ServiceTracker simpleLogServiceTracker;
	private LoggerApi simpleLogService;
	
	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext context) throws Exception {
		// register the service
		context.registerService(
				SimpleLogServiceImpl.class.getName(), 
				new SimpleLogServiceImpl(), 
				new Hashtable());
		
		// create a tracker and track the log service
		simpleLogServiceTracker = 
			new ServiceTracker(context, LoggerApi.class.getName(), null);
		simpleLogServiceTracker.open();
		
		// grab the service
		simpleLogService = (LoggerApi) simpleLogServiceTracker.getService();

		if(simpleLogService != null)
			simpleLogService.log("Yee ha, I'm starting!");
	}
	
	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext context) throws Exception {
		if(simpleLogService != null)
			simpleLogService.log("Yee ha, I'm stopping!");
		
		// close the service tracker
		simpleLogServiceTracker.close();
		simpleLogServiceTracker = null;
		
		simpleLogService = null;
	}

}
