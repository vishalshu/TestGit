package my.sample.osgi.logger.console;

import my.sample.osgi.logger.LoggerApi;

public class SimpleLogServiceImpl implements LoggerApi {

	public void log(String message) {
		System.out.println("Changed logger "+message);
	}
	
}
