/**
 * 
 */
package my.sample.osgi.logger;

/**
 * @author vishalshu
 *
 */
public interface LoggerApi {

	void log(String message);
}
